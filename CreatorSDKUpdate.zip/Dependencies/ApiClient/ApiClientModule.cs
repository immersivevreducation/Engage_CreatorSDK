﻿using System;

namespace Engage.Network
{
    public abstract class ApiClientModule
    {
        public virtual string AuthToken => ApiClient?.Module<ApiClientAuthentication>().AuthToken;

        public abstract string Command { get; }

        public ApiClient ApiClient { get; }
        public virtual Uri ApiDomain => ApiClient?.HostDomain;
        public virtual string ApiVersion => ApiClient?.ApiVersion;

        protected ApiClientModule(ApiClient client)
        {
            ApiClient = client;
        }
    }

    public abstract class ApiClientModule<T, I> : ApiClientModule where T : class
    {
        protected ApiClientModule(ApiClient client) : base(client) { }
    }
}