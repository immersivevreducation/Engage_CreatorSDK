﻿namespace Engage.Network
{
    public class Token : IToken
    {
        public string AccessToken { get; set; }
    }
}