﻿using System;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace Engage.Network
{
    public static class EncryptionTool
    {
        /// <summary>
        /// Encrypts a plain string using the given key.
        /// </summary>
        /// <param name="plainText"></param>
        /// <param name="key">256-bit AES key</param>
        /// <returns>An encrypted Base64 string</returns>
        public static string Encrypt(string plainText, string key)
        {
            if (string.IsNullOrEmpty(plainText))
                return null;

            if (string.IsNullOrEmpty(key))
                return plainText;

            byte[] encrypted;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = Encoding.UTF8.GetBytes(key.Substring(0, 16));

                var encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (var memStream = new MemoryStream())
                {
                    using (var cryptoStream = new CryptoStream(memStream, encryptor, CryptoStreamMode.Write))
                    {
                        using (var writer = new StreamWriter(cryptoStream))
                        {
                            writer.Write(plainText);
                        }
                    }

                    encrypted = memStream.ToArray();
                }
            }

            return Convert.ToBase64String(encrypted, 0, encrypted.Length);
        }

        public static string Decrypt(string encrypted, string key)
        {
            if (string.IsNullOrEmpty(encrypted))
                return null;

            if (string.IsNullOrEmpty(key))
                return encrypted;

            string plainText = string.Empty;

            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(key);
                aes.IV = Encoding.UTF8.GetBytes(key.Substring(0, 16));

                var decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                try
                {
                    using (var memStream = new MemoryStream(Convert.FromBase64String(encrypted)))
                    {
                        using (var cryptoStream = new CryptoStream(memStream, decryptor, CryptoStreamMode.Read))
                        {
                            using (var reader = new StreamReader(cryptoStream))
                            {
                                plainText = reader.ReadToEnd();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                }
            }

            return plainText;
        }
    }
}
