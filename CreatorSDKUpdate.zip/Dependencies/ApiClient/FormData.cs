﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.Networking;

namespace Engage.Network
{
    public class FormData : List<IMultipartFormSection>
    {
        public const string TextType = "text";
        public const string FileType = "file";
        public const string FileKey = "files";

        public void AddText(string key, string value) => Add(new MultipartFormDataSection(key, value, TextType));

        public void AddFile(string filepath)
        {
            if (!System.IO.File.Exists(filepath))
            {
                Debug.LogError($"[ApiClient - FormData.AddFile] filepath ({filepath}) does not exist.");
            }

            var data = System.IO.File.ReadAllBytes(filepath);
            Add(new MultipartFormFileSection(FileKey, data, System.IO.Path.GetFileName(filepath), FileType));
        }
    }
}