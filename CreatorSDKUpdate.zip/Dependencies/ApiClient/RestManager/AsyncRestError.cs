﻿using Newtonsoft.Json;
using System.Collections.Generic;
using UnityEngine.Networking;

namespace Engage.Network
{
    public class AsyncRestError
    {
        public string Url { get; }
        public int HttpStatus { get; }
        public string Error { get; }
        public string Message { get; }

        public AsyncRestError(UnityWebRequest request)
        {
            Url = request.url;
            HttpStatus = (int)request.responseCode;
            Error = request.error;

            try
            {
                var settings = new JsonSerializerSettings
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    MissingMemberHandling = MissingMemberHandling.Ignore
                };

                var errorText = JsonConvert.DeserializeObject<Dictionary<string, string>>(request.downloadHandler.text, settings);

                if (errorText.TryGetValue("message", out string message))
                {
                    Message = message;
                }
            }
            catch
            {
                Message = request.downloadHandler.text;
            }
        }

        public AsyncRestError(long httpStatus)
        {
            HttpStatus = (int)httpStatus;
            Error = HttpStatus.ToString();
        }

        public AsyncRestError(string message)
        {
            Message = message;
        }

        public AsyncRestError(string message, string error)
        {
            Message = message;
            Error = error;
        }

        public override string ToString()
        {
            return $"[{HttpStatus}] Request to ({Url}) Response: {Error} : {Message}";
        }
    }
}
