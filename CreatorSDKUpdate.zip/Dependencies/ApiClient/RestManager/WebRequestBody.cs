﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Networking;

namespace Engage.Network
{
    public partial class WebRequestBody
    {
        public byte[] Content { get; protected set; }
        public string ContentType { get; protected set; }

        protected WebRequestBody() { }

        public static WebRequestBody GetRequestBody(Dictionary<string, string> simpleForm, string contentType = "application/x-www-form-urlencoded")
        {
            try
            {
                return new WebRequestBody()
                {
                    Content = UnityWebRequest.SerializeSimpleForm(simpleForm),
                    ContentType = contentType
                };
            }
            catch (ArgumentException e)
            {
                Debug.LogError($"[RestClient-GetRequest] Invalid body {simpleForm}: {e}");
                return null;
            }
        }

        public static WebRequestBody GetRequestBody(List<IMultipartFormSection> multipartForm)
        {
            try
            {
                byte[] boundary = UnityWebRequest.GenerateBoundary();
                byte[] formSections = UnityWebRequest.SerializeFormSections(multipartForm, boundary);
                byte[] terminate = Encoding.UTF8.GetBytes($"\r\n--{Encoding.UTF8.GetString(boundary)}--");

                var body = new byte[formSections.Length + terminate.Length];
                Buffer.BlockCopy(formSections, 0, body, 0, formSections.Length);
                Buffer.BlockCopy(terminate, 0, body, formSections.Length, terminate.Length);

                var contentType = $"multipart/form-data; boundary={Encoding.UTF8.GetString(boundary)}";

                return new WebRequestBody() { Content = body, ContentType = contentType };
            }
            catch (ArgumentException e)
            {
                Debug.LogError($"[RestClient-GetRequest] Invalid body {multipartForm}: {e}");
                return null;
            }
        }

        public static WebRequestBody GetRequestBody(string json, string contentType = "application/json")
            => GetRequestBody(Encoding.UTF8.GetBytes(json.ToCharArray()), contentType);

        public static WebRequestBody GetRequestBody(byte[] body, string contentType)
            => new WebRequestBody() { Content = body, ContentType = contentType };
    }
}
