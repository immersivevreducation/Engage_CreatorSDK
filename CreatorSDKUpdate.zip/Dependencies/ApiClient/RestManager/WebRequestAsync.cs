﻿// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 21/10/21
// Author: Bryn
// Description: Async web request system
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/


using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace UnityEngine.Networking
{
    public static class UnityWebRequestAsync
    {
        public static async Task<bool> SendRequestAsync(this UnityWebRequest request,
            bool ignoreHttpErrors = false,
            CancellationToken cancellationToken = default,
            Action<float> onUploadProgress = null,
            Action<float> onDownloadProgress = null)
        {
            request.SendWebRequest();

            while (!request.isDone && !cancellationToken.IsCancellationRequested)
            {
                onUploadProgress?.Invoke(request.uploadProgress);
                onDownloadProgress?.Invoke(request.downloadProgress);
                await Task.Yield();
            }

            if (cancellationToken.IsCancellationRequested)
            {
                if (!request.isDone)
                {
                    request.Abort();
                }

                Debug.LogWarning($"[{request.uri}] Cancellation Requested");
                cancellationToken.ThrowIfCancellationRequested();

                return false;
            }

            if ((!ignoreHttpErrors && request.isHttpError) || request.isNetworkError)
            {
                Debug.LogError(request.error);
                return false;
            }

            return true;
        }

        private static async Task<bool> SendRequestAsync(this UnityWebRequest request, 
            Action<UnityWebRequest> setup, 
            CancellationToken cancellationToken = default,
            Action<float> onUploadProgress = null,
            Action<float> onDownloadProgress = null)
        {
            setup?.Invoke(request);
            request.SendWebRequest();

            while (!request.isDone && !cancellationToken.IsCancellationRequested)
            {
                onUploadProgress?.Invoke(request.uploadProgress);
                onDownloadProgress?.Invoke(request.downloadProgress);
                await Task.Yield();
            }

            if (cancellationToken.IsCancellationRequested)
            {
                return false;
            }

            if (request.isHttpError || request.isNetworkError)
            {
                Debug.LogError(request.error);
                return false;
            }

            return true;
        }

        public static async Task<string> RequestTextAsync(string url, Action<UnityWebRequest> setup = null, CancellationToken cancellationToken = default)
        {
            using (var request = UnityWebRequest.Get(url))
            {
                setup?.Invoke(request);

                if (!await request.SendRequestAsync(false, cancellationToken))
                {
                    if (!string.IsNullOrEmpty(request.error))
                    {
                        Debug.LogError(request.error);
                    }
                    return null;
                }

                return request.downloadHandler.text;
            }
        }

        public static async Task<Texture2D> RequestTextureAsync(string url, CancellationToken cancellationToken = default)
        {
            return await RequestTextureAsync(url, false, null, cancellationToken);
        }

        public static async Task<Texture2D> RequestTextureAsync(string url, bool nonReadable, CancellationToken cancellationToken = default)
        {
            return await RequestTextureAsync(url, nonReadable, null, cancellationToken);
        }

        public static async Task<Texture2D> RequestTextureAsync(string url, bool nonReadable, Action<UnityWebRequest> setup, CancellationToken cancellationToken = default)
        {
            using (var request = UnityWebRequestTexture.GetTexture(url, nonReadable))
            {
                setup?.Invoke(request);

                if (!await request.SendRequestAsync(false, cancellationToken))
                {
                    if (!string.IsNullOrEmpty(request.error))
                    {
                        Debug.LogError(request.error);
                    }
                    return null;
                }

                return DownloadHandlerTexture.GetContent(request);
            }
        }
    }
}