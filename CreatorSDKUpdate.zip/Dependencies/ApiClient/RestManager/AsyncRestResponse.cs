﻿namespace Engage.Network
{
    public class AsyncRestResponse
    {
        protected AsyncRestResponse() { }

        public static AsyncRestResponse FromError(AsyncRestError error) => new AsyncRestResponse() { IsSuccess = false, Error = error, Code = error.HttpStatus };
        public static AsyncRestResponse FromErrorMessage(string errorMessage) => new AsyncRestResponse() { IsSuccess = false, Error = new AsyncRestError(errorMessage) };
        public static AsyncRestResponse FromResult(long responceCode, string resultText = null, byte[] resultData = null) => new AsyncRestResponse() { IsSuccess = true, Code = (int)responceCode, ResultText = resultText, ResultData = resultData };

        public int Code { get; protected set; }
        public bool IsSuccess { get; protected set; }
        public string ResultText { get; protected set; }
        public byte[] ResultData { get; protected set; }
        public AsyncRestError Error { get; protected set; }
    }

    public class AsyncRestResponse<T> : AsyncRestResponse
    {
        public static new AsyncRestResponse<T> FromError(AsyncRestError error) => new AsyncRestResponse<T>() { IsSuccess = false, Error = error, Code = error.HttpStatus };
        public static new AsyncRestResponse<T> FromErrorMessage(string errorMessage) => new AsyncRestResponse<T>() { IsSuccess = false, Error = new AsyncRestError(errorMessage) };
        public static AsyncRestResponse<T> FromResult(long responseCode, T result = default, string resultText = null) => new AsyncRestResponse<T>() { IsSuccess = true, Code = (int)responseCode, Result = result, ResultText = resultText };

        public T Result { get; protected set; }
    }
}
