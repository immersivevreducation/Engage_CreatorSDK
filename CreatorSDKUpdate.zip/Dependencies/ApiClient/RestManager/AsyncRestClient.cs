using Newtonsoft.Json;
using System;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Networking;

namespace Engage.Network
{
    public static class Request
    {
        public const string Get = "GET";
        public const string Post = "POST";
        public const string Put = "PUT";
        public const string Patch = "PATCH";
        public const string Delete = "DELETE";
    }

    public static class AsyncRestClient
    {
        private static UnityWebRequest GetRequest(Uri url, string method, string accessToken = null, WebRequestBody body = null)
        {
            UnityWebRequest request;

            try
            {
                request = new UnityWebRequest(url, method, new DownloadHandlerBuffer(), null);
            }
            catch (Exception e)
            {
                Debug.LogError($"[RestClient-GetRequest] Invalid url {url}: {e}");
                return null;
            }

            if (!string.IsNullOrEmpty(accessToken))
            {
                request.SetRequestHeader("Authorization", "Bearer " + accessToken);
            }

            request.SetRequestHeader("Accept", "application/json");

            if (body != null)
            {
                request.SetRequestHeader("Content-Type", body.ContentType);
                request.uploadHandler = new UploadHandlerRaw(body.Content);
                request.uploadHandler.contentType = body.ContentType;
            }

            return request;
        }

        private static async Task<AsyncRestError> TrySendRequest(UnityWebRequest request, CancellationToken cancellationToken = default, Action<float> onUploadProgress = null, Action<float> onDownloadProgress = null)
        {
            try
            {
                if (!await request.SendRequestAsync(true, cancellationToken, onUploadProgress, onDownloadProgress))
                {
                    Debug.LogError($"[RestClient-TrySendRequest] Request to {request.url} failed: {request.error}");
                    return new AsyncRestError("Failed to send request");
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[RestClient-TrySendRequest] Request to {request.url} failed: {e}");
                return new AsyncRestError("Failed to send request");
            }

            if (request.isHttpError)
            {
                var restError = new AsyncRestError(request);
                //Debug.LogError($"[RestClient-TrySendRequest] Failed to parse error from {request.url}: {e}");

                return restError;
            }

            return null;
        }

        public static async Task<AsyncRestResponse> SendRequest(Uri url, string method = Request.Get, string accessToken = null, WebRequestBody body = null, CancellationToken cancellationToken = default, Action<float> onUploadProgress = null, Action<float> onDownloadProgress = null)
        {
            Debug.Log($"[RestClient-SendRequest] ({method}:{url}) Sending...");

            using (var request = GetRequest(url, method, accessToken, body))
            {
                if (request == null)
                {
                    Debug.LogError($"[RestClient-SendRequest] Invalid request");
                    return AsyncRestResponse.FromErrorMessage("Invalid request");
                }

                var error = await TrySendRequest(request, cancellationToken, onUploadProgress, onDownloadProgress);
                if (error != null)
                {
                    Debug.LogError($"[RestClient-SendRequest] Error: {error}");
                    return AsyncRestResponse.FromError(error);
                }

                var response = AsyncRestResponse.FromResult(request.responseCode, request.downloadHandler.text, request.downloadHandler.data);

                Debug.Log($"[RestClient-SendRequest] ({method}:{url}) Response: {(response.IsSuccess ? "Success" : "Failed")}");

                return response;
            }
        }

        public static async Task<AsyncRestResponse<T>> SendRequest<T>(Uri url, string method = Request.Get, string accessToken = null, WebRequestBody body = null, Func<string, string> resultFilter = null)
        {
            Debug.Log($"[RestClient-SendRequest] ({method}:{url}) Sending...");

            using (var request = GetRequest(url, method, accessToken, body))
            {
                if (request == null)
                {
                    Debug.LogError($"[RestClient-SendRequest] Invalid request");
                    return AsyncRestResponse<T>.FromErrorMessage("Invalid request");
                }

                var error = await TrySendRequest(request);
                if (error != null)
                {
                    Debug.LogError($"[RestClient-SendRequest] Error: {error}");
                    return AsyncRestResponse<T>.FromError(error);
                }

                string resultText = request.downloadHandler.text;
                if (resultFilter != null)
                {
                    resultText = resultFilter.Invoke(resultText);
                }

                T result = default;
                try
                {
                    JsonSerializerSettings settings = new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore,
                        MissingMemberHandling = MissingMemberHandling.Ignore
                    };

                    result = JsonConvert.DeserializeObject<T>(resultText, settings);
                }
                catch (Exception e)
                {
                    Debug.LogError($"[RestClient-SendRequest] ({method}:{url}) Failed to parse response: {e}");
                }

                var response = AsyncRestResponse<T>.FromResult(request.responseCode, result, resultText);

                Debug.Log($"[RestClient-SendRequest] ({method}:{url}) Response: {(response.IsSuccess ? "Success" : "Failed")}");

                return response;
            }
        }
    }
}
