﻿using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using UnityEngine;

namespace Engage.Network
{
    public interface IToken
    {
        [JsonProperty("accessToken", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string AccessToken { get; set; }
    }

    public interface IUser
    {
        [JsonProperty("id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? Id { get; set; }
        string Name { get; set; }
        string UserToken { get; set; }
    }

    public class LoginRequest
    {
        [JsonProperty("user", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string UserName { get; set; }

        [JsonProperty("pwd", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        public string Password { get; set; }

        public LoginRequest(string name, string password)
        {
            UserName = name;
            Password = password;
        }
    }

    public enum AuthenticationState
    {
        Unauthenticated,
        Requesting,
        Authenticated,
        Rejected,
        Error
    }

    public class ApiClientAuthentication : ApiClientModule
    {
        public override string Command => "";

        private const int ENCRYPT_KEY_SIZE = 32;
        public string EncryptionKey => UnityEngine.SystemInfo.deviceUniqueIdentifier.Substring(0, ENCRYPT_KEY_SIZE);

        protected IToken token;
        protected IUser currentUser;

        #region properties
        public virtual Uri LoginUrl => new Uri(ApiDomain, $"{ApiVersion}/oauth/token");
        public virtual Uri RefreshUrl => new Uri(ApiDomain, $"{ApiVersion}/refresh");
        public virtual Uri LogoutUrl => new Uri(ApiDomain, $"{ApiVersion}/logout");

        public override string AuthToken
        {
            get
            {
                if (token == null)
                {
                    return null;
                }

                return token?.AccessToken;
            }
        }
        public virtual IUser CurrentUser => currentUser;
        private AuthenticationState? authenticationStatus;
        public virtual AuthenticationState AuthenticationStatus
        {
            get
            {
                if (!authenticationStatus.HasValue)
                {
                    authenticationStatus = AuthenticationState.Requesting;
                    RequestRefresh();
                }

                return authenticationStatus.Value;
            }
            protected set => authenticationStatus = value;
        }
        #endregion

        public ApiClientAuthentication(ApiClient client) : base(client) { }

        #region public methods
        protected virtual WebRequestBody CreateLoginRequestBody(IUser user, string password)
        {
            var loginRequest = new LoginRequest(user.Name, password);
            return WebRequestBody.GetRequestBody(JsonConvert.SerializeObject(loginRequest));
        }

        public virtual async Task<bool> RequestLogin(IUser user, string password)
        {
            currentUser = user;

            if (string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(user.UserToken))
            {
                password = EncryptionTool.Decrypt(user.UserToken, EncryptionKey);
            }

            var requestBody = CreateLoginRequestBody(user, password);

            try
            {
                var response = await AsyncRestClient.SendRequest<Token>(LoginUrl, Request.Post, body: requestBody);

                if (!response.IsSuccess)
                {
                    AuthenticationStatus = AuthenticationState.Rejected;
                    return false;
                }

                user.UserToken = EncryptionTool.Encrypt(password, EncryptionKey);
                token = response.Result;
                AuthenticationStatus = AuthenticationState.Authenticated;
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                return false;
            }

            return true;
        }

        public virtual async Task<bool> RequestRefresh()
        {
            try
            {
                var response = await AsyncRestClient.SendRequest<Token>(RefreshUrl, Request.Get);

                if (!response.IsSuccess)
                {
                    AuthenticationStatus = AuthenticationState.Rejected;
                    return false;
                }

                token = response.Result;
                AuthenticationStatus = AuthenticationState.Authenticated;
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                return false;
            }

            return true;
        }

        public virtual async Task<bool> RequestLogout()
        {
            try
            {
                var response = await AsyncRestClient.SendRequest(LogoutUrl, Request.Get);

                if (!response.IsSuccess)
                {
                    AuthenticationStatus = AuthenticationState.Rejected;
                    return false;
                }

                token = null;
                currentUser = null;
                AuthenticationStatus = AuthenticationState.Unauthenticated;
            }
            catch (Exception e)
            {
                AuthenticationStatus = AuthenticationState.Error;
                Debug.LogError($"[{nameof(ApiClient)}] Unexpected Request Error: {e}");

                return false;
            }

            return true;
        }
        #endregion
    }
}