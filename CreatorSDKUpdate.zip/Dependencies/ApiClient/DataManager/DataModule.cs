﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement
{
    public abstract class DataModule
    {
        protected abstract string DataKey { get; }
        protected abstract string LastUpdateKey { get; }

        public Action OnCacheChanged;

        public abstract DateTime? LastUpdate { get; protected set; }
        protected DataModule() { }

        public abstract void Clear();
        public abstract void Refresh();
        public abstract Task RefreshAsync();
        protected abstract void InitializeData();
        protected abstract void SaveToCache();
        protected abstract bool ReloadFromCache();
    }

    public abstract class DataModule<I, T> : DataModule where T : class, I, new ()
    {
        protected List<I> DataCache { get; set; } = new List<I>();

        public virtual IList<I> Get() => DataCache;

        public abstract I Get(I item);
        public abstract void Create(I item);
        public abstract void Update(I item);
        public abstract bool Delete(I item);
    }

}
