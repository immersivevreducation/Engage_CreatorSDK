﻿using System;
using System.Collections.Generic;

namespace Engage.AssetManagement
{
    public static class DataManager
    {
        public static T Module<T>() where T : DataModule
        {
            Type moduleType = typeof(T);

            if (!dataModules.TryGetValue(moduleType, out DataModule module))
            {
                module = Activator.CreateInstance(moduleType) as DataModule;
                dataModules.Add(moduleType, module);
            }

            return (T)module;
        }

        public static void Clear()
        {
            foreach (var module in dataModules.Values)
            {
                module.Clear();
            }
        }

        public static void Refresh()
        {
            foreach (var module in dataModules.Values)
            {
                module.Refresh();
            }
        }

        public static void RefreshFromServer()
        {
            foreach (var module in dataModules.Values)
            {
                module.RefreshAsync();
            }
        }


        private static readonly Dictionary<Type, DataModule> dataModules = new Dictionary<Type, DataModule>();
    }
}
