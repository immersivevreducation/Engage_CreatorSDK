﻿using System;

namespace Engage.Network
{
    public struct Host
    {
        public string Environment { get; set; }
        public Uri Domain { get; set; }
        public string ApiVersion { get; set; }

        public bool Equals(Host other)
        {
            return Environment == other.Environment
                && Domain == other.Domain
                && ApiVersion == other.ApiVersion
                ;
        }
    }
}
