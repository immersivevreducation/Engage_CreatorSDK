﻿using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Engage.Network
{
    public enum RequestStatus
    {
        None,
        Requesting,
        Complete,
        Error
    }

    public enum SyncStatus
    {
        Remote = -1,
        None = 0,
        Local = 1,
        UncommittedChanges,
        Synced
    }

    public partial class ApiClient
    {
        protected const string currentHostKey = "Current Host";
        protected Host? host;

        public Host Host
        {
            get
            {
                if (!host.HasValue)
                {
                    if (EditorPrefs.HasKey(currentHostKey))
                    {
                        try
                        {
                            host = JsonConvert.DeserializeObject<Host>(EditorPrefs.GetString(currentHostKey));
                        }
                        catch { }
                    }

                    if (!host.HasValue)
                    {
                        host = new Host();
                    }
                }

                return host.Value;
            }

            set
            {
                if (!host.Equals(value))
                {
                    try
                    {
                        EditorPrefs.SetString(currentHostKey, JsonConvert.SerializeObject(value));
                        host = value;
                    }
                    catch
                    {
                        Debug.LogError($"[{this}.Host] Failed to serialize new host {value}");
                        return;
                    }
                }
            }
        }

        public Uri HostDomain => Host.Domain;
        public string ApiVersion => Host.ApiVersion;

        protected ApiClient() { }
        public static ApiClient CreateApiClient()
        {
            return new ApiClient();
        }

        public static ApiClient CreateApiClient<Auth>() where Auth : ApiClientAuthentication
        {
            var client = new ApiClient();
            var authentication = Activator.CreateInstance(typeof(Auth), client) as ApiClientModule;
            client.modules.Add(typeof(ApiClientAuthentication), authentication);
            return client;
        }

        public Type AuthenticationModule { get; protected set; }

        public Uri GetApiHealthUrl() => new Uri(HostDomain, $"{ApiVersion}/");

        protected Dictionary<Type, ApiClientModule> modules = new Dictionary<Type, ApiClientModule>();

        public T Module<T>() where T : ApiClientModule
        {
            Type moduleType = typeof(T);

            if (!modules.TryGetValue(moduleType, out ApiClientModule module))
            {
                module = Activator.CreateInstance(moduleType, this) as ApiClientModule;
                modules.Add(moduleType, module);
            }

            return (T)module;
        }
    }
}
