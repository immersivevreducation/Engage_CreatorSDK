﻿using System.Collections.Generic;
using System.Linq;

namespace Engage.AssetManagement
{
    public class Glossary : Dictionary<string, string>
    {
        public const string English = "en";
        public const string Korean = "ko";
        public const string German = "de";
        public const string Japanese = "ja";
        public const string French = "fr";
        public const string Spanish = "es";
        public const string Chinese_Simplified = "zh-cn";
        public const string Chinese_Tradition = "zh-hant";

        public string Get(string languageCode)
        {
            TryGetValue(languageCode, out string gloss);

            return gloss;
        }

        public void Set(string languageCode, string value)
        {
            if (ContainsKey(languageCode))
            {
                this[languageCode] = value;
            }
            else
            {
                Add(languageCode, value);
            }
        }

        public void SetValues(Glossary glossary)
        {
            Clear();

            if (glossary == null)
                return;

            foreach (var key in glossary.Keys)
            {
                Add(key, glossary[key]);
            }
        }

        public override string ToString()
        {
            if (Count == 0)
                return string.Empty;

            if (!TryGetValue(English, out string first))
            {
                first = this.First().Value;
            }

            return first;
        }

        public static explicit operator Glossary(string english) => new Glossary() { { English, english } };
        public static implicit operator string(Glossary glossary) => glossary?.ToString();

        public static bool Matches(Glossary glossaryA, Glossary glossaryB)
        {
            if (glossaryA == glossaryB)
                return true;

            if (glossaryA == null && glossaryB.Keys.Count > 0)
                return false;

            if (glossaryB == null && glossaryA.Keys.Count > 0)
                return false;

            if (glossaryA.Keys.Count != glossaryB.Keys.Count)
                return false;

            foreach (var key in glossaryA.Keys)
            {
                if (!glossaryB.ContainsKey(key) || glossaryA[key] != glossaryB[key])
                {
                    return false;
                }
            }

            return true;
        }
    }
}