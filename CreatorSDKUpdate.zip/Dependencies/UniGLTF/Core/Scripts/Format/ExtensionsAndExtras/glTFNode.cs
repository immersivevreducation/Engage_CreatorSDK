﻿using System;


namespace UniGLTF
{
    [Serializable]
    public partial class glTFNode_extensions : ExtensionsBase<glTFNode_extensions> { }

    [Serializable]
    public partial class glTFNode_extra : ExtraBase<glTFNode_extra> { }
}
