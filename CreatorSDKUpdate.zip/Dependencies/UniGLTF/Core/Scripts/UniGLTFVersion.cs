
namespace UniGLTF
{
    public static partial class UniGLTFVersion
    {
        public const int MAJOR = 1;
        public const int MINOR = 27;

        public const string VERSION = "1.27";
    }
}
