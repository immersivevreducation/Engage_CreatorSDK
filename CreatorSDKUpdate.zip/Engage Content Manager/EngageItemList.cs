﻿using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using Engage.UI.Editor;

namespace Engage.AssetManagement.Content
{
    public class EngageItemList : ViewModel { }

    public class EngageItemListView<T, V> : View<V> where T : class, IEngageItem where V : ViewModel, new()
    {
        protected Vector2 scrollPos;

        protected Action onConfirm;
        protected Action onCancel;

        public Action<T> DrawItem { get; set; }
        public Action DrawMessage { get; set; }
        public List<T> Selected { get; } = new List<T>();

        public override void Draw()
        {
            EditorGUILayout.Space();

            using (var messagePanel = new EditorGUILayout.HorizontalScope(GUILayout.MinHeight(60)))
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
                DrawMessage();
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
            }

            EditorGUILayout.Space();

            using (var scrollArea = new GuiTools.ScrollArea(ref scrollPos, EditorStyles.helpBox))
            {
                using (var projectListPanel = new EditorGUILayout.VerticalScope())
                {
                    bool even = true;

                    foreach (var item in Selected)
                    {
                        DrawItemRow(item, even ? CreatorStyle.RowStyleEven : CreatorStyle.RowStyleOdd);

                        even = !even;
                    }
                }
            }

            EditorGUILayout.Space();

            using (var selectionButtons = new EditorGUILayout.HorizontalScope())
            {
                GuiTools.DrawButton(Labels.OK, ConfirmSelection);
                GuiTools.DrawButton(Labels.Cancel, Cancel);
            }
        }

        protected virtual void DrawItemRow(T item, GUIStyle style)
        {
            using (var localScope = new GuiTools.ColorScope(color: item.Id.HasValue ? GUI.contentColor : CreatorStyle.Yellow))
            {
                using (var projectRow = new EditorGUILayout.HorizontalScope(style))
                {
                    DrawItem(item);
                }
            }
        }

        protected void ConfirmSelection()
        {
            onConfirm?.Invoke();
            Close();
        }

        protected void Cancel()
        {
            onCancel?.Invoke();
            Close();
        }
    }
}