﻿using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public static class Icons
    {
        public const string LogoPath = "Assets/ENGAGE_CreatorSDK/Engage Content Manager/ENGAGE Logo B.png";
        public static GUIContent Image => EditorGUIUtility.IconContent("RawImage Icon");

        public static GUIContent Refresh => EditorGUIUtility.IconContent("Refresh");
        public static GUIContent Edit => EditorGUIUtility.IconContent("In-Development");
        public static GUIContent Delete => EditorGUIUtility.IconContent("Delete");
        public static GUIContent Cross => EditorGUIUtility.IconContent("CrossIcon");

        public static GUIContent WindowsLogo => EditorGUIUtility.IconContent("d_BuildSettings.Metro");
        public static GUIContent WindowsLogoSmall => EditorGUIUtility.IconContent("d_BuildSettings.Metro.Small");
        public static GUIContent AndroidLogo => EditorGUIUtility.IconContent("d_BuildSettings.Android");
        public static GUIContent AndroidLogoSmall => EditorGUIUtility.IconContent("d_BuildSettings.Android.Small");
        public static GUIContent iOSLogo => EditorGUIUtility.IconContent("d_BuildSettings.iPhone");
        public static GUIContent iOSLogoSmall => EditorGUIUtility.IconContent("d_BuildSettings.iPhone.Small");
        public static GUIContent MacLogo => EditorGUIUtility.IconContent("d_BuildSettings.Standalone");
        public static GUIContent MacLogoSmall => EditorGUIUtility.IconContent("d_BuildSettings.Standalone.Small");

        public static GUIContent Error => EditorGUIUtility.IconContent("console.erroricon");
        public static GUIContent ErrorSmall => EditorGUIUtility.IconContent("console.erroricon.sml");
        public static GUIContent Invalid => EditorGUIUtility.IconContent("Invalid");
        public static GUIContent Warning => EditorGUIUtility.IconContent("Warning");
        public static GUIContent Installed => EditorGUIUtility.IconContent("Installed");
        public static GUIContent TestPassed => EditorGUIUtility.IconContent("TestPassed");
        public static GUIContent TestSkipped => EditorGUIUtility.IconContent("TestIgnored");


        public static GUIContent GetWaitSpinner(int i) => EditorGUIUtility.IconContent($"WaitSpin{i%12:00}");
        public static GUIContent[] GetWaitSpinner(string tooltip = "")
        {
            var spinner = new GUIContent[12];

            for (int i = 0; i < spinner.Length; i++)
            {
                spinner[i] = EditorGUIUtility.IconContent($"WaitSpin{i:00}", tooltip);
            }

            return spinner;
        }

        public static GUIContent Tooltip (this GUIContent icon, string tooltip)
        {
            icon.tooltip = tooltip;
            return icon;
        }
    }
}