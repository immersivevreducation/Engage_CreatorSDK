﻿using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public class IfxOption : IIfxOption
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public Glossary PrettyName { get; set; }
        public string Value { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
    }

    public class IfxOptionClient : EngageApiClientModule<IfxOption, IIfxOption>
    {
        public override string Command => "ifxoptions";

        public IfxOptionClient(ApiClient client) : base(client) { }
    }
}