﻿using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class LocationAsset : ILocationAsset
    {
        public int? Id { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string Name { get; set; }
        public string UnityResourceName { get; set; }
        public Glossary PrettyName { get; set; }
        public Glossary Description { get; set; }
        public int? BundleId { get; set; }
        public string Image { get; set; }
        public bool? IsPrivate { get; set; }
        public bool? EditorOnly { get; set; }
        public bool? Unlisted { get; set; }
        public int? BaseLocationId { get; set; }
        public int? BrandingGroupId { get; set; }
        public string AssetGuid { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IAssetTag, AssetTag>))]
        public List<IAssetTag> Tags { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IAssetCollection, AssetCollection>))]
        public List<IAssetCollection> Collections { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IGroup, Group>))]
        public List<IGroup> Groups { get; set; }
    }

    public class LocationAssetClient : EngageApiClientModule<LocationAsset, ILocationAsset>
    {
        public override string Command => "scenes";

        public LocationAssetClient(ApiClient client) : base(client) { }

        public virtual Uri ThumbnailUrl(int id) => new Uri(ApiDomain, $"{ApiVersion}/{Command}/{id}/thumbnail");
        public virtual Uri BundlesUrl(int id) => new Uri(ApiDomain, $"{ApiVersion}/{Command}/{id}/bundles");

        /// <summary>
        /// Upload files for the item by ID on the server.
        /// 
        /// POST {api-host}/{command}/{id}/upload
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public virtual async Task<bool> UploadThumbnail(ILocationAsset item, FormData data, Action<float> progressCallback, CancellationToken cancellationToken = default)
        {
            if (item == null)
            {
                Debug.LogError($"[UploadAsync({typeof(ILocationAsset)})] {typeof(ILocationAsset)} argument was null");
                return false;
            }

            if (!item.Id.HasValue)
            {
                Debug.LogError($"[UploadAsync({typeof(ILocationAsset)})] {typeof(ILocationAsset)} argument has no assigned Id value");
                return false;
            }

            try
            {
                var body = WebRequestBody.GetRequestBody(data);

                var response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UploadAsync({typeof(ILocationAsset)})] Id ({item.Id.Value}) Exception while attempting Upload Request: {e}");
            }

            return false;
        }

        /// <summary>
        /// Upload files for the item by ID on the server.
        /// 
        /// POST {api-host}/{command}/{id}/upload
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public virtual async Task<bool> UploadBundle(ILocationAsset item, FormData data, Action<float> progressCallback, CancellationToken cancellationToken = default)
        {
            if (item == null)
            {
                Debug.LogError($"[UploadAsync({typeof(ILocationAsset)})] {typeof(ILocationAsset)} argument was null");
                return false;
            }

            if (!item.Id.HasValue)
            {
                Debug.LogError($"[UploadAsync({typeof(ILocationAsset)})] {typeof(ILocationAsset)} argument has no assigned Id value");
                return false;
            }

            try
            {
                var body = WebRequestBody.GetRequestBody(data);

                var response = await AsyncRestClient.SendRequest(BundlesUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(BundlesUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UploadAsync({typeof(ILocationAsset)})] Id ({item.Id.Value}) Exception while attempting Upload Request: {e}");
            }

            return false;
        }
    }
}