﻿using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public class ThumbnailFormData : FormData
    {
        public static ThumbnailFormData Create(string thumbnailPath)
        {
            var thumbnail = new ThumbnailFormData();
            thumbnail.AddFile(thumbnailPath);

            return thumbnail;
        }
    }
}