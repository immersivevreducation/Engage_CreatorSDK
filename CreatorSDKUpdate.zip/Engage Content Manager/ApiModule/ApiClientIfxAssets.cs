﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Engage.Network;
using System.Threading.Tasks;
using UnityEngine;
using System;
using System.Threading;

namespace Engage.AssetManagement.Content
{
    public class IfxAsset : IIfxAsset
    {
        public int CategoryId { get; set; }
        public string Type { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IIfxOption, IfxOption>))]
        public List<IIfxOption> Options { get; set; }
        public int? Id { get; set; }
        public string Name { get; set; }
        public Glossary Description { get; set; }
        public Glossary PrettyName { get; set; }
        public int? BundleId { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string Image { get; set; }
        public bool? IsPrivate { get; set; }
        public bool? EditorOnly { get; set; }
        public bool? Unlisted { get; set; }
        public string Status { get; set; }
        public string StatusUpdatedAt { get; set; }
        public int? SortOrder { get; set; }
        public string UnityResourceName { get; set; }
        public bool? IsSourceFileManager { get; set; }
        public virtual string AssetGuid { get; set; }


        [JsonConverter(typeof(EngageItemListConverter<IGroup, Group>))]
        public List<IGroup> Groups { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IAssetCollection, AssetCollection>))]
        public List<IAssetCollection> Collections { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IAssetTag, AssetTag>))]
        public List<IAssetTag> Tags { get; set; }
    }

    public class IfxAssetClient : EngageApiClientModule<IfxAsset, IIfxAsset>
    {
        public override string Command => "ifxassets";

        public IfxAssetClient(ApiClient client) : base(client) { }

        public virtual Uri ThumbnailUrl(int id) => new Uri(ApiDomain, $"{ApiVersion}/{Command}/{id}/thumbnail");
        public virtual Uri BundlesUrl(int id) => new Uri(ApiDomain, $"{ApiVersion}/{Command}/{id}/bundles");

        /// <summary>
        /// Upload files for the item by ID on the server.
        /// 
        /// POST {api-host}/{command}/{id}/upload
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public virtual async Task<bool> UploadThumbnail(IIfxAsset item, FormData data, Action<float> progressCallback, CancellationToken cancellationToken = default)
        {
            if (item == null)
            {
                Debug.LogError($"[UploadAsync({typeof(IIfxAsset)})] {typeof(IIfxAsset)} argument was null");
                return false;
            }

            if (!item.Id.HasValue)
            {
                Debug.LogError($"[UploadAsync({typeof(IIfxAsset)})] {typeof(IIfxAsset)} argument has no assigned Id value");
                return false;
            }

            try
            {
                var body = WebRequestBody.GetRequestBody(data);

                var response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UploadAsync({typeof(IIfxAsset)})] Id ({item.Id.Value}) Exception while attempting Upload Request: {e}");
            }

            return false;
        }

        /// <summary>
        /// Upload files for the item by ID on the server.
        /// 
        /// POST {api-host}/{command}/{id}/upload
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public virtual async Task<bool> UploadBundle(IIfxAsset item, FormData data, Action<float> progressCallback, CancellationToken cancellationToken = default)
        {
            if (item == null)
            {
                Debug.LogError($"[UploadAsync({typeof(IIfxAsset)})] {typeof(IIfxAsset)} argument was null");
                return false;
            }

            if (!item.Id.HasValue)
            {
                Debug.LogError($"[UploadAsync({typeof(IIfxAsset)})] {typeof(IIfxAsset)} argument has no assigned Id value");
                return false;
            }

            try
            {
                var body = WebRequestBody.GetRequestBody(data);

                var response = await AsyncRestClient.SendRequest(BundlesUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(BundlesUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UploadAsync({typeof(IIfxAsset)})] Id ({item.Id.Value}) Exception while attempting Upload Request: {e}");
            }

            return false;
        }
    }

}