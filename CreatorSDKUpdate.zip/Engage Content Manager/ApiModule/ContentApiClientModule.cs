﻿using System;
using System.Linq;
using System.Threading.Tasks;
using UnityEngine;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Threading;
using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public abstract class EngageApiClientModule<T, I> : ApiClientModule<T, I> where T : class, I where I : IEngageItem
    {
        protected EngageApiClientModule(ApiClient client) : base(client) { }

        public virtual Uri GetListUrl() => new Uri(ApiDomain, $"{ApiVersion}/{Command}");
        public virtual Uri GetUrl(int id) => new Uri(ApiDomain, $"{ApiVersion}/{Command}/{id}");
        public virtual Uri CreateUrl() => GetListUrl();
        public virtual Uri UpdateUrl(int id) => GetUrl(id);
        public virtual Uri DeleteUrl(int id) => GetUrl(id);

        /// <summary>
        /// Get the list from the server.
        /// 
        /// GET {api-host}/{command}
        /// </summary>
        /// <returns>A list of items</returns>
        public virtual async Task<IList<I>> GetAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await AsyncRestClient.SendRequest<IList<T>>(GetListUrl(), Request.Get, AuthToken);

                if (!response.IsSuccess)
                {
                    if (await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                    {
                        response = await AsyncRestClient.SendRequest<IList<T>>(GetListUrl(), Request.Get, AuthToken);
                    }
                }

                if (response.IsSuccess)
                {
                    return response.Result.ToList<I>();
                }
            }
            catch (ApiException ex)
            {
                Debug.Log($"Request Error: {ex.Message}");
            }

            return new List<I>() { };
        }

        /// <summary>
        /// Get one item by ID from the server.
        /// 
        /// GET {api-host}/{command}
        /// </summary>
        /// <returns>An item</returns>
        public async Task<I> GetAsync(int id, CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await AsyncRestClient.SendRequest<T>(GetUrl(id), Request.Get, AuthToken);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest<T>(GetUrl(id), Request.Get, AuthToken);
                }

                return response.Result;
            }
            catch (ApiException ex)
            {
                Debug.Log($"Get Projects Error: {ex.Message}");
            }

            return default;
        }

        /// <summary>
        /// Create a new item on the server.
        /// 
        /// POST {api-host}/{command}
        /// </summary>
        /// <param name="item"></param>
        /// <returns>The created item</returns>
        public async Task<I> CreateAsync(I item, CancellationToken cancellationToken = default)
        {
            try
            {
                var transducer = new EngageItemTransducer<I>();
                transducer.AddFilter(Property.Get(nameof(Property.CreateAt)));
                transducer.AddFilter(Property.Get(nameof(Property.UpdatedAt)));
                transducer.AddFilter(Property.Get(nameof(Property.StatusUpdatedAt)));

                var json = JsonConvert.SerializeObject(item, transducer);
                var body = WebRequestBody.GetRequestBody(json);
                var response = await AsyncRestClient.SendRequest<T>(CreateUrl(), Request.Post, AuthToken, body);

                if (!response.IsSuccess)
                {
                    if (await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                    {
                        response = await AsyncRestClient.SendRequest<T>(CreateUrl(), Request.Post, AuthToken, body);
                    }

                    if (!response.IsSuccess)
                        Debug.Log($"[ApiClientModule.CreateAsync] Request to create ({typeof(T)} was not Successful: {response.Error})");
                }

                return response.Result;
            }
            catch (Exception e)
            {
                Debug.LogError($"[ApiClientModule.CreateAsync] Exception while attempting Create ({typeof(T)}) Request: {e}");
            }

            return default;
        }

        /// <summary>
        /// Update the item by ID on the server.
        /// 
        /// PATCH {api-host}/{command}/{id}
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public async Task<bool> UpdateAsync(I item, CancellationToken cancellationToken = default)
        {
            if (item == null || !item.Id.HasValue)
            {
                return false;
            }

            try
            {
                var transducer = new EngageItemTransducer<I>();
                transducer.AddFilter(Property.Get(nameof(Property.CreateAt)));
                transducer.AddFilter(Property.Get(nameof(Property.UpdatedAt)));
                transducer.AddFilter(Property.Get(nameof(Property.StatusUpdatedAt)));

                var data = JsonConvert.SerializeObject(item, transducer);
                var body = WebRequestBody.GetRequestBody(data);

                var response = await AsyncRestClient.SendRequest(UpdateUrl(item.Id.Value), Request.Patch, AuthToken, body);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(UpdateUrl(item.Id.Value), Request.Patch, AuthToken, body);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[ApiClientModule.UpdateAsync] Exception while attempting Update (ID {item.Id}) Request: {e}");
            }

            return false;
        }

        /// <summary>
        /// Delete the item by ID on the server.
        /// 
        /// DELETE {api-host}/{command}/{id}
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public async Task<bool> DeleteAsync(I item, CancellationToken cancellationToken = default)
        {
            if (item == null || !item.Id.HasValue)
            {
                return false;
            }

            try
            {
                var response = await AsyncRestClient.SendRequest(DeleteUrl(item.Id.Value), Request.Delete, AuthToken);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(DeleteUrl(item.Id.Value), Request.Delete, AuthToken);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[ApiClientModule.UpdateAsync] Exception while attempting Delete (ID {item.Id}) Request: {e}");
            }

            return false;
        }

        /// <summary>
        /// Upload files for the item by ID on the server.
        /// 
        /// POST {api-host}/{command}/{id}/upload
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        //public virtual async Task<bool> UploadAsync(I item, FormData data, Action<float> progressCallback, CancellationToken cancellationToken = default)
        //{
        //    if (item == null)
        //    {
        //        Debug.LogError($"[UploadAsync({typeof(I)})] {typeof(I)} argument was null");
        //        return false;
        //    }
            
        //    if (!item.Id.HasValue)
        //    { 
        //        Debug.LogError($"[UploadAsync({typeof(I)})] {typeof(I)} argument has no assigned Id value");
        //        return false;
        //    }

        //    try
        //    {
        //        var body = WebRequestBody.GetRequestBody(data);

        //        var response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);

        //        if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
        //        {
        //            response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);
        //        }

        //        return response.IsSuccess;
        //    }
        //    catch (Exception e)
        //    {
        //        Debug.LogError($"[UploadAsync({typeof(I)})] Id ({item.Id.Value}) Exception while attempting Upload Request: {e}");
        //    }

        //    return false;
        //}
    }
}