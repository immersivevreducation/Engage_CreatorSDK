﻿using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public class BundleFileFormData : FormData
    {
        public enum AssetType
        {
            Mixed = -1,
            Undefined = 0,
            Location = 1,
            IFX = 2,
            Snapshot
        }

        public enum Platform
        {
            Undefined = 0,
            Windows = 1,
            Android = 2,
            iOS = 3,
            OSX = 4,
        }

        public const string AssetKey = "type";
        public const string PlatformKey = "platform";

        public void AddAssetTypeSection(AssetType type) => AddText(AssetKey, $"{(int)type}");
        public void AddPlatformSection(Platform platform) => AddText(PlatformKey, $"{(int)platform}");

        public static BundleFileFormData Create(AssetType type, Platform platform, string bundlePath, string manifestPath)
        {
            var bundlePackage = new BundleFileFormData();
            bundlePackage.AddAssetTypeSection(type);
            bundlePackage.AddPlatformSection(platform);
            bundlePackage.AddFile(bundlePath);
            bundlePackage.AddFile(manifestPath);

            return bundlePackage;
        }
    }
}