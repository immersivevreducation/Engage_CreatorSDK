﻿using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public class AssetTag : IAssetTag
    {
        public int? Id { get; set; }
        public Glossary Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string Slug { get; set; }
    }

    public class AssetTagClient : EngageApiClientModule<AssetTag, IAssetTag>
    {
        public override string Command => "tags";

        public AssetTagClient(ApiClient client) : base(client) { }
    }
}