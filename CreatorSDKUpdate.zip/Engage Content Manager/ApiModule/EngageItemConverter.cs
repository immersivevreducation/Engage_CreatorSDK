﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class EngageItemConverter<I, T> : JsonConverter where T : I, new ()
    {
        public override bool CanWrite => false;
        public override bool CanRead => true;
        public override bool CanConvert(Type objectType) => objectType is I;

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var item = new T();

            try
            {
                var jsonObject = JObject.Load(reader);
                serializer.Populate(jsonObject.CreateReader(), item);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError(ex);
            }

            return item;
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }

    public class EngageItemListConverter<I, T> : EngageItemConverter<I, T> where T : I, new()
    {
        public override bool CanConvert(Type objectType) => objectType == typeof(List<I>);

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            var groups = new List<I>();

            try
            {
                var jsonArray = JArray.Load(reader);

                foreach (JObject jsonObject in jsonArray)
                {
                    var item = new T();
                    serializer.Populate(jsonObject.CreateReader(), item);
                    groups.Add(item);
                }

            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError(ex);
            }

            return groups;
        }
    }

    // TODO: Create constructor which will take the list of updates to filter the output json.
    public class EngageItemTransducer<I> : JsonConverter
    {
        protected List<string> propertyFilters { get; } = new List<string>();

        public override bool CanRead => false;
        public override bool CanWrite => true;
        public override bool CanConvert(Type objectType) => new List<Type>(objectType.GetInterfaces()).Contains(typeof(I));

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer) => throw new NotImplementedException();

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            var token = JToken.FromObject(value);

            if (token.Type != JTokenType.Object)
            {
                token.WriteTo(writer);
            }
            else
            {
                var engageItem = (JObject)token;

                foreach (var property in engageItem.Properties())
                {
                    if (property.Value.Type == JTokenType.Array)
                    {
                        var jArray = (JArray)property.Value;
                        var idList = new List<JToken>();

                        foreach (var item in jArray)
                        {
                            var itemObject = (JObject)item;

                            idList.Add(itemObject[Property.Get(nameof(Property.Id))]);
                        }

                        jArray.Clear();

                        foreach (var id in idList)
                        {
                            jArray.Add(id);
                        }
                    }
                }

                foreach(var property in propertyFilters)
                {
                    engageItem.Remove(property);
                }



                engageItem.WriteTo(writer);
            }
        }

        public void AddFilter(string property)
        {
            propertyFilters.Add(property);
        }
    }

}