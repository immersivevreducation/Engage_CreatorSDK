﻿using Engage.Network;
using Newtonsoft.Json;
using System;

namespace Engage.AssetManagement.Content
{
    public interface IEngageUser : IUser
    {
        [JsonProperty("username", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Username { get; }
        [JsonProperty("email", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Email { get; }
        [JsonProperty("first_name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string FirstName { get; }
        [JsonProperty("last_name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string LastName { get; }

        [JsonProperty("uuid", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        Guid Uuid { get; }
        [JsonProperty("default_group_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? DefaultGroupId { get; }
        [JsonProperty("subscription_type", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string SubscriptionType { get; }
        [JsonProperty("type", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Type { get; }
        [JsonProperty("is_group_admin", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        bool? isGroupAdmin { get; }

        [JsonProperty("verified", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? Verified { get; }
        [JsonProperty("country_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? CountryId { get; }
        [JsonProperty("timezone_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? TimezoneId { get; }
        [JsonProperty("gender", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Gender { get; }
        //roles
    }

}
