﻿using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class AssetCollection : IAssetCollection
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string PrettyName { get; set; }
        public int UserId { get; set; }
        public string Image { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IGroup, Group>))]
        public List<IGroup> Groups { get; } = new List<IGroup>();
    }

    public class AssetCollectionClient : EngageApiClientModule<AssetCollection, IAssetCollection>
    {
        public override string Command => "collections";
        public AssetCollectionClient(ApiClient client) : base(client) { }

        public virtual Uri ThumbnailUrl(int id) => new Uri(ApiDomain, $"{ApiVersion}/{Command}/{id}/upload");

        /// <summary>
        /// Upload files for the item by ID on the server.
        /// 
        /// POST {api-host}/{command}/{id}/upload
        /// </summary>
        /// <param name="item"></param>
        /// <returns>Boolean representing success of operation.</returns>
        public virtual async Task<bool> UploadThumbnail(IAssetCollection item, FormData data, Action<float> progressCallback, CancellationToken cancellationToken = default)
        {
            if (item == null)
            {
                Debug.LogError($"[UploadAsync({typeof(IAssetCollection)})] {typeof(IAssetCollection)} argument was null");
                return false;
            }

            if (!item.Id.HasValue)
            {
                Debug.LogError($"[UploadAsync({typeof(IAssetCollection)})] {typeof(IAssetCollection)} argument has no assigned Id value");
                return false;
            }

            try
            {
                var body = WebRequestBody.GetRequestBody(data);

                var response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest(ThumbnailUrl(item.Id.Value), Request.Post, AuthToken, body, onUploadProgress: progressCallback);
                }

                return response.IsSuccess;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UploadAsync({typeof(IAssetCollection)})] Id ({item.Id.Value}) Exception while attempting Upload Request: {e}");
            }

            return false;
        }
    }
}