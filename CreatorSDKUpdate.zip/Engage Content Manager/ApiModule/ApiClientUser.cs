﻿using Engage.Network;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class UserDetails : IEngageUser
    {
        public string Name { get; set; }
        public string UserToken { get; set; }

        public int? Id { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }

        public string Username{ get; set; }
        public string Email{ get; set; }
        public string FirstName{ get; set; }
        public string LastName{ get; set; }

        public Guid Uuid{ get; set; }
        public int? DefaultGroupId{ get; set; }
        public string SubscriptionType{ get; set; }
        public string Type{ get; set; }
        public bool? isGroupAdmin{ get; set; }

        public int? Verified{ get; set; }
        public int? CountryId{ get; set; }
        public int? TimezoneId{ get; set; }
        public string Gender{ get; set; }

        public UserDetails(string name)
        {
            Name = name;
        }
    }

    public class UserClient : ApiClientModule<UserDetails, IEngageUser>
    {
        public override string Command => "user";

        public virtual Uri GetUserDetailsUrl() => new Uri(ApiDomain, $"api/{Command}/me");

        public UserClient(ApiClient client) : base(client) { }

        public async Task<UserDetails> GetDetailsAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                var response = await AsyncRestClient.SendRequest<UserDetails>(GetUserDetailsUrl(), Request.Get, AuthToken);

                if (!response.IsSuccess && await ApiClient.Module<ApiClientAuthentication>().RequestRefresh())
                {
                    response = await AsyncRestClient.SendRequest<UserDetails>(GetUserDetailsUrl(), Request.Get, AuthToken);
                }

                return response.Result;
            }
            catch (ApiException ex)
            {
                UnityEngine.Debug.Log($"Get Projects Error: {ex.Message}");
            }

            return default;
        }
    }

}
