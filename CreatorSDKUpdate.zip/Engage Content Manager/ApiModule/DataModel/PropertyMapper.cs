﻿namespace Engage.AssetManagement.Content
{
    public static class Property
    {
        // IEngageItem
        public const string Id = "id";
        public const string CreateAt = "created_at";
        public const string UpdatedAt = "updated_at";

        // INamedItem
        public const string Name = "name";

        // IAsset
        public const string StatusUpdatedAt = "status_updated_at";
        public const string Collections = "collections";
        public const string Tags = "tags";

        // ISceneAsset
        public const string SceneScale = "scene_scale";
        public const string BaseLocationId = "base_scene_id";
        public const string BrandingGroupId = "branding_group_id";

        // IIfxAsset
        public const string CategoryId = "category_id";
        public const string Type = "type";
        public const string Options = "ifx_options";

        public const string Groups = "groups";

        public static string Get(string name)
        {
            var property = typeof(Property).GetField(name);

            return property?.GetValue(null).ToString();
        }
    }
}
