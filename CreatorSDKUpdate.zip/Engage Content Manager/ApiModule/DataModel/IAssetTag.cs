﻿using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface IAssetTag : IEngageItem
    {
        [JsonProperty("name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        Glossary Name { get; }
    }
}