﻿using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface INamedItem
    {
        [JsonProperty("name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Name { get; }
    }
}