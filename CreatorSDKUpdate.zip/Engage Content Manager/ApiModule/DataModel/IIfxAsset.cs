﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface IIfxAsset : IAsset
    {
        [JsonProperty("category_id", Required = Required.Always)]
        int CategoryId { get; }

        [JsonProperty("type", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Type { get; }

        [JsonProperty("ifx_options", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        List<IIfxOption> Options { get; }
    }

}