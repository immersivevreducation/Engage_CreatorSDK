﻿using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface IEngageItem
    {
        [JsonProperty("id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? Id { get; }

        [JsonProperty("created_at", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string CreatedAt { get; }

        [JsonProperty("updated_at", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string UpdatedAt { get; }
    }
}