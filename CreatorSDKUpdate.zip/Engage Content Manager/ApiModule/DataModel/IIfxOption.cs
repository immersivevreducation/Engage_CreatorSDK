﻿using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface IIfxOption : IEngageItem, INamedItem
    {
        [JsonProperty("pretty_name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        Glossary PrettyName { get; }

        [JsonProperty("value", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Value { get; }
    }
}