﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public interface IAssetCollection : IEngageItem, INamedItem
    {
        [JsonProperty("pretty_name", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string PrettyName { get; }

        [JsonProperty("user_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int UserId { get; }

        [JsonProperty("image", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        string Image { get; }

        [JsonProperty("groups", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        List<IGroup> Groups { get; }
    }
}