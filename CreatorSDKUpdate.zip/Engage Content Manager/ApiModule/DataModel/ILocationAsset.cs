﻿using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public interface ILocationAsset : IAsset
    {
        [JsonProperty("base_scene_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? BaseLocationId { get; }

        [JsonProperty("branding_group_id", Required = Required.Default, NullValueHandling = NullValueHandling.Ignore)]
        int? BrandingGroupId { get; }
    }
}