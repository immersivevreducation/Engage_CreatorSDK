﻿namespace Engage.AssetManagement.Content
{
    public interface IGroup : IEngageItem, INamedItem
    {
    }
}