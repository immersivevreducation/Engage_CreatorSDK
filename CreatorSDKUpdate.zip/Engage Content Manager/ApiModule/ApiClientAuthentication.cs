﻿using Engage.Network;
using Newtonsoft.Json;

namespace Engage.AssetManagement.Content
{
    public class ApiClientAuthentication : Network.ApiClientAuthentication
    {
        public struct LoginRequest
        {
            public string email;
            public string password;

            public LoginRequest(string user, string pwd)
            {
                email = user;
                password = pwd;
            }
        }

        public override IUser CurrentUser
        {
            get
            {
                if (currentUser == null)
                {
                    currentUser = new UserDetails("");
                }

                return currentUser;
            }
        }

        public ApiClientAuthentication(ApiClient client) : base(client) { }

        protected override WebRequestBody CreateLoginRequestBody(IUser user, string password)
        {
            var loginRequest = new LoginRequest(user.Name, password);
            var loginJson = JsonConvert.SerializeObject(loginRequest);
            return WebRequestBody.GetRequestBody(loginJson);
        }
    }
}
