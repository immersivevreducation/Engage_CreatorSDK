﻿using Engage.Network;

namespace Engage.AssetManagement.Content
{
    public class Group : IGroup
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
    }

    public class GroupClient : EngageApiClientModule<Group, IGroup>
    {
        public override string Command => "memberships";
        public GroupClient(ApiClient client) : base(client) { }
    }
}