﻿using UnityEngine;
using UnityEditor;
using System;
using System.Collections.Generic;
using Engage.UI.Editor;

namespace Engage.AssetManagement.Content
{
    public class EngageItemSelectorView<T, V> : View<V> where T : class, IEngageItem where V : ViewModel, IEngageItemManager<T>, new ()
    {
        protected Vector2 scrollPos;
        protected Action<T> onSelectionMade;

        protected HashSet<int> currentIds = new HashSet<int>();
        protected HashSet<int> selectedIds = new HashSet<int>();

        protected string search;

        public bool SelectionMade => selectedIds.Count > 0;
        public bool Multiselect { get; set; }

        public static void SelectOne(string title, Action<T> selectionCallback, T[] selected = null)
        {
            var window = GetWindow<EngageItemSelectorView<T, V>>(title: title);
            window.onSelectionMade = selectionCallback;
            window.Multiselect = false;

            if (selected != null)
            {
                foreach(T item in selected)
                {
                    window.currentIds.Add(item.Id.Value);
                }
            }

            window.Show();
        }

        public static void SelectMultiple(string title, Action<T> selectionCallback, T[] selected = null)
        {
            var window = GetWindow<EngageItemSelectorView<T, V>>(title: title);
            window.onSelectionMade = selectionCallback;
            window.Multiselect = true;

            if (selected != null)
            {
                foreach(T item in selected)
                {
                    window.currentIds.Add(item.Id.Value);
                }
            }

            window.Show();
        }

        public override void Draw()
        {
            ViewTools.DrawEnvironmentHeader();

            EditorGUILayout.Space();

            GuiTools.DrawSearchBar(ref search);

            using (var scrollArea = new GuiTools.ScrollArea(ref scrollPos, EditorStyles.helpBox))
            {
                using (var projectListPanel = new EditorGUILayout.VerticalScope())
                {
                    bool even = true;

                    foreach (var item in ViewModel.ItemDisplayList)
                    {
                        if (string.IsNullOrEmpty(search) || item.ToString().IndexOf(search, StringComparison.InvariantCultureIgnoreCase) > -1)
                        {
                            DrawSelectableRow(item, even ? CreatorStyle.RowStyleEven : CreatorStyle.RowStyleOdd);
                        }

                        even = !even;
                    }
                }
            }

            EditorGUILayout.Space();

            ViewTools.DrawRefreshFromServerPanel(ViewModel);

            EditorGUILayout.Space();

            if (Multiselect)
            {
                using (var selectionButtons = new EditorGUILayout.HorizontalScope())
                {
                    using (var selectionMade = new GuiTools.EnabledScope(SelectionMade))
                    {
                        GuiTools.DrawButton(Labels.Select, MakeSelection);
                    }
                    GuiTools.DrawButton(Labels.Cancel, SelectionComplete);
                }
            }
        }

        protected virtual void DrawSelectableRow(T item, GUIStyle style)
        {
            using (var localScope = new GuiTools.ColorScope(
                color: item.Id.HasValue ? GUI.contentColor : CreatorStyle.Yellow,
                backgroundColor: item.Id.HasValue && currentIds.Contains(item.Id.Value) ? CreatorStyle.Green : GUI.contentColor))
            {
                using (var projectRow = new EditorGUILayout.HorizontalScope(style))
                {
                    if (item.Id.HasValue)
                    {
                        int itemId = item.Id.Value;

                        if (GUI.Button(projectRow.rect, GUIContent.none, style))
                        {
                            if (Multiselect)
                            {
                                if (currentIds.Add(itemId))
                                {
                                    selectedIds.Add(itemId);
                                }
                                else
                                {
                                    if (selectedIds.Remove(itemId))
                                        currentIds.Remove(itemId);
                                }
                            }
                            else
                            {
                                if (currentIds.Add(item.Id.Value))
                                {
                                    onSelectionMade?.Invoke(item);
                                    SelectionComplete();
                                }
                            }
                        }
                    }

                    EditorGUILayout.LabelField(item.ToString());
                }
            }
        }

        protected void MakeSelection()
        {
            foreach (var item in ViewModel.ItemDisplayList)
            {
                if (item.Id.HasValue && selectedIds.Contains(item.Id.Value))
                {
                    onSelectionMade?.Invoke(item);
                }
            }

            SelectionComplete();
        }

        protected void SelectionComplete()
        {
            currentIds.Clear();
            selectedIds.Clear();
            onSelectionMade = null;
            Close();
        }
    }
}