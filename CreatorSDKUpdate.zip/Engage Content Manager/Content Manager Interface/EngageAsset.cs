﻿using Engage.CreatorSDK;
using Engage.Network;
using Engage.UI.Editor;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public enum AssetProblem
    {
        None,
        IllegalCharacters,
        DuplicateName
    }

    public enum AssetStatus
    {
        Rejected = -1,
        Draft = 0,
        Review = 1,
        Approved = 2,
    }

    /// <summary>
    /// View model for the data needed for interacting with compiled IFX & Location Bundles.
    /// </summary>
    public abstract class EngageAsset : ViewModel, IAsset
    {
        public override string ToString() => PrettyName;

        protected virtual IAsset Asset { get; set; }

        private string name;
        protected DateTime? created;
        protected DateTime? updated;
        private AssetPrivacy? privacy;

        #region IEngageItem Properties
        public virtual int? Id { get => Asset.Id; }
        public virtual string CreatedAt { get => created?.ToString("yyyy-MM-dd") ?? "-"; }
        public virtual string UpdatedAt { get => updated?.ToString("yyyy-MM-dd") ?? CreatedAt; }
        #endregion

        #region IAsset Properties

        public virtual string Name { get => name; set => name = value; }
        public virtual string UnityResourceName { get; set; }
        public Glossary PrettyName { get; } = new Glossary();
        public Glossary Description { get; } = new Glossary();

        public virtual int? BundleId { get; }
        public virtual string Image { get; set; } = "";

        public virtual bool? IsPrivate { get; set; }
        public virtual bool? EditorOnly { get; set; }
        public virtual bool? Unlisted { get; set; }

        public virtual string AssetGuid { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IAssetTag, AssetTagData>))]
        public List<IAssetTag> Tags { get; set; } = new List<IAssetTag>();

        [JsonConverter(typeof(EngageItemListConverter<IAssetCollection, AssetCollectionData>))]
        public List<IAssetCollection> Collections { get; set; } = new List<IAssetCollection>();

        [JsonConverter(typeof(EngageItemListConverter<IGroup, GroupData>))]
        public List<IGroup> Groups { get; set; } = new List<IGroup>();
        #endregion

        #region Other Properties
        protected string localThumbnailPath;
        public string LocalThumbnailPath
        {
            get => localThumbnailPath;
            set
            {
                localThumbnailPath = value;
                NotifyPropertyChange(nameof(LocalThumbnailPath));
            }
        }

        public AssetProblem Problem { get; protected set; }
        public bool HasProblem => Problem != AssetProblem.None;
        #endregion

        #region Management Status
        protected RequestStatus requestStatus = RequestStatus.None;
        public RequestStatus RequestStatus
        {
            get => requestStatus;
            protected set
            {
                requestStatus = value;
                NotifyPropertyChange(nameof(RequestStatus));
            }
        }
        public float Progress { get; protected set; }

        protected SyncStatusManager syncStatusManager;
        public SyncStatusManager Sync
        {
            get
            {
                if (syncStatusManager == null)
                {
                    InitializeSyncStatusManager();
                }

                return syncStatusManager;
            }
        }
        protected virtual void InitializeSyncStatusManager()
        {
            syncStatusManager = new SyncStatusManager();
            syncStatusManager.OnStatusChanged += NotifyPropertyChange;

            syncStatusManager.RegisterProperty(nameof(Name), () => Name != Asset.Name);
            syncStatusManager.RegisterProperty(nameof(PrettyName), () => !Glossary.Matches(PrettyName, Asset.PrettyName));
            syncStatusManager.RegisterProperty(nameof(Description), () => !Glossary.Matches(Description, Asset.Description));
            syncStatusManager.RegisterProperty(nameof(IsPrivate), () => IsPrivate != Asset.IsPrivate);
            syncStatusManager.RegisterProperty(nameof(EditorOnly), () => EditorOnly != Asset.EditorOnly);
            syncStatusManager.RegisterProperty(nameof(Unlisted), () => Unlisted != Unlisted);

            syncStatusManager.RegisterCollection(nameof(Tags),
                () => !Enumerable.SequenceEqual(Tags, Asset.Tags),
                (IAssetTag item) => !Asset.Tags.Any(tag => tag.Id == item.Id));

            syncStatusManager.RegisterCollection(nameof(Collections),
                () => !Enumerable.SequenceEqual(Collections, Asset.Collections),
                (IAssetCollection item) => !Asset.Collections.Any(collection => collection.Id == item.Id));

            syncStatusManager.RegisterCollection(nameof(Groups),
                () => !Enumerable.SequenceEqual(Groups, Asset.Groups),
                (IGroup item) => !Asset.Collections.Any(group => group.Id == item.Id));
        }
        #endregion

        #region Constructors
        public EngageAsset() { }
        #endregion

        public virtual void Reset()
        {
            if (Asset == null)
            {
                return;
            }

            Name = Asset.Name;
            UnityResourceName = Asset.UnityResourceName;

            PrettyName.SetValues(Asset.PrettyName);
            Description.SetValues(Asset.Description);

            created = DateTime.TryParse(Asset.CreatedAt, out DateTime createdAt) ? createdAt : (DateTime?)null;
            updated = DateTime.TryParse(Asset.UpdatedAt, out DateTime updatedAt) ? updatedAt : (DateTime?)null;

            Image = Asset.Image;

            IsPrivate = Asset.IsPrivate;
            EditorOnly = Asset.EditorOnly;
            Unlisted = Asset.Unlisted;

            Tags.Clear();
            Tags.AddRange(Asset.Tags);

            Collections.Clear();
            Collections.AddRange(Asset.Collections);

            Groups.Clear();
            Groups.AddRange(Asset.Groups);
        }

        public AssetPrivacy Privacy
        {
            get
            {
                if (!privacy.HasValue)
                {
                    if (IsPrivate.HasValue && !IsPrivate.Value)
                    {
                        privacy = AssetPrivacy.Public;
                    }
                    else
                    {
                        privacy = AssetPrivacy.Private;
                    }
                }

                return privacy.Value;
            }
        }

        public virtual void AddTag(IAssetTag assetTag)
        {
            if (Tags.Contains(assetTag) || Tags.Any(tag => tag.Id.HasValue && tag.Id == assetTag.Id))
            {
                return;
            }

            Tags.Add(assetTag);
            NotifyPropertyChange(nameof(Tags));
        }

        public virtual void RemoveTag(IAssetTag assetTag)
        {
            if (!Tags.Remove(assetTag))
            {
                Tags.RemoveAll(tag => tag.Id.HasValue && tag.Id == assetTag.Id);
            }
        }

        public virtual void AddCollection(IAssetCollection assetCollection)
        {
            if (Collections.Contains(assetCollection) || Collections.Any(collection => collection.Id.HasValue && collection.Id == assetCollection.Id))
            {
                return;
            }

            Collections.Add(assetCollection);
            NotifyPropertyChange(nameof(Collections));
        }

        public virtual void RemoveCollection(IAssetCollection assetCollection)
        {
            if (!Collections.Remove(assetCollection))
            {
                Collections.RemoveAll(collection => collection.Id.HasValue && collection.Id == assetCollection.Id);
            }
        }

        public virtual void AddGroup(IGroup group)
        {
            if (Groups.Contains(group) || Groups.Any(userGroup => userGroup.Id.HasValue && userGroup.Id == group.Id))
            {
                return;
            }

            Groups.Add(group);
            NotifyPropertyChange(nameof(Groups));
        }

        public virtual void RemoveGroup(IGroup group)
        {
            if (!Groups.Remove(group))
            {
                Groups.RemoveAll(userGroup => userGroup.Id.HasValue && userGroup.Id == group.Id);
            }
        }

        public abstract void Save();

        public abstract void CreateAsset();
        public abstract Task CreateAssetAsync();
        public abstract void UpdateAsset();
        public abstract Task UpdateAssetAsync();

        public abstract void UploadThumbnail();
        public abstract void UploadThumbnail(Action<float> progressCallback, Action<bool> onComplete = null);
        public abstract void UploadBundle(EngagePlatform platform, BundleFile localFile, Action<BundleFile, float> update, Action<BundleFile, bool> onComplete = null);
        public virtual void UploadBundle(EngagePlatform platform, BundleFile localFile)
        {
            UploadBundle(platform, localFile, (bundle, progress) => NotifyPropertyChange(nameof(UploadBundle)), (bundle, success) => NotifyPropertyChange(nameof(UploadBundle)));
        }
        public abstract void UploadAllBundles();
        public abstract void UploadAllBundles(Action update);

        public abstract void DeleteAsset();
    }
}