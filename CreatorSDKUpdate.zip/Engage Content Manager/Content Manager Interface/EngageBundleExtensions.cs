﻿using Engage.CreatorSDK;
using Engage.Network;
using Engage.UI.Editor;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class BundleFilePanelStatus
    {
        public bool ExpandPanel;
        public Vector2 PanelScrollPos;

        public class PlatformStatus
        {
            public bool Expand;
            public Vector2 ScrollPos;
        }

        private Dictionary<EngagePlatform, PlatformStatus> platformStatus = new Dictionary<EngagePlatform, PlatformStatus>()
        {
            { EngagePlatform.Windows, new PlatformStatus() },
            { EngagePlatform.Android, new PlatformStatus() },
            { EngagePlatform.iOS, new PlatformStatus() },
            { EngagePlatform.OSX, new PlatformStatus() }
        };

        public PlatformStatus this[EngagePlatform platform]
        {
            get
            {
                if (!platformStatus.ContainsKey(platform))
                {
                    platformStatus.Add(platform, new PlatformStatus());
                }

                return platformStatus[platform];
            }
            set
            {
                if (platformStatus.ContainsKey(platform))
                {
                    platformStatus[platform] = value;
                }
                else
                {
                    platformStatus.Add(platform, value);
                }
            }
        }
    }
}