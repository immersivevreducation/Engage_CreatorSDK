using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using Engage.CreatorSDK;
using System.IO;
using System.Collections.Generic;
using System;

namespace Engage.AssetManagement.Content
{
    public class IfxBuilderView : View<IfxBuilder>
    {
        private Vector2 scrollPos;
        private const float verticalSpace = 20f;
        public bool showSpinner;
        private int frame;
        private int ticks;
        private bool buildStarted;
        private IfxStatusPanel ifxBuildStatusPanel;
        private Texture logo;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.LogoPath);
                }

                return logo;
            }
        }

        private string LocalThumbnailPath
        {
            get
            {
                if (localThumbnail == null && !string.IsNullOrEmpty(ViewModel.LocalThumbnail))
                {
                    UpdateLocalThumbnail(ViewModel.LocalThumbnail);
                }

                return ViewModel.LocalThumbnail;
            }
            set
            {
                if (ViewModel.LocalThumbnail == value)
                    return;

                ViewModel.LocalThumbnail = value;
                UpdateLocalThumbnail(ViewModel.LocalThumbnail);
            }
        }

        private Texture2D localThumbnail;

        private IfxStatusPanel IfxBuildStatusPanel
        {
            get
            {
                if (ifxBuildStatusPanel == null)
                {
                    ifxBuildStatusPanel = new IfxStartState(this);
                }

                return ifxBuildStatusPanel;
            }

            set
            {
                ifxBuildStatusPanel = value;
            }
        }

        private class Labels : Content.Labels
        {
            public const string MenuTitle = "Build ENGAGE Ifx";
            public const string ViewTitle = " Ifx Builder";
            public const string Build = "Build Ifx";
            public const string Rebuild = "Rebuild Ifx";
            public const string ThumbnailSelect = "Select\nThumbnail";

            // TODO: Get some real label values
            public const string ConfirmBuildTitle = "Build Ifx?";
            public const string ConfirmBuildMessage = "We're going to build this IFX now. OK?";

            public const string EmptySelection = "--";

            public const string BatchBuildMode = "Batch Build Mode";
            public const string BatchBuildTooltip = "Batch build mode will create duplicate copies of the project and run the bundle build process in parallel";

            public const string LocalBuildPath = "Local Build Path";
            public const string Prefab = "Prefab";
            public const string PrefabNoneSelected = "No prefab selected";
            public const string PrefabNoneSelectedMessage = "Please select a Unity prefab to build as an ENGAGE IFX";
            public const string BuildModuleNotInstalledMessage = "Module is not installed";

            public const string Save = "Save";
            public const string SaveTooltip = "Save your IFX settings locally without uploading.";

            public const string ThumbnailSelectTitle = "Select Thumbnail Image";
            public const string ThumbnailSelectTooltip = "Select thumbnail image";
            public const string ThumbnailSpecification = "Thumbnail images should be jpeg\nor png, and 750 x 500 pixels.";

            public const string PrefabSelected = "Prefab Selected";
            public const string RebuildIfxConditionTooltip = "To rebuild this IFX, select a prefab.";
            public const string Bundles = "Bundles";
            public const string ThumbnailUploaded = "Thumbnail Uploaded";

            public const string UpdateIfxTooltip = "Update the details for this IFX.";
            public const string RebuildAndUpdateIfxTooltip = "Rebuild and update this IFX.";

            public const string BuildIfxTooltip = "Build and upload this IFX.";
            public const string LoginTooltip = "You must log with your authorized ENGAGE User account.";

            public const string Building = "Building...";
            public const string Uploading = "Uploading...";
            public const string Done = "Done";

            public const string IfxStatus = "Ifx Status";
            public const string IfxUpdated = "Ifx Updated";
            public const string IfxCreated = "Ifx Created";
        }

        private Dictionary<EngagePlatform, GUIContent> platformIcons;
        public Dictionary<EngagePlatform, GUIContent> PlatformIcons
        {
            get
            {
                platformIcons = new Dictionary<EngagePlatform, GUIContent>()
                {
                    { EngagePlatform.Windows, Icons.WindowsLogoSmall },
                    { EngagePlatform.Android, Icons.AndroidLogoSmall },
                    { EngagePlatform.iOS, Icons.iOSLogoSmall },
                    { EngagePlatform.OSX, Icons.MacLogoSmall }
                };
                return platformIcons;
            }
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            titleContent = new GUIContent(Labels.ViewTitle, Logo);
        }

        [MenuItem(MenuLabels.AssetsToolsPath + Labels.MenuTitle, priority = MenuLabels.BuildViewPriority + 1)]
        [MenuItem(MenuLabels.CreatorSDKToolsPath + Labels.MenuTitle, priority = MenuLabels.BuildViewPriority + 1)]
        public static void OpenView()
        {
            var window = GetWindow<IfxBuilderView>();
            window.Open();
        }
        
        public static void Edit(EngageIFX ifx)
        {
            var window = GetWindow<IfxBuilderView>();
            window.ViewModel.Edit(ifx);
            window.Open();
        }

        #region Unity Events
        protected override void OnGUI()
        {
            base.OnGUI();

            if (Event.current.commandName == "ObjectSelectorClosed")
            {
                var prefab = EditorGUIUtility.GetObjectPickerObject() as GameObject;

                if (prefab == null)
                    return;

                Debug.Log($"Selected prefab [{prefab}]");
                ViewModel.LoadUnityPrefab(prefab);
            }
        }

        protected virtual void Update()
        {
            if (showSpinner)
            {
                ticks++;

                if (ticks > 20)
                {
                    ticks = 0;
                    frame++;
                }

                Repaint();
            }
        }
        #endregion

        protected override void Initialize()
        {
            base.Initialize();

            IfxBuildStatusPanel = new IfxStartState(this);
        }

        public override void Draw()
        {
            ViewTools.DrawEnvironmentHeader();

            EditorGUILayout.Space();

            DrawBuildJob(ViewModel.Job);

            EditorGUILayout.Space();

            EditorGUILayout.Space();

            using (var enableEditing = new GuiTools.EnabledScope(!(IfxBuildStatusPanel is IfxStartState)))
            {

                using (var textArea = new EditorGUILayout.VerticalScope())
                {
                    // Pretty Name field
                    ViewModel.PrettyName = EditorGUILayout.TextField(Labels.Name, ViewModel.PrettyName);

                    EditorGUILayout.Space();

                    // Description field
                    ViewModel.Description = EditorGUILayout.TextField(Labels.Description, ViewModel.Description);

                    EditorGUILayout.Space();
                }

                //Thumbnail field
                var thumbnail = string.IsNullOrEmpty(LocalThumbnailPath) ? Icons.Image : new GUIContent(localThumbnail);
                thumbnail.tooltip = (string.IsNullOrEmpty(ViewModel.LocalThumbnail) ? Labels.ThumbnailSelectTooltip : ViewModel.LocalThumbnail) + "\n\n" + Labels.ThumbnailSpecification;

                if (GUILayout.Button(thumbnail, GUILayout.Height(100), GUILayout.Width(150)))
                {
                    SelectThumbnail();
                }

                EditorGUILayout.Space();

                // Groups field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Groups), ViewModel.Groups, (IGroup group) => group.Name, ViewModel.RemoveGroup, GroupSelectorView.SelectMultiple, ViewModel.AddGroup);

                EditorGUILayout.Space();

                // Collections field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Collections), ViewModel.Collections, (IAssetCollection collection) => collection.PrettyName, ViewModel.RemoveCollection, CollectionSelectorView.SelectMultiple, ViewModel.AddCollection);

                EditorGUILayout.Space();

                // Tags field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Tags), ViewModel.Tags, (IAssetTag tag) => tag.Name, ViewModel.RemoveTag, TagSelectorView.SelectMultiple, ViewModel.AddTag);
            }

            GUILayout.Space(verticalSpace);

            IfxBuildStatusPanel.Draw();

            ViewTools.DrawFooter(ViewModel.Message);
        }

        private void DrawBuildJob(BundleBuildJob job)
        {
            using (var jobPanel = new EditorGUILayout.VerticalScope())
            {
                var sceneLabel = job == null ? new GUIContent(Labels.PrefabNoneSelected, Labels.PrefabNoneSelectedMessage)
                    : new GUIContent(ViewModel.UnityAssetName);
                var scenePath = job == null ? new GUIContent(Labels.EmptySelection)
                    : new GUIContent(job.BundlePath);

                using (var labelPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(Labels.Prefab), EditorStyles.boldLabel, GUILayout.Width(EditorGUIUtility.labelWidth));
                    EditorGUILayout.LabelField(sceneLabel, EditorStyles.boldLabel);
                }

                EditorGUILayout.Space();

                using (var scenePathPanel = new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField(scenePath);

                    using (var buildInProgress = new GuiTools.EnabledScope(!buildStarted))
                    {
                        if (GUI.Button(new Rect(scenePathPanel.rect.x + scenePathPanel.rect.width - 22, scenePathPanel.rect.y + (scenePathPanel.rect.height * 0.5f) - 10, 20, 20), new GUIContent(Labels.Ellipsis)))
                        {
                            DrawAssetSelector();
                        }
                    }
                }
            }
        }

        public GUIContent GetSpinner()
        {
            showSpinner = true;
            return Icons.GetWaitSpinner(frame);
        }

        private void DrawAssetSelector()
        {
            EditorGUIUtility.ShowObjectPicker<GameObject>(ViewModel.Prefab, true, "", GUIUtility.GetControlID(GetInstanceID(), FocusType.Keyboard));
        }

        private void SelectThumbnail()
        {
            var imageTypes = new string[] { "Image", "jpg,jpeg,png", "JPEG", "jpg,jpeg", "Portable Network Graphic", "png" };

            var imagePath = GuiTools.BrowseFilePath(Labels.ThumbnailSelectTitle, ViewModel.LocalThumbnail, imageTypes);

            if (!string.IsNullOrEmpty(imagePath))
            {
                ViewModel.Status |= BuildStatus.ThumbnailSelected;
                LocalThumbnailPath = imagePath;
            }
        }

        private void UpdateLocalThumbnail(string path)
        {
            if (File.Exists(path))
            {
                var bytes = File.ReadAllBytes(path);

                if (localThumbnail == null)
                    localThumbnail = new Texture2D(2, 2);

                localThumbnail.LoadImage(bytes, true);
            }
        }

        public Color GetBackgroundColorCoding(BundleFile file)
        {
            if (file != null)
            {
                return file.Uploaded ? CreatorStyle.Green : CreatorStyle.Red;
            }

            return GUI.backgroundColor;
        }

        private void Save()
        {
            ViewModel.Save();
            Close();
        }

        private void ConfirmCreateIfx()
        {
            ConfirmBuildIfx.OpenDialog(
                this,
                (builder) => EditorGUILayout.LabelField(Labels.ConfirmBuildMessage),
                CreateIfx
                );
        }

        private void CreateIfx()
        {
            buildStarted = true;
            IfxBuildStatusPanel.NextState();
            ViewModel.Start();
        }

        public abstract class BuildStatusPanel<T>
        {
            public abstract void NextState();

            protected T Parent { get; }
            public BuildStatusPanel(T parent)
            {
                Parent = parent;
            }
            public virtual void Draw() { }

            protected void DrawStatusRow(string status, string label)
            {
                DrawStatusRow(new GUIContent(status), new GUIContent(label));
            }

            protected void DrawStatusRow(GUIContent status, string label)
            {
                DrawStatusRow(status, new GUIContent(label));
            }

            protected void DrawStatusRow(GUIContent status, GUIContent label)
            {
                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(string.Empty, GUILayout.Width(10));
                    EditorGUILayout.LabelField(status, GUILayout.Width(30));
                    EditorGUILayout.LabelField(label);
                }
            }
        }

        /// <summary>
        /// Base class for all Ifx Status State Panels
        /// </summary>
        public abstract class IfxStatusPanel : BuildStatusPanel<IfxBuilderView>
        {
            public IfxStatusPanel(IfxBuilderView parent) : base(parent)
            {
                ifxLabel = Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists) ? Labels.IfxUpdated : Labels.IfxCreated;
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), Parent.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);

                // DEBUG
                string stateType = GetType().ToString();
                stateLabel = stateType.Substring(stateType.LastIndexOf("+") + 1);
                // DEBUG
            }

            protected Action DrawSaveButton;
            protected Action DrawStartButton;

            protected virtual bool SaveButtonEnabled => true;
            protected virtual bool StartButtonEnabled => true;

            protected BuildStatus Status => Parent?.ViewModel?.Status ?? BuildStatus.None;

            protected string ifxLabel;
            protected string stateLabel;

            public virtual void Update() { }

            public virtual void DrawHeader()
            {
                using (var statusPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(Labels.IfxStatus, EditorStyles.boldLabel);
                    //EditorGUILayout.LabelField(stateLabel);
                }
            }

            public virtual void DrawBody()
            {
                DrawStatusRow("", Labels.PrefabSelected);
                DrawStatusRow("", ifxLabel);
                DrawStatusRow("", Labels.ThumbnailUploaded);
                DrawStatusRow("", Labels.Bundles);
            }

            public virtual void DrawButtons()
            {
                using (var buttons = new EditorGUILayout.HorizontalScope())
                {
                    using (var saveDisabled = new GuiTools.EnabledScope(SaveButtonEnabled))
                    {
                        DrawSaveButton();
                    }
                    using (var startDisabled = new GuiTools.EnabledScope(StartButtonEnabled))
                    {
                        DrawStartButton();
                    }
                }
            }

            public override void Draw()
            {
                DrawHeader();

                using (var buildOptions = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    DrawBody();
                }

                EditorGUILayout.LabelField("", GUILayout.ExpandHeight(true));

                DrawButtons();

                Update();
            }
        }

        /// <summary>
        /// Error state
        /// </summary>
        public class ErrorState : IfxStatusPanel
        {
            public override void NextState()
            {
                Debug.Log("Welcome to Error Town!");
            }

            public ErrorState(IfxBuilderView parent) : base(parent)
            {
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.Warning, "Prefab selected: " + Parent.ViewModel.Status.HasFlag(BuildStatus.UnityAssetSelected));
                DrawStatusRow(Icons.Warning, "Ifx created: " + Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists));
                DrawStatusRow(Icons.Warning, "Thumbnail selected: " + Parent.ViewModel.Status.HasFlag(BuildStatus.ThumbnailSelected));
                DrawStatusRow(Icons.Warning, "Thumbnail uploaded: " + Parent.ViewModel.Status.HasFlag(BuildStatus.ThumbnailUploaded));
                DrawStatusRow(Icons.Warning, "Bundles Built: " + Parent.ViewModel.Status.HasFlag(BuildStatus.BundlesExist));
                DrawStatusRow(Icons.Warning, "Bundles uploaded: " + Parent.ViewModel.Status.HasFlag(BuildStatus.BundlesUploaded));
            }
        }

        /// <summary>
        /// Starting default Ifx state
        /// </summary>
        public class IfxStartState : IfxStatusPanel
        {
            public IfxStartState(IfxBuilderView parent) : base(parent) { }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    Parent.IfxBuildStatusPanel = new IfxBuildReadyState(Parent);
                }
                else
                {
                    Parent.IfxBuildStatusPanel = new IfxUpdateReadyState(Parent);
                }
            }

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetExists) || Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Error.Tooltip(Labels.PrefabNoneSelectedMessage), Labels.PrefabSelected);
                DrawStatusRow("", ifxLabel);
                DrawStatusRow("", Labels.ThumbnailUploaded);
                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State for starting update of existing Ifx with no Scene asset selected.
        /// </summary>
        public class IfxUpdateReadyState : IfxStatusPanel
        {
            public IfxUpdateReadyState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Update, Labels.UpdateIfxTooltip), Parent.CreateIfx);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;

            protected bool isRebuild;
            public override void NextState() => Parent.IfxBuildStatusPanel = new UpdatingIfxState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected) && !isRebuild)
                {
                    DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Rebuild, Labels.RebuildAndUpdateIfxTooltip), Parent.ConfirmCreateIfx);
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Parent.ViewModel.Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Warning.Tooltip(Labels.RebuildIfxConditionTooltip), Labels.PrefabSelected);
                DrawStatusRow("", ifxLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }
        }

        /// <summary>
        /// State for the update of existing Ifx's details and optionally thumbnail.
        /// </summary>
        public class UpdatingIfxState : IfxStatusPanel
        {
            public UpdatingIfxState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Update), null);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.IfxBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetUpdated))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.PrefabSelected);
                DrawStatusRow(Status.HasFlag(BuildStatus.EngageAssetUpdated) ? Icons.TestPassed : Parent.GetSpinner(), ifxLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }
        }

        /// <summary>
        /// Completed state for Update process.
        /// </summary>
        public class IfxUpdateCompleteState : IfxStatusPanel
        {
            public IfxUpdateCompleteState(IfxBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }

            protected override bool SaveButtonEnabled => false;
            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestSkipped, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, ifxLabel);
                DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                DrawStatusRow(Icons.TestSkipped, Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which Scene asset has been selected and the creation process is started.
        /// </summary>
        public class IfxBuildReadyState : IfxStatusPanel
        {
            public IfxBuildReadyState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save, Labels.SaveTooltip), Parent.ViewModel.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build, BuildButtonTooltop), Parent.ConfirmCreateIfx);
            }

            protected override bool SaveButtonEnabled => true;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;
            protected string BuildButtonTooltop => StartButtonEnabled ? Labels.BuildIfxTooltip : Labels.LoginTooltip;

            public override void NextState() => Parent.IfxBuildStatusPanel = new CreatingIfxState(Parent);

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow("", ifxLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);

                // NOTE: Batch Mode will be supported in a later release
                // Batch Build Mode
                //Parent.ViewModel.BatchBuild = EditorGUILayout.Toggle(new GUIContent(Labels.BatchBuildMode, Labels.BatchBuildTooltip), Parent.ViewModel.BatchBuild);
            }
        }

        /// <summary>
        /// State in which the Ifx is created or updated.
        /// </summary>
        public class CreatingIfxState : IfxStatusPanel
        {
            public CreatingIfxState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.IfxBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Parent.GetSpinner(), ifxLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which the Thumbnail is uploaded.
        /// </summary>
        public class UploadingThumbnailState : IfxStatusPanel
        {
            public UploadingThumbnailState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    Parent.IfxBuildStatusPanel = new BuildingIfxBundlesState(Parent);
                }
                else
                {
                    Parent.IfxBuildStatusPanel = new IfxUpdateCompleteState(Parent);
                }
            }

            public override void Update()
            {
                if (!Status.HasFlag(BuildStatus.ThumbnailSelected))
                {
                    NextState();
                }

                if (Status.HasFlag(BuildStatus.ThumbnailUploaded))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, ifxLabel);
                //DrawStatusRow(Parent.GetSpinner(), Labels.ThumbnailUploaded);

                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(string.Empty, GUILayout.Width(10));
                    EditorGUILayout.LabelField(Parent.GetSpinner(), GUILayout.Width(30));
                    EditorGUILayout.LabelField(Labels.ThumbnailUploaded);

                    using (var progressBar = new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Box(new GUIContent());

                        var progress = Parent.ViewModel.ThumbnailUploadProgress;
                        EditorGUI.ProgressBar(progressBar.rect, progress, $"{progress * 100:F0}%");
                    }
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }

            public override void DrawButtons()
            {
                using (var actionsEnabled = new GuiTools.EnabledScope(false))
                {
                    base.DrawButtons();
                }
            }
        }

        /// <summary>
        /// State in which the Build and upload status are displayed.
        /// </summary>
        public class BuildingIfxBundlesState : IfxStatusPanel
        {
            public BuildingIfxBundlesState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.IfxBuildStatusPanel = new CompleteState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.LocalFiles.Uploaded == (EngagePlatform.Windows | EngagePlatform.Android | EngagePlatform.iOS | EngagePlatform.OSX))// Parent.ViewModel.Job.BuildTargets)
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, ifxLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public void DrawPlatformStatus(EngagePlatform platform)
            {
                bool built = Parent.ViewModel.LocalFiles.ContainsKey(platform);
                bool uploaded = built ? Parent.ViewModel.LocalFiles[platform].Uploaded : false;

                var status = built ? uploaded ? Icons.TestPassed : Parent.GetSpinner() : new GUIContent();
                var icon = Parent.PlatformIcons[platform];

                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("", GUILayout.Width(40));
                    EditorGUILayout.LabelField(status, GUILayout.Width(40));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(40));

                    string processLabel = !built ? Labels.Building : !uploaded ? Labels.Uploading : Labels.Done;

                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(100));

                    if (built && !uploaded)
                    {
                        using (var progressBar = new EditorGUILayout.HorizontalScope())
                        {
                            GUILayout.Box(new GUIContent());

                            var progress = Parent.ViewModel.LocalFiles[platform].UploadProgress;
                            EditorGUI.ProgressBar(progressBar.rect, progress, $"{progress * 100:F0}%");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// State in which all processes are completed, and the window can then be closed.
        /// </summary>
        public class CompleteState : IfxStatusPanel
        {
            public CompleteState(IfxBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }
            protected override bool SaveButtonEnabled => false;

            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.PrefabSelected);
                DrawStatusRow(Icons.TestPassed, ifxLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Icons.TestPassed, Labels.Bundles);
            }
        }

        public class ConfirmBuildIfx : EngageConfirmDialog<IfxBuilderView>
        {
            protected const int heightExtent = 100;
            protected const int widthExtent = 150;

            public static void OpenDialog(
                IfxBuilderView view,
                Action<IfxBuilderView> drawMessageBody,
                Action confirmCallback = null,
                Action cancelCallback = null
                )
            {
                var dialog = GetWindow<ConfirmBuildIfx>(Labels.ConfirmBuildTitle);

                dialog.DrawMessageBody = drawMessageBody;
                dialog.onConfirm = confirmCallback;
                dialog.onCancel = cancelCallback;

                var extents = new Vector2(widthExtent, heightExtent);

                dialog.position = new Rect(view.position.center - extents, extents * 2);

                dialog.ShowModalUtility();
            }
        }
    }
}