﻿using System.Collections.Generic;
using Engage.UI.Editor;
using System.Linq;

namespace Engage.AssetManagement.Content
{
    public class GroupManager : EngageItemManager<IGroup, EngageGroup, GroupDataModule>
    {
        protected override GroupDataModule DataModule => DataManager.Module<GroupDataModule>();
        protected override IList<IGroup> Cache => DataModule.Get();

        protected override async void Initialize()
        {
            RebuildInventory(await DataModule.GetAsync());
            RefreshFromServer();
        }

        protected override EngageGroup Create(IGroup group)
        {
            var engageGroup = new EngageGroup(group);
            engageGroup.AddListener(this, OnGroupUpdated);
            return engageGroup;
        }

        protected override EngageGroup Create(string groupName)
        {
            int counter = 0;
            string suffix = "";

            while (itemInventory.Any(group => group.Name == groupName + suffix))
            {
                suffix = $"_{++counter}";
            }

            var engageGroup = new EngageGroup(groupName + suffix);
            engageGroup.AddListener(this, OnGroupUpdated);
            return engageGroup;
        }

        protected void OnGroupUpdated(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }
    }
}