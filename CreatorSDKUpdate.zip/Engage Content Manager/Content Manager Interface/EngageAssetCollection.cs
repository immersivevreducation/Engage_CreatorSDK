﻿using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    [JsonObject(MemberSerialization.OptIn)]
    public class EngageAssetCollection : EngageItem<IAssetCollection, AssetCollectionData>, IAssetCollection
    {
        protected AssetCollectionDataModule DataModule => DataManager.Module<AssetCollectionDataModule>();
        public override string ToString() => PrettyName;
        public string Name { get; set; }

        public string PrettyName { get; set; }
        public int UserId { get; set; }
        public string Image { get; set; } = "";

        [JsonConverter(typeof(EngageItemListConverter<IGroup, GroupData>))]
        public List<IGroup> Groups { get; } = new List<IGroup>();

        #region Other Properties
        protected string localThumbnailPath;
        public string LocalThumbnailPath
        {
            get => localThumbnailPath;
            set
            {
                localThumbnailPath = value;
                NotifyPropertyChange(nameof(LocalThumbnailPath));
            }
        }
        #endregion
        #region Management Status
        public float Progress { get; protected set; }
        #endregion

        public EngageAssetCollection(IAssetCollection collection)
        {
            resetItem.SetValues(collection);
            Reset();
        }

        public EngageAssetCollection(string collectionName)
        {
            PrettyName = collectionName;
            created = DateTime.Now;
            resetItem.SetValues(this);
        }

        public override void Reset()
        {
            PrettyName = resetItem.PrettyName;
            Name = resetItem.Name;
            UserId = resetItem.UserId;
            Image = resetItem.Image;

            Groups.Clear();
            Groups.AddRange(resetItem.Groups);

            base.Reset();
        }

        public override async void Create()
        {
            RequestStatus = RequestStatus.Requesting;
            var tag = await DataModule.CreateAsync(this);

            if (tag != null)
            {
                resetItem.SetValues(tag);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }
        }

        public override async void Update()
        {
            if (!resetItem.Id.HasValue)
            {
                Reset();
                return;
            }

            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UpdateAsync(this);

            if (success)
            {
                resetItem.SetValues(this);
                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }
        }

        public void UploadThumbnail()
        {
            UploadThumbnail((progress) => { Progress = progress; });
        }
        public async void UploadThumbnail(Action<float> progressCallback, Action<bool> onComplete = null)
        {
            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UploadThumbnail(
                this,
                LocalThumbnailPath,
                progressCallback);

            if (success)
            {
                var item = DataModule.Get(Id.Value);
                resetItem.SetValues(item);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            onComplete?.Invoke(success);
        }

        public void Save()
        {
            if (DataModule.TryGetLocal(Name, out IAssetCollection collection))
            {
                DataModule.Update(this);
            }
            else
            {
                DataModule.Create(this);
            }

            Debug.Log($"[Location] Location {PrettyName} saved.");
        }

        public void DeleteCollection()
        {
            DataModule.DeleteLocal(Name);

            if (Id.HasValue)
            {
                DataModule.DeleteAsync(this);
            }
        }
    }

}
