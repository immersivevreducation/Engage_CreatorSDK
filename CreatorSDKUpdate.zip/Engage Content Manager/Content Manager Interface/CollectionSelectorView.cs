﻿using System;

namespace Engage.AssetManagement.Content
{
    public class CollectionSelectorView : EngageItemSelectorView<EngageAssetCollection, CollectionManager>
    {
        private class Labels : Content.Labels
        {
            public const string ViewTitle = "Select Collection";
        }

        public static void SelectMultiple(Action<IAssetCollection> selectionCallback, IAssetCollection[] selected = null)
        {
            var window = GetWindow<CollectionSelectorView>(title: Labels.ViewTitle);
            window.onSelectionMade = selectionCallback;
            window.Multiselect = true;

            if (selected != null)
            {
                foreach (var item in selected)
                {
                    window.currentIds.Add(item.Id.Value);
                }
            }

            window.Show();
        }
    }
}