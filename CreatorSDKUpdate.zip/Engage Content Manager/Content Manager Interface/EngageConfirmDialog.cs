﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System;

namespace Engage.AssetManagement.Content
{
    public class EngageConfirmDialog<T> : EditorWindow
    {
        protected T Target { get; private set; }
        protected Vector2 scrollPos;

        protected Action onConfirm;
        protected Action onCancel;

        public Action<T> DrawMessageBody { get; set; }

        private void OnGUI()
        {
            Draw();
        }

        public void Draw()
        {
            EditorGUILayout.Space();

            using (var messagePanel = new EditorGUILayout.HorizontalScope(GUILayout.MinHeight(60)))
            {
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
                DrawMessageBody(Target);
                EditorGUILayout.LabelField(string.Empty, GUILayout.Width(20));
            }

            EditorGUILayout.LabelField(string.Empty, GUILayout.ExpandHeight(true));

            using (var selectionButtons = new EditorGUILayout.HorizontalScope())
            {
                GuiTools.DrawButton(Labels.OK, ConfirmSelection);
                GuiTools.DrawButton(Labels.Cancel, Cancel);
            }
        }

        protected void ConfirmSelection()
        {
            onConfirm?.Invoke();
            Close();
        }

        protected void Cancel()
        {
            onCancel?.Invoke();
            Close();
        }
    }
}