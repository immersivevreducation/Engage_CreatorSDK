﻿using System.Collections.Generic;
using Engage.UI.Editor;
using System.Linq;

namespace Engage.AssetManagement.Content
{
    public class TagManager : EngageItemManager<IAssetTag, EngageAssetTag, AssetTagDataModule>
    {
        protected override AssetTagDataModule DataModule => DataManager.Module<AssetTagDataModule>();
        protected override IList<IAssetTag> Cache => DataManager.Module<AssetTagDataModule>().Get();

        protected override async void Initialize()
        {
            RebuildInventory(await DataModule.GetAsync());
            RefreshFromServer();
        }

        protected override EngageAssetTag Create(IAssetTag tag)
        {
            var engageTag = new EngageAssetTag(tag);
            engageTag.AddListener(this, OnTagUpdated);
            return engageTag;
        }

        protected override EngageAssetTag Create(string tagName)
        {
            int counter = 0;
            string suffix = "";

            while (itemInventory.Any(tag => tag.EnglishName == tagName + suffix))
            {
                suffix = $"_{++counter}";
            }

            var engageTag = new EngageAssetTag(tagName + suffix);
            engageTag.AddListener(this, OnTagUpdated);
            return engageTag;
        }

        public void AddNewAssetTag()
        {
            var item = Create("");

            itemInventory.Add(item);
            ItemDisplayList.Insert(0, item);
            DataModule.Create(item);
            NotifyPropertyChange(nameof(Create));
        }

        protected void OnTagUpdated(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }
    }
}