﻿using System.Collections.Generic;
using Engage.UI.Editor;
using System.Linq;
using System;

namespace Engage.AssetManagement.Content
{
    public class CollectionManager : EngageItemManager<IAssetCollection, EngageAssetCollection, AssetCollectionDataModule>
    {
        protected override AssetCollectionDataModule DataModule => DataManager.Module<AssetCollectionDataModule>();
        protected override IList<IAssetCollection> Cache => DataModule.Get();

        protected override async void Initialize()
        {
            RebuildInventory(await DataModule.GetAsync());
            RefreshFromServer();
        }

        protected override EngageAssetCollection Create(IAssetCollection collection)
        {
            var engageCollection = new EngageAssetCollection(collection);
            engageCollection.AddListener(this, OnCollectionChanged);
            return engageCollection;
        }

        protected override EngageAssetCollection Create(string collectionName)
        {
            int counter = 0;
            string suffix = "";

            while (itemInventory.Any(collection => collection.PrettyName == collectionName + suffix))
            {
                suffix = $"_{++counter}";
            }

            var engageCollection = new EngageAssetCollection(collectionName + suffix);
            engageCollection.AddListener(this, OnCollectionChanged);
            return engageCollection;
        }

        protected void OnCollectionChanged(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }

        internal void DeleteCollection(EngageAssetCollection collection)
        {
            itemInventory.Remove(collection);
            collection.DeleteCollection();
            RefreshDisplay();
        }
    }
}