﻿using System;

namespace Engage.AssetManagement.Content
{
    public class TagSelectorView : EngageItemSelectorView<EngageAssetTag, TagManager>
    {
        private class Labels : Content.Labels
        {
            public const string ViewTitle = "Select Tag";
        }

        public static void SelectMultiple(Action<IAssetTag> selectionCallback, IAssetTag[] selected = null)
        {
            var window = GetWindow<TagSelectorView>(title: Labels.ViewTitle);
            window.onSelectionMade = selectionCallback;
            window.Multiselect = true;

            if (selected != null)
            {
                foreach (var item in selected)
                {
                    if (item.Id.HasValue)
                    {
                        window.currentIds.Add(item.Id.Value);
                    }
                }
            }

            window.Show();
        }
    }
}