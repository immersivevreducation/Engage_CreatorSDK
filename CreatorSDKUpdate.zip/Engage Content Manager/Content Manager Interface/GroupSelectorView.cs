﻿using System;

namespace Engage.AssetManagement.Content
{
    public class GroupSelectorView : EngageItemSelectorView<EngageGroup, GroupManager>
    {
        private class Labels : Content.Labels
        {
            public const string ViewTitle = "Select Group";
        }

        public static void Select(Action<IGroup> selectionCallback)
        {
            var window = GetWindow<GroupSelectorView>(title: Labels.ViewTitle);
            window.onSelectionMade = selectionCallback;
            window.Show();
        }

        public static void SelectMultiple(Action<IGroup> selectionCallback, IGroup[] selected = null)
        {
            var window = GetWindow<GroupSelectorView>(title: Labels.ViewTitle);
            window.onSelectionMade = selectionCallback;
            window.Multiselect = true;

            if (selected != null)
            {
                foreach (var item in selected)
                {
                    window.currentIds.Add(item.Id.Value);
                }
            }

            window.Show();
        }
    }
}