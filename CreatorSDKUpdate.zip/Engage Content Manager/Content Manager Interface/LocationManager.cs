﻿using Engage.UI.Editor;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class LocationManager : EngageItemManager<ILocationAsset, EngageLocation, LocationAssetDataModule>
    {
        #region Const & Static
        public static class Keys
        {
            public const string bundleManagerSortKey = "BundleManagerSortKey";
            public const string bundleManagerShowNonLocalKey = "BundleManagerShowNonLocalKey";
            public const string bundleManagerShowUploadedKey = "BundleManagerShowUploadedKey";
        }

        private static bool? showMyLocations;
        private static bool? showUploadedLocations;
        #endregion

        protected override LocationAssetDataModule DataModule => DataManager.Module<LocationAssetDataModule>();
        protected override IList<ILocationAsset> Cache => DataModule.Get();

        // used to shorten time before view can be rendered on first load
        protected bool preloadedInventory = false;

        protected override EngageLocation Create(ILocationAsset location)
        {
            var item = location as EngageLocation;

            if (item == null)
            {
                item = new EngageLocation(location);
            }

            item.AddListener(this, OnLocationUpdated);
            return item;
        }

        protected override EngageLocation Create(string name)
        {
            var item = new EngageLocation();
            item.Name = name;
            item.AddListener(this, OnLocationUpdated);

            return item;
        }

        protected async override void Initialize()
        {
            RebuildInventory(await DataModule.GetAsync());
            preloadedInventory = true;
        }

        protected override void RebuildInventory(IList<ILocationAsset> locations)
        {
            if (preloadedInventory)
            {
                preloadedInventory = false;
                return;
            }

            itemInventory.Clear();

            foreach (ILocationAsset location in locations)
            {
                itemInventory.Add(Create(location));
            }

            RefreshUploadHistory();
            RefreshDisplay();
        }

        protected override Predicate<EngageLocation> DisplayItem => (bundle) => bundle.Id.HasValue ? true : bundle.UnityResourceName == EngageUser.CurrentProjectName;

        public void RefreshUploadHistory()
        {
            EngageUser.RefreshUploadHistory();
            NotifyPropertyChange(nameof(RefreshUploadHistory));
        }

        public void ClearBundleUploadHistory()
        {
            EngageUser.ClearUploadHistory();
            NotifyPropertyChange(nameof(ClearBundleUploadHistory));
        }

        protected void OnLocationUpdated(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }

        internal void DeleteLocation(EngageLocation location)
        {
            itemInventory.Remove(location);
            location.DeleteAsset();
            RefreshDisplay();
        }

        public async override void RefreshFromServer()
        {
            await DataModule.RefreshAsync();

            foreach(var location in GenerateList())
            {
                DataModule.Create(location);
            }

            Refresh();
        }

        public List<ILocationAsset> GenerateList(int count = 10)
        {
            var rand = new Random();
            var list = new List<ILocationAsset>();

            for (int i = 0; i < count; i++)
            {
                int id = rand.Next(1, 100);
                var location = new LocationAssetData($"dummy_location_{id:00}")
                {
                    PrettyName = (Glossary)$"Dummy Location {id}",
                    Description = (Glossary)$"A description of Dummy Location {id}, signifying nothing,",
                    BundleId = 52,
                    Id = id,
                    CreatedAt = DateTime.Now.ToString(),
                    UpdatedAt = DateTime.Now.ToString()
                };

                list.Add(location);
            }

            return list;
        }
    }
}