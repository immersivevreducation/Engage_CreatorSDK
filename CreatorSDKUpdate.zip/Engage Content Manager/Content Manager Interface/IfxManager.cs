﻿using Engage.UI.Editor;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class IfxManager : EngageItemManager<IIfxAsset, EngageIFX, IfxAssetDataModule>
    {
        protected override IfxAssetDataModule DataModule => DataManager.Module<IfxAssetDataModule>();
        protected override IList<IIfxAsset> Cache => DataModule.Get();

        // used to shorten time before view can be rendered on first load
        protected bool preloadedInventory = false;

        protected override EngageIFX Create(IIfxAsset ifx)
        {
            var item = ifx as EngageIFX;

            if (item == null)
            {
                item = new EngageIFX(ifx);
            }

            item.AddListener(this, OnIfxUpdated);
            return item;
        }

        protected override EngageIFX Create(string name)
        {
            var item = new EngageIFX();
            item.Name = name;
            item.AddListener(this, OnIfxUpdated);

            return item;
        }

        protected async override void Initialize()
        {
            RebuildInventory(await DataModule.GetAsync());
            preloadedInventory = true;
        }

        protected override void RebuildInventory(IList<IIfxAsset> ifxs)
        {
            if (preloadedInventory)
            {
                preloadedInventory = false;
                return;
            }

            itemInventory.Clear();

            foreach (IIfxAsset ifx in ifxs)
            {
                itemInventory.Add(Create(ifx));
            }

            RefreshUploadHistory();
            RefreshDisplay();
        }

        protected override Predicate<EngageIFX> DisplayItem => (bundle) => bundle.Id.HasValue ? true : bundle.UnityResourceName == EngageUser.CurrentProjectName;

        public void RefreshUploadHistory()
        {
            EngageUser.RefreshUploadHistory();
            NotifyPropertyChange(nameof(RefreshUploadHistory));
        }

        public void ClearBundleUploadHistory()
        {
            EngageUser.ClearUploadHistory();
            NotifyPropertyChange(nameof(ClearBundleUploadHistory));
        }

        protected void OnIfxUpdated(ViewModel viewModel, string property)
        {
            NotifyPropertyChange(property);
        }

        internal void DeleteIFX(EngageIFX ifx)
        {
            itemInventory.Remove(ifx);
            ifx.DeleteAsset();
            RefreshDisplay();
        }

        public async override void RefreshFromServer()
        {
            await DataModule.RefreshAsync();

            foreach(var ifx in GenerateList())
            {
                DataModule.Create(ifx);
            }

            Refresh();
        }

        public List<IIfxAsset> GenerateList(int count = 10)
        {
            var rand = new Random();
            var list = new List<IIfxAsset>();

            for (int i = 0; i < count; i++)
            {
                int id = rand.Next(1, 100);
                var ifx = new IfxAssetData($"dummy_ifx_{id:00}")
                {
                    PrettyName = (Glossary)$"Dummy IFX {id}",
                    Description = (Glossary)$"A description of Dummy IFX {id}, signifying nothing,",
                    BundleId = 52,
                    Id = id,
                    CreatedAt = DateTime.Now.ToString(),
                    UpdatedAt = DateTime.Now.ToString()
                };

                list.Add(ifx);
            }

            return list;
        }
    }
}