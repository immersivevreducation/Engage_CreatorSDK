﻿using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public interface IBranding
    {
        int? BrandingGroupId { get; set; }
        IGroup BrandingGroup { get; set; }
        void SetBrandingGroup(IGroup group);
    }

    public class BrandingGroupViewTools
    {
        // NOTE: Branding group selection will be supported in a later release
        // Branding Group field

        public static void DrawBrandingGroupPanel(IBranding brandable)
        {
            using (var brandingGroupPanel = new EditorGUILayout.HorizontalScope())
            {
                if (brandable.BrandingGroupId.HasValue)
                {
                    EditorGUILayout.LabelField(Labels.BrandingGroup, $"{brandable.BrandingGroup.Name} ({brandable.BrandingGroupId.ToIdString()})");
                    GuiTools.DrawButton(Labels.Edit, () => SelectGroup(brandable), GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));
                    GuiTools.DrawButton(Labels.Clear, () => ClearGroup(brandable), GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));
                }
                else
                {
                    EditorGUILayout.LabelField(Labels.BrandingGroup, GUILayout.Width(EditorGUIUtility.labelWidth));
                    GuiTools.DrawButton(Labels.Select, () => SelectGroup(brandable), GUILayout.Width(CreatorStyle.EXTRALONG_BUTTON_WIDTH));
                }
            }
        }

        public static void SelectGroup(IBranding brandable)
        {
            GroupSelectorView.Select(brandable.SetBrandingGroup);
        }

        public static void ClearGroup(IBranding brandable)
        {
            brandable.SetBrandingGroup(null);
        }
    }
}