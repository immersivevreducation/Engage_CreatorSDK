using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using Engage.UI.Editor;
using Engage.CreatorSDK;
using System.Linq;
using System;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public enum BundleBuildQueue { Parallel, Serial }

    public enum BuildMode { Create, Edit }

    [Flags]
    public enum BuildStatus
    {
        None = 0x0000,

        EngageAssetExists = 0x0001,
        BundlesExist = 0x0002,

        ThumbnailSelected = 0x0004,
        UnityAssetSelected = 0x0008,

        BundlesUploaded = 0x0010,
        ThumbnailUploaded = 0x0020,

        EngageAssetUpdated = 0x0040,

        EngageAssetError = 0x0100,
        ThumbnailError = 0x0200,
        BundleError = 0x0400,
        UnityAssetError = 0x0800
    }

    public enum ProcessState
    {
        None,
        Ready,
        Skipped,
        Running,
        Complete,
        Error
    }

    public class EngageProcess
    {
        public string Name { get; }
        public string Message { get; set; }
        public float Progress { get; set; }
        public ProcessState State {get; set;}
    }

    public class EngageProcessStatus
    {
        public Dictionary<string, EngageProcess> Processes { get; } = new Dictionary<string, EngageProcess>();

        public ProcessState GetStatus(string processName)
        {
            if (Processes.TryGetValue(processName, out EngageProcess process))
            {
                return process.State;
            }

            return ProcessState.None;
        }
    }

    public abstract class AssetBuilder<T> : ViewModel where T : EngageAsset
    {
        //protected LocationAssetDataModule DataModule => DataManager.Module<LocationAssetDataModule>();

        protected readonly BundleBuilder.ModuleManager moduleManager = new BundleBuilder.ModuleManager();
        protected readonly BundleBuilder.BatchHandler handler = new BundleBuilder.BatchHandler();
        protected readonly HashSet<BuildTarget> installedBuildModules = new HashSet<BuildTarget>();

        protected string localThumbnail;
        protected float thumbnailUploadProgress;

        protected T engageAsset;

        public BuildStatus Status { get; set; }
        public Dictionary<string, EngageProcess> ProcessStatus { get; } = new Dictionary<string, EngageProcess>();

        public T EngageAsset
        {
            get
            {
                if (engageAsset == null)
                {
                    Refresh();
                }

                return engageAsset;
            }
            set
            {
                engageAsset = value;
                NotifyPropertyChange(nameof(EngageAsset));
            }
        }

        public BuildMode Mode { get; private set; } = BuildMode.Create;
        public string Message { get; set; }

        public int? Id { get => EngageAsset.Id; }
        public string UnityResourceName { get => EngageAsset.UnityResourceName; set => EngageAsset.UnityResourceName = value; }
        public string PrettyName { get => EngageAsset.PrettyName; set => EngageAsset.PrettyName.Set(Glossary.English, value); }
        public string Description { get => EngageAsset.Description; set => EngageAsset.Description.Set(Glossary.English, value); }
        public string ImageURL { get => EngageAsset.Image; set => EngageAsset.Image = value; }

        //public int? BrandingGroupId { get => Location.BrandingGroupId; set => Location.BrandingGroupId = value; }
        //public IGroup BrandingGroup { get => Location.BrandingGroup; set => Location.BrandingGroup = value; }
        //public void SetBrandingGroup(IGroup group) => Location.SetBrandingGroup(group);

        public List<IGroup> Groups => EngageAsset.Groups;
        public List<IAssetCollection> Collections => EngageAsset.Collections;
        public List<IAssetTag> Tags => EngageAsset.Tags;

        public string LocalThumbnail
        {
            get
            {
                return localThumbnail;
            }
            set
            {
                localThumbnail = value;
                NotifyPropertyChange(nameof(LocalThumbnail));
            }
        }

        internal void Edit(T asset)
        {
            Mode = BuildMode.Edit;
            this.engageAsset = asset;
            localThumbnail = EngageAsset.Image;
        }

        public BundleFiles LocalFiles { get; set; }
        public BundleBuildJob Job { get; protected set; }
        //public SceneAsset Scene { get; protected set; }
        public abstract string UnityAssetName { get; }// => Scene?.name;

        public float ThumbnailUploadProgress
        {
            get => thumbnailUploadProgress;
            set
            {
                thumbnailUploadProgress = value;
                NotifyPropertyChange(nameof(ThumbnailUploadProgress));
            }
        }

        public bool AllModulesInstalled
        {
            get
            {
                foreach (var target in BundleBuilder.SupportedBuildTargets)
                {
                    if (!installedBuildModules.Contains(target))
                    {
                        return false;
                    }
                }

                return true;
            }
        }

        public bool IsModuleInstalled(BuildTarget target)
        {
            if (target == BuildTarget.iOS)
                return false;

            return installedBuildModules.Contains(target);
        }

        public bool BatchBuild { get; set; }

        protected override void Initialize()
        {
            base.Initialize();

            foreach (var target in BundleBuilder.SupportedBuildTargets)
            {
                if (moduleManager.IsModuleInstalled(target))
                {
                    installedBuildModules.Add(target);
                }
            }
        }

        public override void Refresh()
        {
            Message = "";

            if (Mode == BuildMode.Create)
            {
                var guid = Selection.assetGUIDs.FirstOrDefault();
                LoadEngageAsset(guid);
                LoadUnityAsset(guid);
            }
            else
            {
                LoadEngageAsset(EngageAsset);
                LoadUnityAsset(EngageAsset.Name);
            }
        }

        public abstract void LoadEngageAsset(string guid);
        public virtual void LoadEngageAsset(T asset)
        {
            Status = Status & ~BuildStatus.EngageAssetExists;
            Status = Status & ~BuildStatus.ThumbnailSelected;

            localThumbnail = EngageAsset.Image;

            // Existing EngageAsset
            if (EngageAsset.Id.HasValue)
            {
                Status |= BuildStatus.EngageAssetExists;
            }
            else
            {
                if (!string.IsNullOrEmpty(localThumbnail))
                {
                    Status |= BuildStatus.ThumbnailSelected;
                }
            }
        }

        public void LoadLocalFiles(string guid)
        {
            Status = Status & ~BuildStatus.BundlesExist;

            if (string.IsNullOrEmpty(guid))
                return;

            LocalFiles = new BundleFiles(guid);

            if (LocalFiles.Platforms > EngagePlatform.None)
            {
                Debug.Log($"[Build Status] GUID {guid} Adding ({BuildStatus.BundlesExist}) to ({Status})");
                Status |= BuildStatus.BundlesExist;
            }

            NotifyPropertyChange(nameof(LocalFiles));
        }

        public abstract void LoadUnityAsset(string guid);
        //{
        //    if (string.IsNullOrEmpty(guid))
        //    {
        //        Status &= ~BuildStatus.SceneSelected;
        //        Job = null;
        //        Message = $"No scene selected";
        //        Debug.LogWarning($"[{nameof(T)} Builder] {Message}");
        //        return;
        //    }

        //    var path = AssetDatabase.GUIDToAssetPath(guid);
        //    var scene = AssetDatabase.LoadAssetAtPath<SceneAsset>(path);

        //    LoadLocalScene(scene);
        //}

        //public void LoadLocalScene(SceneAsset scene)
        //{
        //    Status &= ~BuildStatus.SceneSelected;

        //    if (scene == null)
        //    {
        //        Job = null;
        //        Message = $"Selected object is not a scene";
        //        Debug.LogWarning($"[{nameof(T)} Builder] {Message}");
        //        return;
        //    }

        //    Status |= BuildStatus.SceneSelected;

        //    Scene = scene;
        //    string guid = Scene.GetGUID();

        //    // Location data empty or unsaved
        //    if (string.IsNullOrEmpty(EngageAsset.Name))
        //    {
        //        LoadEngageAsset(guid);
        //        PrettyName = UnityAssetName.ToPretty();
        //    }

        //    Job = new BundleBuildJob(guid);
        //    Job.BundleLabel = guid;
        //    Job.OnComplete += OnBuildComplete;

        //    LoadLocalFiles(guid);

        //    NotifyPropertyChange(nameof(Job));
        //}

        public void AddGroup(IGroup group) => EngageAsset.AddGroup(group);
        public void RemoveGroup(IGroup group) => EngageAsset.RemoveGroup(group);
        public void AddCollection(IAssetCollection collection) => EngageAsset.AddCollection(collection);
        public void RemoveCollection(IAssetCollection collection) => EngageAsset.RemoveCollection(collection);
        public void AddTag(IAssetTag tag) => EngageAsset.AddTag(tag);
        public void RemoveTag(IAssetTag tag) => EngageAsset.RemoveTag(tag);

        public bool DemoMode { get; set; } = true;

        public async void Start()
        {
            // 1. Create/Update ENGAGE Location
            await CreateAsset();

            // 2. Updload Thumbnail
            if (Status.HasFlag(BuildStatus.ThumbnailSelected))
            {
                await UploadThumbnail();
            }

            // 3. Build Bundles
            if (Status.HasFlag(BuildStatus.UnityAssetSelected))
            {
                BuildBundles();
            }
        }

        public async Task CreateAsset()
        {
            if (DemoMode)
            {
                await Task.Delay(1000);
                Status |= BuildStatus.EngageAssetExists | BuildStatus.EngageAssetUpdated;
                NotifyPropertyChange(nameof(Status));
                return;
            }

            if (Status.HasFlag(BuildStatus.EngageAssetExists))
            {
                await EngageAsset.UpdateAssetAsync();
            }
            else
            {
                await EngageAsset.CreateAssetAsync();
            }

            if (EngageAsset.RequestStatus == Network.RequestStatus.Error)
            {
                Debug.LogError("ERROR");
                NotifyPropertyChange(nameof(T));
                return;
            }
            else
            {
                if (Id.HasValue)
                {
                    Status |= BuildStatus.EngageAssetExists | BuildStatus.EngageAssetUpdated;
                }
                else
                {
                    // Something went very wrong
                }
            }

            NotifyPropertyChange(nameof(Status));
        }

        public async Task UploadThumbnail()
        {
            if (DemoMode)
            {
                await Task.Delay(500);
                await MockThumbnailUploadProgress(OnThumbnailUploadDone);
                NotifyPropertyChange(nameof(Status));
                return;
            }

            if (File.Exists(LocalThumbnail))
            {
                EngageAsset.LocalThumbnailPath = LocalThumbnail;
                EngageAsset.UploadThumbnail(OnThumbnailProgress, OnThumbnailUploadDone);
            }

            NotifyPropertyChange(nameof(Status));
        }

        protected void OnThumbnailProgress(float progress)
        {
            ThumbnailUploadProgress = progress;
            NotifyPropertyChange(nameof(ThumbnailUploadProgress));
        }

        protected void OnThumbnailUploadDone(bool success)
        {
            if (success)
            {
                Status |= BuildStatus.ThumbnailUploaded;
            }
            else
            {
                //Status |= BuildStatus.ThumbnailError;
            }
        }

        public async void BuildBundles()
        {
            buildTargets = new Queue<BuildTarget>(BundleBuilder.SupportedBuildTargets);

            if (DemoMode)
            {
                while (buildTargets.Count > 0)
                {
                    await Task.Delay(1000);
                    OnBuildComplete(Job, buildTargets.Dequeue().ToEngagePlatform());
                    Status |= BuildStatus.BundlesExist;
                }

                NotifyPropertyChange(nameof(Status));
                return;
            }

            if (BatchBuild)
            {
                StartBatchBuildJob();
            }
            else
            {
                StartBuildJob();
            }

            NotifyPropertyChange(nameof(Status));
        }

        protected void OnBuildComplete(BundleBuildJob job, EngagePlatform platform)
        {
            Debug.Log($"[Build Job] Build Complete: ({platform})");

            if (DemoMode)
            {
                LocalFiles.Add(platform, new BundleFile(platform, "test", "TestAsset"));
                Upload(platform);
                NotifyPropertyChange(nameof(LocalFiles));
                return;
            }

            LocalFiles.Refresh(platform);

            Upload(platform);

            // This will only be necessary of in Serial Build Mode
            if (buildTargets.Count > 0)
            {
                var next = buildTargets.Dequeue();
                Job.Start(next);
                Debug.Log($"[Build Job] Starting: ({next})");
            }

            NotifyPropertyChange(nameof(LocalFiles));
        }

        public void Upload(EngagePlatform platform)
        {
            if (LocalFiles == null || !LocalFiles.TryGetValue(platform, out BundleFile localFile))
            {
                // Log warning that platform's local file doesn't exist?
                return;
            }

            if (DemoMode)
            {
                MockUploadProgress(platform, OnUploadComplete);
            }
            else
            {
                EngageAsset.UploadBundle(platform, localFile, (bundle, progress) => NotifyPropertyChange($"{EngageAsset.PrettyName}_{platform}"), OnUploadComplete);
            }
        }

        protected void OnUploadComplete(BundleFile bundle, bool success)
        {
            if (success)
            {
                Debug.Log($"[{nameof(T)}] {bundle.Platform} ({bundle.Bundle?.FullName}) upload complete");
            }
        }

        public async Task MockThumbnailUploadProgress(Action<bool> onComplete)
        {
            while (ThumbnailUploadProgress < 1)
            {
                await Task.Delay(20);
                ThumbnailUploadProgress += ThumbnailUploadProgress + 0.01f;
                NotifyPropertyChange(nameof(Status));
            }

            ThumbnailUploadProgress = 1f;
            onComplete?.Invoke(true);
        }

        public async void MockUploadProgress(EngagePlatform platform, Action<BundleFile, bool> onComplete)
        {
            if (LocalFiles.TryGetValue(platform, out BundleFile bundle))
            {
                while (bundle.UploadProgress < 1)
                {
                    await Task.Delay(20);
                    bundle.UpdateProgress(bundle.UploadProgress + 0.01f);
                }

                bundle.UpdateProgress(1f);
                bundle.Uploaded = true;
                onComplete?.Invoke(bundle, true);
            }
        }

        private Queue<BuildTarget> buildTargets;

        public void StartBuildJob()
        {
            buildTargets = new Queue<BuildTarget>(BundleBuilder.SupportedBuildTargets);

            if (AssetDatabase.AssetPathToGUID(Job.BundlePath) == Job.BundleGuid)
            {
                Job.RunQATests();

                if (Job.IsQAPassed)
                {
                    Job.BuildTargets = BundleBuilder.ToEngagePlatform(installedBuildModules);
                    BundleBuilder.QueueBuildJob(Job);
                }
            }

            Job.Start(buildTargets.Dequeue());
        }

        private void StartBatchBuildJob()
        {
            foreach (BuildTarget target in installedBuildModules)
            {
                Job.BuildTargets = BundleBuilder.ToEngagePlatform(installedBuildModules);
                string batchPath = handler.CreateBatchBuildFile(Job, target);
                handler.RunBatchFile(batchPath);
            }
        }

        public void Save()
        {
            if (!Status.HasFlag(BuildStatus.EngageAssetExists))
            {
                EngageAsset.DeleteAsset();
                EngageAsset.Name = Job.BundleGuid;
                EngageAsset.UnityResourceName = EngageUser.CurrentProjectName;
            }

            if (Status.HasFlag(BuildStatus.ThumbnailSelected))
            {
                EngageAsset.Image = LocalThumbnail;
            }

            EngageAsset.Save();

            Message = $"{PrettyName} saved to local cache";
        }
    }
}