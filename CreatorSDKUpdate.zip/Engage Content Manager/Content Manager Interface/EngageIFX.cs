﻿using Engage.CreatorSDK;
using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    /// <summary>
    /// View model for interacting with Location Assets.
    /// </summary>
    [JsonObject(MemberSerialization.OptIn)]
    public class EngageIFX : EngageAsset, IIfxAsset
    {
        protected override IAsset Asset { get => resetIfxAsset; set => _ = value; }
        protected IfxAssetData resetIfxAsset = new IfxAssetData();
        protected IfxAssetDataModule DataModule => DataManager.Module<IfxAssetDataModule>();

        #region IIfxAsset Properties
        public int CategoryId { get; set; }
        public string Type { get; set; }
        public List<IIfxOption> Options { get; } = new List<IIfxOption>();
        #endregion

        protected override void InitializeSyncStatusManager()
        {
            base.InitializeSyncStatusManager();

            syncStatusManager.RegisterProperty(nameof(CategoryId), () => CategoryId != resetIfxAsset.CategoryId);
            syncStatusManager.RegisterProperty(nameof(Type), () => Type != resetIfxAsset.Type);
        }

        #region Constructors
        public EngageIFX()
        {
            // TODO: Implement configurable default settings
            //resetSceneAsset.SetValues(Environment.DefaultSceneAssetSettings);
        }

        public EngageIFX(IIfxAsset asset)
        {
            resetIfxAsset.SetValues(asset);
            Reset();
        }
        #endregion

        public override void Reset()
        {
            base.Reset();

            CategoryId = resetIfxAsset.CategoryId;
            Type = resetIfxAsset.Type;

            Options.Clear();
            Options.AddRange(resetIfxAsset.Options);
        }

        public async override Task CreateAssetAsync()
        {
            RequestStatus = RequestStatus.Requesting;

            var asset = await DataModule.CreateAsync(this);

            if (asset != null)
            {
                resetIfxAsset.SetValues(asset);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            return;
        }
        public async override void CreateAsset()
        {
            await CreateAssetAsync();
        }

        public async override Task UpdateAssetAsync()
        {
            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UpdateAsync(this);

            if (success)
            {
                resetIfxAsset.SetValues(this);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            return;
        }
        public async override void UpdateAsset()
        {
            await UpdateAssetAsync();
        }

        public override void UploadThumbnail()
        {
            UploadThumbnail((progress) => { Progress = progress; });
        }
        public async override void UploadThumbnail(Action<float> progressCallback, Action<bool> onComplete = null)
        {
            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UploadThumbnail(
                this,
                LocalThumbnailPath,
                progressCallback);

            if (success)
            {
                var item = DataModule.Get(Id.Value);
                resetIfxAsset.SetValues(item);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            onComplete?.Invoke(success);
        }

        public async override void UploadBundle(EngagePlatform platform, BundleFile localFile, Action<BundleFile, float> update, Action<BundleFile, bool> complete)
        {
            if (localFile == null)
            {
                return;
            }

            if (localFile.Status == RequestStatus.Requesting)
            {
                Debug.LogWarning($"[Bundle Upload] {Name} ({platform}) already requesting upload.");
                return;
            }

            localFile.Status = RequestStatus.Requesting;

            update?.Invoke(localFile, localFile.UploadProgress);

            if (update != null)
            {
                localFile.OnProgressUpdated += update;
            }

            var success = await DataModule.UploadBundle(this, localFile);

            if (update != null)
            {
                localFile.OnProgressUpdated -= update;
            }

            if (success)
            {
                localFile.Status = RequestStatus.Complete;
                EngageUser.RegisterUpload(localFile);
                Debug.Log($"[Engage Bundle] {Name} ({platform}) successfully uploaded.");
            }
            else
            {
                localFile.Status = RequestStatus.Error;
                Debug.LogWarning($"[Engage Bundle] {Name} ({platform}) was not uploaded.");
            }

            update?.Invoke(localFile, localFile.UploadProgress);
            complete?.Invoke(localFile, success);
        }

        internal void CreateLocation()
        {
            throw new NotImplementedException();
        }

        public override void UploadAllBundles() => UploadAllBundles(null);

        public override void UploadAllBundles(Action update)
        {
            //if (LocalFiles == null)
            //    return;

            //foreach (var fileSet in LocalFiles)
            //{
            //    UploadBundle(fileSet.Key, update);
            //}
        }

        public override void Save()
        {
            if (DataModule.TryGetLocal(Name, out IIfxAsset ifx))
            {
                DataModule.Update(this);
            }
            else
            {
                DataModule.Create(this);
            }

            Debug.Log($"[Location] Location {PrettyName} saved.");
        }

        public override void DeleteAsset()
        {
            DataModule.DeleteLocal(Name);

            if (Id.HasValue)
            {
                DataModule.DeleteAsync(this);
            }
        }
    }
}

