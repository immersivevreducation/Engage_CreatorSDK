﻿using System.IO;
using System.Threading.Tasks;
using UnityEditor;
using Engage.Network;
using Engage.CreatorSDK;

namespace Engage.AssetManagement.Content
{
    public class EngageUser
    {
        private static class Keys
        {
            public const string rememberedUserKey = "RememberedUserKey";
            public const string rememberCredentialsKey = "RememberUserCredentials";

            public const string currentLocalAssetPathKey = "CurrentBuildPath";
            public const string currentAssetPlatform = "CurrentBuildTargets";

            public const string defaultIfxAssetKey = "DefaultIfxSettings";
            public const string defaultLocationAssetKey = "DefaultLocationSettings";
        }

        private const string defaultLocalAssetPath = "AssetBundles";

        private static EngageUser instance;
        internal static EngageUser Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new EngageUser();
                }

                return instance;
            }
        }

        public static string GetUserKey(string key) => $"{ApiClient.Host.Environment}_{key}";
        public static string CurrentProjectName => new DirectoryInfo(Directory.GetCurrentDirectory()).Name;

        internal static string RememberCredentialsKey => GetUserKey(Keys.rememberCredentialsKey);
        internal static string RememberedUserKey => GetUserKey(Keys.rememberedUserKey);

        private ApiClient apiClient;
        public static ApiClient ApiClient
        {
            get
            {
                if (Instance.apiClient == null)
                {
                    Instance.apiClient = ApiClient.CreateApiClient<ApiClientAuthentication>();
                }

                return Instance.apiClient;
            }
        }

        #region Authentication

        public static string UserName
        {
            get => ApiClient.Module<ApiClientAuthentication>().CurrentUser.Name;
            set => ApiClient.Module<ApiClientAuthentication>().CurrentUser.Name = value;
        }
        public static string Password { get; set; }

        private UserDetails userDetails;
        public static UserDetails UserDetails
        {
            get => Instance.userDetails ?? ApiClient.Module<ApiClientAuthentication>().CurrentUser as UserDetails;
            set
            {
                Instance.userDetails = value;
                ApiClient.Module<ApiClientAuthentication>().CurrentUser.Id = value.Id;
            }
        }

        public static string EncryptionKey => ApiClient.Module<ApiClientAuthentication>().EncryptionKey;

        private bool? rememberCredentials;
        private string localAssetPath;

        public static bool IsRemembered => !string.IsNullOrEmpty(ApiClient.Module<ApiClientAuthentication>().CurrentUser?.UserToken);
        public static bool IsAuthenticated => ApiClient.Module<ApiClientAuthentication>().AuthenticationStatus == AuthenticationState.Authenticated;
        public static bool RememberCredentials
        {
            get
            {
                if (!Instance.rememberCredentials.HasValue)
                {
                    Instance.rememberCredentials = EditorPrefs.GetBool(RememberCredentialsKey, false);
                }

                return Instance.rememberCredentials.Value;
            }
            set
            {
                if (Instance.rememberCredentials.HasValue)
                {
                    if (Instance.rememberCredentials != value)
                    {
                        Instance.rememberCredentials = value;
                        EditorPrefs.SetBool(RememberCredentialsKey, Instance.rememberCredentials.Value);
                    }
                }
            }
        }

        public static async Task<bool> RequestLogin(string password)
        {
            bool success = await ApiClient.Module<ApiClientAuthentication>().RequestLogin(ApiClient.Module<ApiClientAuthentication>().CurrentUser, password);

            //if (success && RememberCredentials)
            //{
            //    UserDirectory.RememberUser(ApiClient.Host, User);
            //}
            //else
            //{
            //    UserDirectory.ForgetUser(ApiClient.Host);
            //}

            return success;
        }

        public static async Task<bool> RequestLogout()
        {
            return await ApiClient.Module<ApiClientAuthentication>().RequestLogout();
        }

        //public static void DiscardStoredCredentials()
        //{
        //    UserDirectory.ForgetUser(ApiClient.Host);
        //}
        #endregion


        private ILocationAsset defaultLocationAssetSettings;
        public static ILocationAsset DefaultLocationAssetSettings
        {
            get
            {
                //if (Instance.defaultSceneAssetSettings == null)
                //{
                //    var settings = EditorPrefs.GetString(GetUserKey(Keys.defaultSceneAssetKey));

                //    if (string.IsNullOrEmpty(settings))
                //    {
                //        Instance.defaultSceneAssetSettings = new SceneAssetData("DefaultLocationSettings");
                //    }
                //    else
                //    {
                //        try
                //        {
                //            Instance.defaultSceneAssetSettings = JsonConvert.DeserializeObject<SceneAsset>(settings);
                //        }
                //        catch (Exception ex)
                //        {
                //            Debug.LogError("[Environment Settings] Default Scene Settings could not be deserialized: " + ex);

                //            Instance.defaultSceneAssetSettings = new SceneAssetData("DefaultLocationSettings");
                //        }
                //    }
                //}

                return Instance.defaultLocationAssetSettings;
            }
            set
            {
                //try
                //{
                //    var settings = JsonConvert.SerializeObject(value);
                //    EditorPrefs.SetString(GetUserKey(Keys.defaultSceneAssetKey), settings);
                //}
                //catch (Exception ex)
                //{
                //    Debug.LogError("[Environment Settings] Default Scene Settings could not be serialized: " + ex);
                //}

                Instance.defaultLocationAssetSettings = value;
            }
        }

        public static string GetLocalAssetPath(BuildTarget assetPlatform) => Path.Combine(BuildSettings.LocalBuildPath, assetPlatform.ToEngagePlatform().ToString());

        private UploadRegistry uploadedBundles;
        public static UploadRegistry UploadedBundles
        {
            get
            {
                if (Instance.uploadedBundles == null)
                {
                    Instance.uploadedBundles = UploadRegistry.GetUploadHistory();
                }

                return Instance.uploadedBundles;
            }
        }

        public static void RegisterUpload(BundleFile bundle) => UploadedBundles.RegisterUpload(bundle);
        public static void RefreshUploadHistory() => Instance.uploadedBundles = null;
        public static void ClearUploadHistory(BundleFile bundle) => UploadedBundles.ClearUploadHistory(bundle);
        public static void ClearUploadHistory() => UploadedBundles.ClearUploadHistory();
        public static bool WasUploaded(BundleFile bundle) => UploadedBundles.ContainsKey(bundle?.CRC);
    }
}