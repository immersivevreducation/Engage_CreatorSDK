﻿using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class CollectionManagerView : View<CollectionManager>
    {
        private class Labels : Content.Labels
        {
            public const string MenuTitle = "Manage Collections";
            public const string ViewTitle = " Collection Manager";
        }

        //[MenuItem(MenuLabels.EngageAssetManagementPath + Labels.MenuTitle, priority = MenuLabels.ManagerViewPriority + 1)]
        public static void OpenView() => GetWindow<CollectionManagerView>().Open();

        protected Vector2 scrollPosBundles;
        protected string search;
        protected Texture2D defaultTexture;
        protected Texture logo;
        private const int imageScaleUnit = 25;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.LogoPath);
                }

                return logo;
            }
        }

        public Texture2D DefaultThumbnail
        {
            get
            {
                if (defaultTexture == null)
                {
                    defaultTexture = new Texture2D(24, 24);

                    var pixels = new Color[24 * 24];

                    for (int i = 0; i < pixels.Length; i++)
                    {
                        pixels[i] = Color.green;
                    }

                    defaultTexture.SetPixels(pixels);
                }

                return defaultTexture;
            }
        }

        protected Dictionary<string, Texture2D> localThumbnails = new Dictionary<string, Texture2D>();

        private class CollectionDisplaySet
        {
            private readonly HashSet<EngageAssetCollection> displaySet = new HashSet<EngageAssetCollection>();

            public bool this[EngageAssetCollection collection]
            {
                get => displaySet.Contains(collection);
                set
                {
                    if (value)
                    {
                        if (displaySet.Add(collection))
                        {
                            collection.Refresh();
                        }
                    }
                    else
                    {
                        displaySet.Remove(collection);
                    }
                }
            }
        }

        private CollectionDisplaySet locationDisplay = new CollectionDisplaySet();

        private CollectionPresenter<EngageAssetCollection> sortState = new CollectionPresenter<EngageAssetCollection>();

        private Action SortAction(SortOption sortOption, Comparison<EngageAssetCollection> comparer)
        {
            return () =>
            {
                if (sortState.currentSortOption != sortOption)
                {
                    sortState.currentSortOption = sortOption;
                    sortState.currentSortDirection = SortDirection.None;
                }

                sortState.currentSort = comparer;
                sortState.Sort(ViewModel.ItemDisplayList);
            };
        }

        private void ReSort()
        {
            sortState.Sort(ViewModel.ItemDisplayList, true);
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            ViewModel.OnRefreshDisplay += ReSort;
            titleContent = new GUIContent(Labels.ViewTitle, Logo);
        }

        protected override void OnDisable()
        {
            base.OnDisable();
            ViewModel.OnRefreshDisplay -= ReSort;
        }

        public override void Draw()
        {
            using (var updatingArea = new GuiTools.EnabledScope(ViewModel.RefreshStatus != RequestStatus.Requesting))
            {
                ViewTools.DrawEnvironmentHeader();

                EditorGUILayout.Space();

                GuiTools.DrawSearchBar(ref search);

                GUILayout.Space(20);

                DrawCollectionPanel();

                EditorGUILayout.Space();
            }

            EditorGUILayout.Space();

            ViewTools.DrawFooter();
        }

        private void ConfirmDeleteLocation(EngageAssetCollection collection)
        {
            if (EditorUtility.DisplayDialog(
                    title: "Confirm Delete Location",
                    message: $"Permanently delete {collection.PrettyName} from {(collection.Id.HasValue ? "your ENGAGE locations" : "the local cache")}?",
                    ok: Labels.Delete,
                    cancel: Labels.Cancel
                ))
            {
                ViewModel.DeleteCollection(collection);
            }
        }

        private void DrawCollectionPanel()
        {
            using (var collectionPanelContentFrame = new EditorGUILayout.VerticalScope())
            {
                using (var collectionListColumnHeaders = new EditorGUILayout.HorizontalScope())
                {
                    using (var enabled = new GuiTools.EnabledScope(ViewModel.ItemDisplayList?.Count > 0))
                    {
                        GUILayout.Space(imageScaleUnit * 3 + 12);
                        GuiTools.DrawHeader($"{Labels.Name}{sortState.GetSymbol(SortOption.PrettyName)}", SortAction(SortOption.PrettyName, (a, b) => a.PrettyName.ToString().CompareTo(b.PrettyName)), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));
                        //GuiTools.DrawHeader($"{Labels.Description}{sortState.GetSymbol(SortOption.Description)}", SortAction(SortOption.Description, (a, b) => a.Description.ToString().CompareTo(b.Description)), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));
                        GuiTools.DrawHeader($"{Labels.Updated}{sortState.GetSymbol(SortOption.LastUpdated)}", SortAction(SortOption.LastUpdated, (a, b) => a.UpdatedAt.CompareTo(b.UpdatedAt)), GUILayout.Width(CreatorStyle.DATE_WIDTH));
                    }
                }

                using (var scrollArea = new GuiTools.ScrollArea(ref scrollPosBundles, EditorStyles.helpBox))
                {
                    DrawEngageCollectionListView();
                }

                if (GUI.Button(new Rect(collectionPanelContentFrame.rect.width - 40, collectionPanelContentFrame.rect.y - 15, 40, 30), Icons.Refresh.Tooltip("Refresh from server")))
                {
                    ViewModel.RefreshFromServer();
                }
            }
        }

        private void DrawEngageCollectionListView()
        {
            using (var collectionListPanel = new EditorGUILayout.VerticalScope())
            {
                bool even = true;

                foreach (var collection in ViewModel.ItemDisplayList.ToArray())
                {
                    if (string.IsNullOrEmpty(search) || collection.ToString().IndexOf(search, StringComparison.InvariantCultureIgnoreCase) > -1)
                    {
                        DrawEngageCollectionRow(collection, even ? CreatorStyle.RowStyleEven : CreatorStyle.RowStyleOdd);
                        even = !even;
                    }
                }
            }
        }

        private Color GetSyncStateColorCoding(EngageAssetCollection collection)
        {
            if (!collection.Id.HasValue)
            {
                return CreatorStyle.Yellow;
            }

            return GUI.color;
        }

        private void DrawEngageCollectionRow(EngageAssetCollection collection, GUIStyle style)
        {
            using (var engageBundleRow = new EditorGUILayout.HorizontalScope(style, GUILayout.ExpandWidth(false)))
            {
                // thumbnail
                GUILayout.Box(GetThumbnail(collection), GUILayout.Width(imageScaleUnit * 3), GUILayout.Height(imageScaleUnit * 2));

                using (var localScope = new GuiTools.ColorScope(color: GetSyncStateColorCoding(collection)))
                {
                    // Pretty Name
                    EditorGUILayout.LabelField(collection.PrettyName, GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));

                    // TODO: Show indicator for owned Collections
                    // Owner
                    //EditorGUILayout.LabelField(collection.UserId.ToString(), GUILayout.Width(CreatorStyle.PRETTYNAME_WIDTH));

                    // Timestamps
                    //EditorGUILayout.LabelField($"{bundle.CreatedAt}", GUILayout.Width(CreatorStyle.DATE_WIDTH));
                    EditorGUILayout.LabelField($"{collection.UpdatedAt}", GUILayout.Width(CreatorStyle.DATE_WIDTH));

                    // Edit Button
                    //GuiTools.DrawButton(Labels.Edit, () => LocationBuilderView.Edit(collection), GUILayout.Width(CreatorStyle.SHORT_BUTTON_WIDTH));

                    // Delete Button
                    //GuiTools.DrawButton(Labels.Delete, () => ConfirmDeleteLocation(collection), GUILayout.Width(CreatorStyle.SHORT_BUTTON_WIDTH));
                }
            }
        }

        private GUIContent GetThumbnail(EngageAssetCollection collection)
        {
            if (string.IsNullOrEmpty(collection.Image))
            {
                return Icons.Image;
            }

            if (string.IsNullOrEmpty(collection.LocalThumbnailPath))
            {
                collection.LocalThumbnailPath = collection.Image;
            }

            if (!localThumbnails.TryGetValue(collection.LocalThumbnailPath, out Texture2D thumbnail))
            {
                if (File.Exists(collection.LocalThumbnailPath))
                {
                    var bytes = File.ReadAllBytes(collection.LocalThumbnailPath);

                    thumbnail = new Texture2D(2, 2);
                    thumbnail.LoadImage(bytes, true);
                }
                else
                {
                    // Get from url
                }

                localThumbnails.Add(collection.LocalThumbnailPath, thumbnail);
            }

            return new GUIContent(thumbnail);
        }
    }
}