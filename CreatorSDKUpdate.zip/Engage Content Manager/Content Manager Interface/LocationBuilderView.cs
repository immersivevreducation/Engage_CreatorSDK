using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;
using Engage.CreatorSDK;
using System.IO;
using System.Collections.Generic;
using System;

namespace Engage.AssetManagement.Content
{
    public partial class LocationBuilderView : View<LocationBuilder>
    {
        private Vector2 scrollPos;
        private const float verticalSpace = 20f;
        public bool showSpinner;
        private int frame;
        private int ticks;
        private bool buildStarted;
        private LocationStatusPanel locationBuildStatusPanel;
        private Texture logo;

        public Texture Logo
        {
            get
            {
                if (logo == null)
                {
                    logo = AssetDatabase.LoadAssetAtPath<Texture>(Icons.LogoPath);
                }

                return logo;
            }
        }

        private string LocalThumbnailPath
        {
            get
            {
                if (localThumbnail == null && !string.IsNullOrEmpty(ViewModel.LocalThumbnail))
                {
                    UpdateLocalThumbnail(ViewModel.LocalThumbnail);
                }

                return ViewModel.LocalThumbnail;
            }
            set
            {
                if (ViewModel.LocalThumbnail == value)
                    return;

                ViewModel.LocalThumbnail = value;
                UpdateLocalThumbnail(ViewModel.LocalThumbnail);
            }
        }

        private Texture2D localThumbnail;

        private LocationStatusPanel LocationBuildStatusPanel
        {
            get
            {
                if (locationBuildStatusPanel == null)
                {
                    locationBuildStatusPanel = new LocationStartState(this);
                }

                return locationBuildStatusPanel;
            }

            set
            {
                locationBuildStatusPanel = value;
            }
        }

        private class Labels : Content.Labels
        {
            public const string MenuTitle = "Build ENGAGE Location";
            public const string ViewTitle = " Location Builder";
            public const string Build = "Build Location";
            public const string Rebuild = "Rebuild Location";
            public const string ThumbnailSelect = "Select\nThumbnail";

            // TODO: Get some real label values
            public const string ConfirmBuildTitle = "Build Ifx?";
            public const string ConfirmBuildMessage = "We're going to build this IFX now. OK?";

            public const string EmptySelection = "--";

            public const string BatchBuildMode = "Batch Build Mode";
            public const string BatchBuildTooltip = "Batch build mode will create duplicate copies of the project and run the bundle build process in parallel";

            public const string LocalBuildPath = "Local Build Path";
            public const string Scene = "Scene";
            public const string SceneNoneSelected = "No scene selected";
            public const string SceneNoneSelectedMessage = "Please select a Unity scene to build as an ENGAGE location";
            public const string BuildModuleNotInstalledMessage = "Module is not installed";

            public const string Save = "Save";
            public const string SaveTooltip = "Save your locations settings locally without uploading.";

            public const string ThumbnailSelectTitle = "Select Thumbnail Image";
            public const string ThumbnailSelectTooltip = "Select thumbnail image";
            public const string ThumbnailSpecification = "Thumbnail images should be jpeg\nor png, and 750 x 500 pixels.";

            public const string SceneSelected = "Scene Selected";
            public const string RebuildLocationConditionTooltip = "To rebuild this location, select a scene.";
            public const string Bundles = "Bundles";
            public const string ThumbnailUploaded = "Thumbnail Uploaded";

            public const string UpdateLocationTooltip = "Update the details for this Location.";
            public const string RebuildAndUpdateLocationTooltip = "Rebuild and update this Location.";

            public const string BuildLocationTooltip = "Build and upload this Location.";
            public const string LoginTooltip = "You must log with your authorized ENGAGE User account.";

            public const string Building = "Building...";
            public const string Uploading = "Uploading...";
            public const string Done = "Done";

            public const string LocationsStatus = "Locations Status";
            public const string LocationsUpdated = "Locations Updated";
            public const string LocationsCreated = "Locations Created";
        }

        private Dictionary<EngagePlatform, GUIContent> platformIcons;
        public Dictionary<EngagePlatform, GUIContent> PlatformIcons
        {
            get
            {
                platformIcons = new Dictionary<EngagePlatform, GUIContent>()
                {
                    { EngagePlatform.Windows, Icons.WindowsLogoSmall },
                    { EngagePlatform.Android, Icons.AndroidLogoSmall },
                    { EngagePlatform.iOS, Icons.iOSLogoSmall },
                    { EngagePlatform.OSX, Icons.MacLogoSmall }
                };
                return platformIcons;
            }
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            titleContent = new GUIContent(Labels.ViewTitle, Logo);
        }

        [MenuItem(MenuLabels.AssetsToolsPath + Labels.MenuTitle, priority = MenuLabels.BuildViewPriority + 1)]
        [MenuItem(MenuLabels.CreatorSDKToolsPath + Labels.MenuTitle, priority = MenuLabels.BuildViewPriority + 1)]
        public static void OpenView()
        {
            var window = GetWindow<LocationBuilderView>();
            window.Open();
        }
        
        public static void Edit(EngageLocation location)
        {
            var window = GetWindow<LocationBuilderView>();
            window.ViewModel.Edit(location);
            window.Open();
        }

        #region Unity Events
        protected override void OnGUI()
        {
            base.OnGUI();

            if (Event.current.commandName == "ObjectSelectorClosed")
            {
                var scene = EditorGUIUtility.GetObjectPickerObject() as SceneAsset;

                if (scene == null)
                    return;

                Debug.Log($"Selected scene [{scene}]");
                ViewModel.LoadUnityScene(scene);
            }
        }

        protected virtual void Update()
        {
            if (showSpinner)
            {
                ticks++;

                if (ticks > 20)
                {
                    ticks = 0;
                    frame++;
                }

                Repaint();
            }
        }
        #endregion

        protected override void Initialize()
        {
            base.Initialize();

            LocationBuildStatusPanel = new LocationStartState(this);
        }

        public override void Draw()
        {
            ViewTools.DrawEnvironmentHeader();

            EditorGUILayout.Space();

            DrawBuildJob(ViewModel.Job);

            EditorGUILayout.Space();

            EditorGUILayout.Space();

            using (var enableEditing = new GuiTools.EnabledScope(!(LocationBuildStatusPanel is LocationStartState)))
            {

                using (var textArea = new EditorGUILayout.VerticalScope())
                {
                    // Pretty Name field
                    ViewModel.PrettyName = EditorGUILayout.TextField(Labels.Name, ViewModel.PrettyName);

                    EditorGUILayout.Space();

                    // Description field
                    ViewModel.Description = EditorGUILayout.TextField(Labels.Description, ViewModel.Description);

                    EditorGUILayout.Space();
                }

                //Thumbnail field
                var thumbnail = string.IsNullOrEmpty(LocalThumbnailPath) ? Icons.Image : new GUIContent(localThumbnail);
                thumbnail.tooltip = (string.IsNullOrEmpty(ViewModel.LocalThumbnail) ? Labels.ThumbnailSelectTooltip : ViewModel.LocalThumbnail) + "\n\n" + Labels.ThumbnailSpecification;

                if (GUILayout.Button(thumbnail, GUILayout.Height(100), GUILayout.Width(150)))
                {
                    SelectThumbnail();
                }

                EditorGUILayout.Space();

                // Groups field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Groups), ViewModel.Groups, (IGroup group) => group.Name, ViewModel.RemoveGroup, GroupSelectorView.SelectMultiple, ViewModel.AddGroup);

                EditorGUILayout.Space();

                // Collections field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Collections), ViewModel.Collections, (IAssetCollection collection) => collection.PrettyName, ViewModel.RemoveCollection, CollectionSelectorView.SelectMultiple, ViewModel.AddCollection);

                EditorGUILayout.Space();

                // Tags field
                MemberListView.DrawMemberListPanel(nameof(ViewModel.Tags), ViewModel.Tags, (IAssetTag tag) => tag.Name, ViewModel.RemoveTag, TagSelectorView.SelectMultiple, ViewModel.AddTag);
            }

            GUILayout.Space(verticalSpace);

            LocationBuildStatusPanel.Draw();

            ViewTools.DrawFooter(ViewModel.Message);
        }

        private void DrawBuildJob(BundleBuildJob job)
        {
            using (var jobPanel = new EditorGUILayout.VerticalScope())
            {
                var sceneLabel = job == null ? new GUIContent(Labels.SceneNoneSelected, Labels.SceneNoneSelectedMessage)
                    : new GUIContent(ViewModel.UnityAssetName);
                var scenePath = job == null ? new GUIContent(Labels.EmptySelection)
                    : new GUIContent(job.BundlePath);

                using (var labelPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(new GUIContent(Labels.Scene), EditorStyles.boldLabel, GUILayout.Width(EditorGUIUtility.labelWidth));
                    EditorGUILayout.LabelField(sceneLabel, EditorStyles.boldLabel);
                }

                EditorGUILayout.Space();

                using (var scenePathPanel = new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
                {
                    EditorGUILayout.LabelField(scenePath);

                    using (var buildInProgress = new GuiTools.EnabledScope(!buildStarted))
                    {
                        if (GUI.Button(new Rect(scenePathPanel.rect.x + scenePathPanel.rect.width - 22, scenePathPanel.rect.y + (scenePathPanel.rect.height * 0.5f) - 10, 20, 20), new GUIContent(Labels.Ellipsis)))
                        {
                            DrawAssetSelector();
                        }
                    }
                }
            }
        }

        public GUIContent GetSpinner()
        {
            showSpinner = true;
            return Icons.GetWaitSpinner(frame);
        }

        private void DrawAssetSelector()
        {
            EditorGUIUtility.ShowObjectPicker<SceneAsset>(ViewModel.Scene, true, "", EditorGUIUtility.GetControlID(GetInstanceID(), FocusType.Keyboard));
        }

        private void SelectThumbnail()
        {
            var imageTypes = new string[] { "Image", "jpg,jpeg,png", "JPEG", "jpg,jpeg", "Portable Network Graphic", "png" };

            var imagePath = GuiTools.BrowseFilePath(Labels.ThumbnailSelectTitle, ViewModel.LocalThumbnail, imageTypes);

            if (!string.IsNullOrEmpty(imagePath))
            {
                ViewModel.Status |= BuildStatus.ThumbnailSelected;
                LocalThumbnailPath = imagePath;
            }
        }

        private void UpdateLocalThumbnail(string path)
        {
            if (File.Exists(path))
            {
                var bytes = File.ReadAllBytes(path);

                if (localThumbnail == null)
                    localThumbnail = new Texture2D(2, 2);

                localThumbnail.LoadImage(bytes, true);
            }
        }

        public Color GetBackgroundColorCoding(BundleFile file)
        {
            if (file != null)
            {
                return file.Uploaded ? CreatorStyle.Green : CreatorStyle.Red;
            }

            return GUI.backgroundColor;
        }

        private void Save()
        {
            ViewModel.Save();
            Close();
        }

        private void ConfirmCreateLocation()
        {
            ConfirmBuildLocation.OpenDialog(
                this,
                (builder) => EditorGUILayout.LabelField(Labels.ConfirmBuildMessage),
                CreateLocation
                );
        }

        private void CreateLocation()
        {
            buildStarted = true;
            LocationBuildStatusPanel.NextState();
            ViewModel.Start();
        }

        public abstract class BuildStatusPanel<T>
        {
            public abstract void NextState();

            protected T Parent { get; }
            public BuildStatusPanel(T parent)
            {
                Parent = parent;
            }
            public virtual void Draw() { }

            protected void DrawStatusRow(string status, string label)
            {
                DrawStatusRow(new GUIContent(status), new GUIContent(label));
            }

            protected void DrawStatusRow(GUIContent status, string label)
            {
                DrawStatusRow(status, new GUIContent(label));
            }

            protected void DrawStatusRow(GUIContent status, GUIContent label)
            {
                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(string.Empty, GUILayout.Width(10));
                    EditorGUILayout.LabelField(status, GUILayout.Width(30));
                    EditorGUILayout.LabelField(label);
                }
            }
        }

        /// <summary>
        /// Base class for all Location Status State Panels
        /// </summary>
        public abstract class LocationStatusPanel : BuildStatusPanel<LocationBuilderView>
        {
            public LocationStatusPanel(LocationBuilderView parent) : base(parent)
            {
                locationLabel = Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists) ? Labels.LocationsUpdated : Labels.LocationsCreated;
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), Parent.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);

                // DEBUG
                string stateType = GetType().ToString();
                stateLabel = stateType.Substring(stateType.LastIndexOf("+") + 1);
                // DEBUG
            }

            protected Action DrawSaveButton;
            protected Action DrawStartButton;

            protected virtual bool SaveButtonEnabled => true;
            protected virtual bool StartButtonEnabled => true;

            protected BuildStatus Status => Parent?.ViewModel?.Status ?? BuildStatus.None;

            protected string locationLabel;
            protected string stateLabel;

            public virtual void Update() { }

            public virtual void DrawHeader()
            {
                using (var statusPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(Labels.LocationsStatus, EditorStyles.boldLabel);
                    //EditorGUILayout.LabelField(stateLabel);
                }
            }

            public virtual void DrawBody()
            {
                DrawStatusRow("", Labels.SceneSelected);
                DrawStatusRow("", locationLabel);
                DrawStatusRow("", Labels.ThumbnailUploaded);
                DrawStatusRow("", Labels.Bundles);
            }

            public virtual void DrawButtons()
            {
                using (var buttons = new EditorGUILayout.HorizontalScope())
                {
                    using (var saveDisabled = new GuiTools.EnabledScope(SaveButtonEnabled))
                    {
                        DrawSaveButton();
                    }
                    using (var startDisabled = new GuiTools.EnabledScope(StartButtonEnabled))
                    {
                        DrawStartButton();
                    }
                }
            }

            public override void Draw()
            {
                DrawHeader();

                using (var buildOptions = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
                {
                    DrawBody();
                }

                EditorGUILayout.LabelField("", GUILayout.ExpandHeight(true));

                DrawButtons();

                Update();
            }
        }

        /// <summary>
        /// Error state
        /// </summary>
        public class ErrorState : LocationStatusPanel
        {
            public override void NextState()
            {
                Debug.Log("Welcome to Error Town!");
            }

            public ErrorState(LocationBuilderView parent) : base(parent)
            {
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.Warning, "Scene selected: " + Parent.ViewModel.Status.HasFlag(BuildStatus.UnityAssetSelected));
                DrawStatusRow(Icons.Warning, "Location created: " + Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists));
                DrawStatusRow(Icons.Warning, "Thumbnail selected: " + Parent.ViewModel.Status.HasFlag(BuildStatus.ThumbnailSelected));
                DrawStatusRow(Icons.Warning, "Thumbnail uploaded: " + Parent.ViewModel.Status.HasFlag(BuildStatus.ThumbnailUploaded));
                DrawStatusRow(Icons.Warning, "Bundles Built: " + Parent.ViewModel.Status.HasFlag(BuildStatus.BundlesExist));
                DrawStatusRow(Icons.Warning, "Bundles uploaded: " + Parent.ViewModel.Status.HasFlag(BuildStatus.BundlesUploaded));
            }
        }

        /// <summary>
        /// Starting default Location state
        /// </summary>
        public class LocationStartState : LocationStatusPanel
        {
            public LocationStartState(LocationBuilderView parent) : base(parent) { }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    Parent.LocationBuildStatusPanel = new LocationBuildReadyState(Parent);
                }
                else
                {
                    Parent.LocationBuildStatusPanel = new LocationUpdateReadyState(Parent);
                }
            }

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetExists) || Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Error.Tooltip(Labels.SceneNoneSelectedMessage), Labels.SceneSelected);
                DrawStatusRow("", locationLabel);
                DrawStatusRow("", Labels.ThumbnailUploaded);
                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State for starting update of existing Location with no Scene asset selected.
        /// </summary>
        public class LocationUpdateReadyState : LocationStatusPanel
        {
            public LocationUpdateReadyState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Update, Labels.UpdateLocationTooltip), Parent.CreateLocation);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;

            protected bool isRebuild;
            public override void NextState() => Parent.LocationBuildStatusPanel = new UpdatingLocationState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected) && !isRebuild)
                {
                    DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Rebuild, Labels.RebuildAndUpdateLocationTooltip), Parent.ConfirmCreateLocation);
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Parent.ViewModel.Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.Warning.Tooltip(Labels.RebuildLocationConditionTooltip), Labels.SceneSelected);
                DrawStatusRow("", locationLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }
        }

        /// <summary>
        /// State for the update of existing Location's details and optionally thumbnail.
        /// </summary>
        public class UpdatingLocationState : LocationStatusPanel
        {
            public UpdatingLocationState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Update), null);
            }

            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.LocationBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Status.HasFlag(BuildStatus.EngageAssetUpdated))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.SceneSelected);
                DrawStatusRow(Status.HasFlag(BuildStatus.EngageAssetUpdated) ? Icons.TestPassed : Parent.GetSpinner(), locationLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.SceneSelected);
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }
        }

        /// <summary>
        /// Completed state for Update process.
        /// </summary>
        public class LocationUpdateCompleteState : LocationStatusPanel
        {
            public LocationUpdateCompleteState(LocationBuilderView parent) : base(parent)
            {
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }

            protected override bool SaveButtonEnabled => false;
            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestSkipped, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, locationLabel);
                DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                DrawStatusRow(Icons.TestSkipped, Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which Scene asset has been selected and the creation process is started.
        /// </summary>
        public class LocationBuildReadyState : LocationStatusPanel
        {
            public LocationBuildReadyState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save, Labels.SaveTooltip), Parent.ViewModel.Save);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build, BuildButtonTooltop), Parent.ConfirmCreateLocation);
            }

            protected override bool SaveButtonEnabled => true;
            protected override bool StartButtonEnabled => EngageUser.IsAuthenticated;
            protected string BuildButtonTooltop => StartButtonEnabled ? Labels.BuildLocationTooltip : Labels.LoginTooltip;

            public override void NextState() => Parent.LocationBuildStatusPanel = new CreatingLocationState(Parent);

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow("", locationLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);

                // NOTE: Batch Mode will be supported in a later release
                // Batch Build Mode
                //Parent.ViewModel.BatchBuild = EditorGUILayout.Toggle(new GUIContent(Labels.BatchBuildMode, Labels.BatchBuildTooltip), Parent.ViewModel.BatchBuild);
            }
        }

        /// <summary>
        /// State in which the Location is created or updated.
        /// </summary>
        public class CreatingLocationState : LocationStatusPanel
        {
            public CreatingLocationState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.LocationBuildStatusPanel = new UploadingThumbnailState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.Status.HasFlag(BuildStatus.EngageAssetExists))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Parent.GetSpinner(), locationLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow("", Labels.ThumbnailUploaded);
                }

                DrawStatusRow("", Labels.Bundles);
            }
        }

        /// <summary>
        /// State in which the Thumbnail is uploaded.
        /// </summary>
        public class UploadingThumbnailState : LocationStatusPanel
        {
            public UploadingThumbnailState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState()
            {
                if (Status.HasFlag(BuildStatus.UnityAssetSelected))
                {
                    Parent.LocationBuildStatusPanel = new BuildingLocationBundlesState(Parent);
                }
                else
                {
                    Parent.LocationBuildStatusPanel = new LocationUpdateCompleteState(Parent);
                }
            }

            public override void Update()
            {
                if (!Status.HasFlag(BuildStatus.ThumbnailSelected))
                {
                    NextState();
                }

                if (Status.HasFlag(BuildStatus.ThumbnailUploaded))
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Status.HasFlag(BuildStatus.UnityAssetSelected) ? Icons.TestPassed : Icons.TestSkipped, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, locationLabel);

                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField(string.Empty, GUILayout.Width(10));
                    EditorGUILayout.LabelField(Parent.GetSpinner(), GUILayout.Width(30));
                    EditorGUILayout.LabelField(Labels.ThumbnailUploaded);

                    using (var progressBar = new EditorGUILayout.HorizontalScope())
                    {
                        GUILayout.Box(new GUIContent());

                        var progress = Parent.ViewModel.ThumbnailUploadProgress;
                        EditorGUI.ProgressBar(progressBar.rect, progress, $"{progress * 100:F0}%");
                    }
                }

                using (var sceneSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.UnityAssetSelected)))
                {
                    DrawStatusRow("", Labels.Bundles);
                }
            }

            public override void DrawButtons()
            {
                using (var actionsEnabled = new GuiTools.EnabledScope(false))
                {
                    base.DrawButtons();
                }
            }
        }

        /// <summary>
        /// State in which the Build and upload status are displayed.
        /// </summary>
        public class BuildingLocationBundlesState : LocationStatusPanel
        {
            public BuildingLocationBundlesState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Build), null);
            }
            protected override bool SaveButtonEnabled => false;
            protected override bool StartButtonEnabled => false;

            public override void NextState() => Parent.LocationBuildStatusPanel = new CompleteState(Parent);

            public override void Update()
            {
                if (Parent.ViewModel.LocalFiles.Uploaded == (EngagePlatform.Windows | EngagePlatform.Android | EngagePlatform.iOS | EngagePlatform.OSX))// Parent.ViewModel.Job.BuildTargets)
                {
                    NextState();
                }
            }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, locationLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Parent.GetSpinner(), Labels.Bundles);

                foreach (var platform in new EngagePlatform[] { EngagePlatform.Windows, EngagePlatform.Android, EngagePlatform.iOS, EngagePlatform.OSX })
                {
                    DrawPlatformStatus(platform);
                }
            }

            public void DrawPlatformStatus(EngagePlatform platform)
            {
                bool built = Parent.ViewModel.LocalFiles.ContainsKey(platform);
                bool uploaded = built ? Parent.ViewModel.LocalFiles[platform].Uploaded : false;

                var status = built ? uploaded ? Icons.TestPassed : Parent.GetSpinner() : new GUIContent();
                var icon = Parent.PlatformIcons[platform];

                using (var opPanel = new EditorGUILayout.HorizontalScope())
                {
                    EditorGUILayout.LabelField("", GUILayout.Width(40));
                    EditorGUILayout.LabelField(status, GUILayout.Width(40));
                    EditorGUILayout.LabelField(icon, GUILayout.Width(40));

                    string processLabel = !built ? Labels.Building : !uploaded ? Labels.Uploading : Labels.Done;

                    EditorGUILayout.LabelField(processLabel, GUILayout.Width(100));

                    if (built && !uploaded)
                    {
                        using (var progressBar = new EditorGUILayout.HorizontalScope())
                        {
                            GUILayout.Box(new GUIContent());

                            var progress = Parent.ViewModel.LocalFiles[platform].UploadProgress;
                            EditorGUI.ProgressBar(progressBar.rect, progress, $"{progress * 100:F0}%");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// State in which all processes are completed, and the window can then be closed.
        /// </summary>
        public class CompleteState : LocationStatusPanel
        {
            public CompleteState(LocationBuilderView parent) : base(parent)
            {
                DrawSaveButton = () => GuiTools.DrawButton(new GUIContent(Labels.Save), null);
                DrawStartButton = () => GuiTools.DrawButton(new GUIContent(Labels.Close), Parent.Close);
            }
            protected override bool SaveButtonEnabled => false;

            public override void NextState() { }

            public override void DrawBody()
            {
                DrawStatusRow(Icons.TestPassed, Labels.SceneSelected);
                DrawStatusRow(Icons.TestPassed, locationLabel);

                using (var thumbnailSelected = new GuiTools.EnabledScope(Status.HasFlag(BuildStatus.ThumbnailSelected)))
                {
                    DrawStatusRow(Status.HasFlag(BuildStatus.ThumbnailUploaded) ? Icons.TestPassed : Icons.TestSkipped, Labels.ThumbnailUploaded);
                }

                DrawStatusRow(Icons.TestPassed, Labels.Bundles);
            }
        }

        public class ConfirmBuildLocation : EngageConfirmDialog<LocationBuilderView>
        {
            protected const int heightExtent = 100;
            protected const int widthExtent = 150;

            public static void OpenDialog(
                LocationBuilderView view,
                Action<LocationBuilderView> drawMessageBody,
                Action confirmCallback = null,
                Action cancelCallback = null
                )
            {
                var dialog = GetWindow<ConfirmBuildLocation>(Labels.ConfirmBuildTitle);

                dialog.DrawMessageBody = drawMessageBody;
                dialog.onConfirm = confirmCallback;
                dialog.onCancel = cancelCallback;

                var extents = new Vector2(widthExtent, heightExtent);

                dialog.position = new Rect(view.position.center - extents, extents * 2);

                dialog.ShowModalUtility();
            }
        }
    }
}