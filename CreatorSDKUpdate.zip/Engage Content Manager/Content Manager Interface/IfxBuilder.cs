using UnityEditor;
using UnityEngine;
using Engage.UI.Editor;
using Engage.CreatorSDK;

namespace Engage.AssetManagement.Content
{
    public class IfxBuilder : AssetBuilder<EngageIFX>
    {
        protected IfxAssetDataModule DataModule => DataManager.Module<IfxAssetDataModule>();

        public GameObject Prefab { get; protected set; }
        public override string UnityAssetName => Prefab?.name;

        public override void LoadEngageAsset(string guid)
        {
            if (string.IsNullOrEmpty(guid))
                return;

            // Finds saved local settings for this asset
            if (DataModule.TryGetLocal(guid, out IIfxAsset asset))
            {
                EngageAsset = new EngageIFX(asset);
            }
            else
            {
                EngageAsset = new EngageIFX();
            }

            LoadEngageAsset(EngageAsset);
        }

        public override void LoadUnityAsset(string guid)
        {
            if (string.IsNullOrEmpty(guid))
            {
                Status &= ~BuildStatus.UnityAssetSelected;
                Job = null;
                Message = $"No scene selected";
                Debug.LogWarning($"[Location Builder] {Message}");
                return;
            }

            var path = AssetDatabase.GUIDToAssetPath(guid);
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);

            LoadUnityPrefab(prefab);
        }

        public void LoadUnityPrefab(GameObject prefab)
        {
            Status &= ~BuildStatus.UnityAssetSelected;

            if (prefab == null)
            {
                Job = null;
                Message = $"Selected object is not a scene";
                Debug.LogWarning($"[Location Builder] {Message}");
                return;
            }

            Status |= BuildStatus.UnityAssetSelected;

            Prefab = prefab;
            string guid = Prefab.GetGUID();

            // Location data empty or unsaved
            if (string.IsNullOrEmpty(EngageAsset.Name))
            {
                LoadEngageAsset(guid);
                PrettyName = UnityAssetName.ToPretty();
            }

            Job = new BundleBuildJob(guid);
            Job.BundleLabel = guid;
            Job.OnComplete += OnBuildComplete;

            LoadLocalFiles(guid);

            NotifyPropertyChange(nameof(Job));
        }
    }
}