﻿using System.Collections.Generic;
using UnityEditor;
using Engage.CreatorSDK;

namespace Engage.AssetManagement.Content
{
    public enum EngageFileType
    {
        Unknown = -1,
        Bundle = 0,
        Manifest = 1
    }

    //public enum AssetType
    //{
    //    Mixed = -1,
    //    Undefined = 0,
    //    Location = 1,
    //    IFX = 2,
    //    Snapshot
    //}

    public enum AssetPrivacy
    {
        Private, Public, Mixed
    }

    public enum EngageTarget
    {
        Unspecified = 0, Common = 1, Client = 2
    }

    public class BundleTarget
    {
        public EngageTarget id;
        public string name;
    }

    //[Flags]
    //public enum EngagePlatform
    //{
    //    None = 0x00,
    //    Android = 0x01,
    //    iOS = 0x02,
    //    OSX = 0x04,
    //    WebGL = 0x08,
    //    Windows = 0x10
    //}

    public static class BundleFileExtensions
    {
        //public static BundleFileFormData.AssetType ToBundleFileType(this BundleFileFormData.AssetType type)
        //{
        //    switch (type)
        //    {
        //        //case AssetType.Mixed: return BundleFileFormData.AssetType.Mixed;
        //        case AssetType.Location: return BundleFileFormData.AssetType.Location;
        //        case AssetType.IFX: return BundleFileFormData.AssetType.IFX;
        //        default: return BundleFileFormData.AssetType.Undefined;
        //    }
        //}

        public static BundleFileFormData.Platform ToBundleFilePlatform(this EngagePlatform platform)
        {
            switch (platform)
            {
                case EngagePlatform.Android: return BundleFileFormData.Platform.Android;
                case EngagePlatform.iOS: return BundleFileFormData.Platform.iOS;
                case EngagePlatform.OSX: return BundleFileFormData.Platform.OSX;
                case EngagePlatform.Windows: return BundleFileFormData.Platform.Windows;
                default: return BundleFileFormData.Platform.Undefined;
            }
        }

        public static EngagePlatform ToEngagePlatform(this BuildTarget target)
        {
            switch (target)
            {
                case BuildTarget.Android: return EngagePlatform.Android;
                case BuildTarget.iOS: return EngagePlatform.iOS;
                case BuildTarget.StandaloneOSX: return EngagePlatform.OSX;
                case BuildTarget.WebGL: return EngagePlatform.WebGL;
                case BuildTarget.StandaloneWindows:
                case BuildTarget.StandaloneWindows64: return EngagePlatform.Windows;
                default: return EngagePlatform.None;
            }
        }

        public static BuildTarget ToBuildTarget(this EngagePlatform platform)
        {
            switch (platform)
            {
                case EngagePlatform.Android: return BuildTarget.Android;
                case EngagePlatform.iOS: return BuildTarget.iOS;
                case EngagePlatform.OSX: return BuildTarget.StandaloneOSX;
                default:
                case EngagePlatform.Windows: return BuildTarget.StandaloneWindows;
            }
        }

        public static string ToString(this EngagePlatform platform)
        {
            var buildTargets = new List<string>();

            foreach (EngagePlatform target in System.Enum.GetValues(typeof(EngagePlatform)))
            {
                if (target > EngagePlatform.None && platform.HasFlag(target))
                {
                    buildTargets.Add(target.ToString());
                }
            }

            return string.Join(", ", buildTargets);
        }
    }
}