﻿using Engage.Network;
using Engage.UI.Editor;
using Newtonsoft.Json;
using System;

namespace Engage.AssetManagement.Content
{
    [JsonObject(MemberSerialization.OptIn)]
    public class EngageAssetTag : ViewModel, IAssetTag
    {
        protected AssetTagDataModule DataModule => DataManager.Module<AssetTagDataModule>();
        public override string ToString() => EnglishName;

        private AssetTagData resetTag = new AssetTagData();

        private DateTime? created;
        private DateTime? updated;

        public int? Id => resetTag.Id;
        public string CreatedAt => created?.ToString("yyyy-MM-dd") ?? "-";
        public string UpdatedAt => updated?.ToString("yyyy-MM-dd") ?? "-";
        public Glossary Name { get; set; }

        public string EnglishName
        {
            get => Name;
            set
            {
                if (Name == null)
                {
                    Name = (Glossary)value;
                }
                else
                {
                    Name["en"] = value;
                }

                NotifyPropertyChange(nameof(EnglishName));
            }
        }

        public string CurrentName => resetTag.Name;


        #region Management Status
        protected RequestStatus status = RequestStatus.None;
        protected SyncStatus sync = SyncStatus.Local;

        public RequestStatus RequestStatus
        {
            get => status;
            protected set
            {
                status = value;
                NotifyPropertyChange(nameof(RequestStatus));
            }
        }
        public SyncStatus SyncStatus
        {
            get => sync;
            protected set
            {
                sync = value;
                NotifyPropertyChange(nameof(SyncStatus));
            }
        }
        #endregion

        public EngageAssetTag(IAssetTag tag)
        {
            resetTag.SetValues(tag);
            Reset();
        }

        public EngageAssetTag(string tagName)
        {
            EnglishName = tagName;
            created = DateTime.Now;
            resetTag.SetValues(this);
        }

        public void EditTag()
        {
            SyncStatus = SyncStatus.UncommittedChanges;
        }

        public void Reset()
        {
            Name = resetTag.Name;

            created = DateTime.TryParse(resetTag.CreatedAt, out DateTime createdAt) ? createdAt : (DateTime?)null;
            updated = DateTime.TryParse(resetTag.UpdatedAt, out DateTime updatedAt) ? updatedAt : (DateTime?)null;

            SyncStatus = resetTag.Id.HasValue ? SyncStatus.Synced : SyncStatus.Local;

            NotifyPropertyChange(nameof(Reset));
        }

        public async void CreateTag()
        {
            RequestStatus = RequestStatus.Requesting;
            var tag = await DataModule.CreateAsync(this);

            if (tag != null)
            {
                resetTag.SetValues(tag);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }
        }

        public async void UpdateTag()
        {
            if (!resetTag.Id.HasValue)
            {
                Reset();
                return;
            }

            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UpdateAsync(this);

            if (success)
            {
                resetTag.SetValues(this);
                RequestStatus = RequestStatus.Complete;
                SyncStatus = SyncStatus.Synced;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
                SyncStatus = SyncStatus.UncommittedChanges;
            }
        }
    }

}
