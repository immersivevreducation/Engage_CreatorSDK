﻿using Engage.Network;
using Engage.UI.Editor;
using Newtonsoft.Json;
using System;

namespace Engage.AssetManagement.Content
{
    [JsonObject(MemberSerialization.OptIn)]
    public class EngageGroup : ViewModel, IGroup
    {
        protected GroupDataModule DataModule => DataManager.Module<GroupDataModule>();

        public override string ToString() => Name;

        protected GroupData resetGroup = new GroupData();

        protected DateTime? created;
        protected DateTime? updated;

        public int? Id => resetGroup.Id;
        public string CreatedAt => created?.ToString("yyyy-MM-dd") ?? "-";
        public string UpdatedAt => updated?.ToString("yyyy-MM-dd") ?? "-";
        public string Image { get; set; }

        public string Name { get; set; }

        #region Management Status
        protected RequestStatus status = RequestStatus.None;
        protected SyncStatus sync = SyncStatus.Local;

        public RequestStatus RequestStatus
        {
            get => status;
            protected set
            {
                status = value;
                NotifyPropertyChange(nameof(RequestStatus));
            }
        }
        public SyncStatus SyncStatus
        {
            get => sync;
            protected set
            {
                sync = value;
                NotifyPropertyChange(nameof(SyncStatus));
            }
        }
        #endregion

        public EngageGroup(IGroup group)
        {
            resetGroup.SetValues(group);
            Reset();
        }

        public EngageGroup(string groupName)
        {
            Name = groupName;
            created = DateTime.Now;
            resetGroup.SetValues(this);
        }

        public void Reset()
        {
            Name = resetGroup.Name;

            created = DateTime.TryParse(resetGroup.CreatedAt, out DateTime createdAt) ? createdAt : (DateTime?)null;
            updated = DateTime.TryParse(resetGroup.UpdatedAt, out DateTime updatedAt) ? updatedAt : (DateTime?)null;

            SyncStatus = resetGroup.Id.HasValue ? SyncStatus.Synced : SyncStatus.Local;

            NotifyPropertyChange(nameof(Reset));
        }

        public async void CreateGroup()
        {
            RequestStatus = RequestStatus.Requesting;
            var group = await DataModule.CreateAsync(this);

            if (group != null)
            {
                resetGroup.SetValues(group);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }
        }

        public async void UpdateGroup()
        {
            if (!resetGroup.Id.HasValue)
            {
                Reset();
                return;
            }

            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UpdateAsync(this);

            if (success)
            {
                resetGroup.SetValues(this);
                RequestStatus = RequestStatus.Complete;
                SyncStatus = SyncStatus.Synced;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
                SyncStatus = SyncStatus.UncommittedChanges;
            }
        }
    }

}
