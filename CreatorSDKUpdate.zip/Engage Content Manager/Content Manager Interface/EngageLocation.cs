﻿using Engage.CreatorSDK;
using Engage.Network;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    /// <summary>
    /// View model for interacting with Location Assets.
    /// </summary>
    [JsonObject(MemberSerialization.OptIn)]
    public class EngageLocation : EngageAsset, ILocationAsset
    {
        protected override IAsset Asset { get => resetLocationAsset; set => _ = value; }
        protected LocationAssetData resetLocationAsset = new LocationAssetData();
        protected LocationAssetDataModule DataModule => DataManager.Module<LocationAssetDataModule>();

        #region ILocationAsset Properties
        public int? BaseLocationId
        {
            get => BaseLocation?.Id;
            set
            {
                if (BaseLocation?.Id == value)
                    return;

                if (value.HasValue && DataModule.TryGet(value.Value, out ILocationAsset scene))
                {
                    BaseLocation = scene;
                }
                else
                {
                    BaseLocation = null;
                }
            }
        }
        public int? BrandingGroupId
        {
            get => BrandingGroup?.Id;
            set
            {
                if (BrandingGroup?.Id == value)
                    return;

                if (value.HasValue && DataManager.Module<GroupDataModule>().TryGet(value.Value, out IGroup group))
                {
                    BrandingGroup = group;
                }
                else
                {
                    BrandingGroup = null;
                }
            }
        }
        #endregion

        public ILocationAsset BaseLocation { get; set; }
        public IGroup BrandingGroup { get; set; }

        protected override void InitializeSyncStatusManager()
        {
            base.InitializeSyncStatusManager();

            syncStatusManager.RegisterProperty(nameof(BaseLocation), () => BaseLocationId != resetLocationAsset.BaseLocationId);
            syncStatusManager.RegisterProperty(nameof(BrandingGroup), () => BrandingGroupId != resetLocationAsset.BrandingGroupId);
        }

        #region Constructors
        public EngageLocation()
        {
            // TODO: Implement configurable default settings
            //resetSceneAsset.SetValues(Environment.DefaultSceneAssetSettings);
        }

        public EngageLocation(ILocationAsset asset)
        {
            resetLocationAsset.SetValues(asset);
            Reset();
        }
        #endregion

        public override void Reset()
        {
            base.Reset();

            BaseLocationId = resetLocationAsset.BaseLocationId;
            BrandingGroupId = resetLocationAsset.BrandingGroupId;
        }

        public async override Task CreateAssetAsync()
        {
            RequestStatus = RequestStatus.Requesting;

            var asset = await DataModule.CreateAsync(this);

            if (asset != null)
            {
                resetLocationAsset.SetValues(asset);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            return;
        }
        public async override void CreateAsset()
        {
            await CreateAssetAsync();
        }

        public async override Task UpdateAssetAsync()
        {
            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UpdateAsync(this);

            if (success)
            {
                resetLocationAsset.SetValues(this);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            return;
        }
        public async override void UpdateAsset()
        {
            await UpdateAssetAsync();
        }

        public override void UploadThumbnail()
        {
            UploadThumbnail((progress) => { Progress = progress; });
        }
        public async override void UploadThumbnail(Action<float> progressCallback, Action<bool> onComplete = null)
        {
            RequestStatus = RequestStatus.Requesting;

            var success = await DataModule.UploadThumbnail(
                this,
                LocalThumbnailPath,
                progressCallback);

            if (success)
            {
                var item = DataModule.Get(Id.Value);
                resetLocationAsset.SetValues(item);
                Reset();

                RequestStatus = RequestStatus.Complete;
            }
            else
            {
                RequestStatus = RequestStatus.Error;
            }

            onComplete?.Invoke(success);
        }

        public void SetBrandingGroup(IGroup group)
        {
            BrandingGroupId = group?.Id ?? null;
        }

        public async override void UploadBundle(EngagePlatform platform, BundleFile localFile, Action<BundleFile, float> update, Action<BundleFile, bool> complete)
        {
            if (localFile == null)
            {
                return;
            }

            if (localFile.Status == RequestStatus.Requesting)
            {
                Debug.LogWarning($"[Bundle Upload] {Name} ({platform}) already requesting upload.");
                return;
            }

            localFile.Status = RequestStatus.Requesting;

            update?.Invoke(localFile, localFile.UploadProgress);

            if (update != null)
            {
                localFile.OnProgressUpdated += update;
            }

            var success = await DataModule.UploadBundle(this, localFile);

            if (update != null)
            {
                localFile.OnProgressUpdated -= update;
            }

            if (success)
            {
                localFile.Status = RequestStatus.Complete;
                EngageUser.RegisterUpload(localFile);
                Debug.Log($"[Engage Bundle] {Name} ({platform}) successfully uploaded.");
            }
            else
            {
                localFile.Status = RequestStatus.Error;
                Debug.LogWarning($"[Engage Bundle] {Name} ({platform}) was not uploaded.");
            }

            update?.Invoke(localFile, localFile.UploadProgress);
            complete?.Invoke(localFile, success);
        }

        internal void CreateLocation()
        {
            throw new NotImplementedException();
        }

        public override void UploadAllBundles() => UploadAllBundles(null);

        public override void UploadAllBundles(Action update)
        {
            //if (LocalFiles == null)
            //    return;

            //foreach (var fileSet in LocalFiles)
            //{
            //    UploadBundle(fileSet.Key, update);
            //}
        }

        public override void Save()
        {
            if (DataModule.TryGetLocal(Name, out ILocationAsset location))
            {
                DataModule.Update(this);
            }
            else
            {
                DataModule.Create(this);
            }

            Debug.Log($"[Location] Location {PrettyName} saved.");
        }

        public override void DeleteAsset()
        {
            DataModule.DeleteLocal(Name);

            if (Id.HasValue)
            {
                DataModule.DeleteAsync(this);
            }
        }
    }
}

