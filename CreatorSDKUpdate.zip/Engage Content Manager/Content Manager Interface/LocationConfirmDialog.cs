﻿using System;
using UnityEditor;

namespace Engage.AssetManagement.Content
{
    public class LocationConfirmDialog : EngageItemListView<EngageLocation, EngageItemList>
    {
        public static void ConfirmSelection(string title, string message, EngageLocation[] selected, Action confirmCallback = null, Action cancelCallback = null)
        {
            var window = GetConfirmDialog(title, message, selected, confirmCallback, cancelCallback);

            window.Center();
            window.ShowUtility();
        }

        public static LocationConfirmDialog GetConfirmDialog(string title, string message, EngageLocation[] selected, Action confirmCallback = null, Action cancelCallback = null)
        {
            var window = GetWindow<LocationConfirmDialog>(title);

            window.Selected.Clear();
            window.Selected.AddRange(selected);

            window.DrawItem = (item) => EditorGUILayout.LabelField(item.ToString());
            window.DrawMessage = () => EditorGUILayout.LabelField(message);

            window.onConfirm = confirmCallback;
            window.onCancel = cancelCallback;

            return window;
        }
    }
}
