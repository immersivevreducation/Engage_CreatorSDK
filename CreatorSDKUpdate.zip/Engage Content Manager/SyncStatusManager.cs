﻿using Engage.Network;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Engage.AssetManagement.Content
{
    public class SyncStatusManager
    {
        private SyncStatus status = SyncStatus.None;

        private class Property
        {
            public readonly string name;
            public readonly Func<bool> test;

            public Property(string name, Func<bool> test)
            {
                this.name = name;
                this.test = test;
            }
        }

        private class Collection<T> : Property
        {
            public readonly Predicate<T> memberTest;

            public Collection(string name, Func<bool> test, Predicate<T> memberTest) : base(name, test)
            {
                this.memberTest = memberTest;
            }
        }

        private List<Property> propertyRegistry = new List<Property>();

        public bool HasUpdates => propertyRegistry.Any(property => property.test.Invoke());

        public event Action<string> OnStatusChanged;
        public SyncStatus Status
        {
            get => HasUpdates ? SyncStatus.UncommittedChanges : status;
            set
            {
                bool statusChanged = status != value;

                status = value;
                
                if (statusChanged)
                    OnStatusChanged?.Invoke(nameof(Status));
            }
        }

        public void RegisterProperty(string propertyName, Func<bool> test)
        {
            propertyRegistry.RemoveAll(property => property.name == propertyName);
            propertyRegistry.Add(new Property(propertyName, test));
        }

        public void RegisterCollection<T>(string collectionName, Func<bool> test, Predicate<T> memberTest)
        {
            propertyRegistry.RemoveAll(property => property.name == collectionName);
            propertyRegistry.Add(new Collection<T>(collectionName, test, memberTest));
        }

        public bool PropertyUpdated(string propertyName) => propertyRegistry.FirstOrDefault(property => property.name == propertyName)?.test?.Invoke() ?? false;
        public bool CollectionUpdated<T>(string collectionName, T member)
        {
            var collection = propertyRegistry.FirstOrDefault(property => property.name == collectionName) as Collection<T>;

            return collection?.memberTest(member) ?? false;
        }
    }
}
