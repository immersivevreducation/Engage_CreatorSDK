﻿using Engage.Network;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class Labels
    {
        public const string CreateButton = "Create";
        public const string CreateSelectedButton = "Create Selected";
        public const string CreateAllButton = "Create All";

        public const string NotAuthenticated = "User not currently authenticated";
        public const string LoginPrompt = "Please login using your authorized ENGAGE account";

        public const string UserName = "User Name";
        public const string UserNameTooltip = "User name or email";
        public const string Password = "Password";
        public const string Login = "Log in";
        public const string Logout = "Log out";
        public const string EngageUser = "Engage User";

        public const string Select = "Select";
        public const string Id = "ID";
        public const string Name = "Name";
        public const string PrettyName = "Pretty Name";
        public const string Project = "Project";
        public const string AssetType = "Asset Type";
        public const string Created = "Created On";
        public const string Updated = "Last Updated";
        public const string Ifx = "IFX";
        public const string Location = "Location";
        public const string AssetTarget = "Target";
        public const string LocalFiles = "Local Files";
        public const string Status = "Status";
        public const string Thumbnail = "Thumbnail";
        public const string Description = "Description";
        public const string Category = "Category";
        public const string SortOrder = "Sort Order";
        public const string Parameters = "Parameters";
        public const string IsPrivate = "Privacy";
        public const string IsPremium = "Premium";
        public const string EditorOnly = "Editor Only";
        public const string Unlisted = "Unlisted";
        public const string AssetStatus = "Asset Status";
        public const string Scale = "Scale";
        public const string SceneScale = "Scene Scale";
        public const string BaseLocation = "Base Location";
        public const string BrandingGroup = "Branding Group";

        public const string OK = "OK";
        public const string Yes = "Yes";
        public const string No = "No";
        public const string Close = "Close";
        public const string Cancel = "Cancel";
        public const string Clear = "Clear";
        public const string Edit = "Edit";
        public const string Manage = "Manage";
        public const string Refresh = "Refresh";
        public const string SetDefault = "Set Default";

        public const string Create = "Create";
        public const string Update = "Update";
        public const string Delete = "Delete";
        public const string UploadAll = "Upload All";
        public const string Upload = "Upload";
        public const string Uploaded = "Uploaded";

        public const string RefreshFromServer = "Refresh From Server";
        public const string LastRefresh = "Last Refresh";
        public const string DataStale = "Data last refreshed over a day ago. Please log in to refresh.";
        public const string NoLastRefreshValue = "???";

        public const string ChangeBundleConfirm = "Change Bundle Association";
        public const string ChangeBundleConfirmMessage = "Are you sure you want to change the Bundle this asset is associated with?";

        public const string IfxExplanation = "These are the IFX entries associated with this Bundle";
        public const string LocalFileExplanation = "These are the local bundle files associated with this Bundle and their contents";
        public const string LocationExplanation = "These are the Location entries associated with this Bundle";
        public const string RefreshFilesTooltip = "Refresh local file information";

        public const string ProjectDoesntExist = "Project [{0}] does not yet exist in Database";
        public const string BundleDoesntExist = "Bundle [{0}] does not yet exist in Database";
        public const string EntityNameProblem = "Name contains illegal characters";

        public const string BundleProblemMixed = "Asset Bundle contains mixed asset types";
        public const string BundleProblemName = "Asset Bundle contains asset name with illegal characters";
        public const string BundleProblemEmpty = "Asset Bundle is empty or unreadable";
        public const string BundleProblemUnbuilt = "There is no Asset Bundle file present";

        //public static Dictionary<BundleProblem, string> BundleProblemDescription = new Dictionary<BundleProblem, string>()
        //{
        //    { BundleProblem.None, string.Empty },
        //    { BundleProblem.MixedTypes, BundleProblemMixed },
        //    { BundleProblem.NameFormat, BundleProblemName },
        //    { BundleProblem.Empty, BundleProblemEmpty },
        //};

        public const string SyncStatusLocal = "This item only exists locally";
        public const string SyncStatusUncommittedChanges = "The item has uncommitted changes";
        public const string SyncStatusSynced = "This item is fully synced";
        public const string SyncStatusRemote = "This item has no local files";

        public static Dictionary<SyncStatus, string> SyncStatusDescription = new Dictionary<SyncStatus, string>()
        {
            { SyncStatus.None, string.Empty },
            { SyncStatus.Local, SyncStatusLocal },
            { SyncStatus.UncommittedChanges, SyncStatusUncommittedChanges },
            { SyncStatus.Synced, SyncStatusSynced },
            { SyncStatus.Remote, SyncStatusRemote }
        };

        /* ICONS */
        public const string Checkbox = "☑";
        public const string XButton = "✕";
        public const string Ellipsis = "⋯";
        public const string Plus = "＋";
    }
}