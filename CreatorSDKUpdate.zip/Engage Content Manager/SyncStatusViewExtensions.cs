﻿using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{

    public static class SyncStatusViewExtensions
    {
        public static Color ToColorCode(this SyncStatus syncStatus)
        {
            switch (syncStatus)
            {
                case SyncStatus.Local: 
                case SyncStatus.UncommittedChanges:
                    return CreatorStyle.Yellow;

                case SyncStatus.Synced:
                    return CreatorStyle.Green;

                case SyncStatus.Remote:
                default:
                    return GUI.contentColor;
            }
        }

        public static Color Status(this SyncStatusManager sync, string property)
        {
            if (sync.PropertyUpdated(property))
            {
                return CreatorStyle.Yellow;
            }

            return GUI.contentColor;
        }

        public static Color Status<T>(this SyncStatusManager sync, string collection, T member)
        {
            if (sync.CollectionUpdated(collection, member))
            {
                return CreatorStyle.Yellow;
            }

            return GUI.contentColor;
        }

        public static void DrawSyncStatusLabel(this SyncStatusManager sync, string property, params GUILayoutOption[] options)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                EditorGUILayout.LabelField(property, EditorStyles.helpBox, options);
            }
        }

        public static void DrawSyncStatusLabel(this SyncStatusManager sync, string property, string value, bool hidePropertyLabel = false)
        {
            sync.DrawSyncStatusLabel(property, property, value, hidePropertyLabel);
        }

        public static void DrawSyncStatusLabel(this SyncStatusManager sync, string label, string property, string value, bool hidePropertyLabel = false)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                if (hidePropertyLabel)
                {
                    EditorGUILayout.LabelField(value);
                }
                else
                {
                    EditorGUILayout.LabelField(label, value);
                }
            }
        }

        public static string DrawSyncStatusText(this SyncStatusManager sync, string label, string property, string value)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                return EditorGUILayout.TextField(label, value);
            }
        }

        public static E DrawSyncStatusEnumPopup<E>(this SyncStatusManager sync, string label, string property, E value) where E : Enum
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                return (E)EditorGUILayout.EnumPopup(label, value);
            }
        }
        
        public static E DrawSyncStatusEnumFlags<E>(this SyncStatusManager sync, string label, string property, E value) where E : Enum
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                return (E)EditorGUILayout.EnumFlagsField(label, value);
            }
        }

        public static int? DrawSyncStatusTextInt(this SyncStatusManager sync, string label, string property, int? value)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                if (int.TryParse(EditorGUILayout.TextField(label, value.HasValue ? value.Value.ToString() : string.Empty), out int sortOrder))
                {
                    return sortOrder;
                }
            }

            return null;
        }

        public static int DrawSyncStatusInt(this SyncStatusManager sync, string label, string property, int value)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                return EditorGUILayout.IntField(label, value);
            }
        }

        public static float DrawSyncStatusFloat(this SyncStatusManager sync, string label, string property, float value)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                return EditorGUILayout.FloatField(label, value);
            }
        }

        public static bool DrawSyncStatusBool(this SyncStatusManager sync, string label, string property, bool value)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
            {
                return EditorGUILayout.Toggle(label, value);
            }
        }

        public static void DrawSyncMemberList<T>(this SyncStatusManager sync, string property, List<T> members, Func<T, string> getName, Action<T> memberAction, Action<Action<T>, T[]> selectNewMember, Action<T> selectionCallback) where T : class
        {
            T actionItem = null;

            using (var memberLayout = new EditorGUILayout.VerticalScope())
            {
                using (var groupDisplay = new EditorGUILayout.HorizontalScope())
                {
                    using (var targetStatus = new GuiTools.ColorScope(sync.Status(property)))
                    {
                        GUILayout.Label(property, GUILayout.ExpandWidth(false));
                    }

                    if (GUILayout.Button("+", GUILayout.Width(20)))
                    {
                        selectNewMember?.Invoke(selectionCallback, members.ToArray());
                    }
                }

                for (int j = 0; j < members.Count;)
                {
                    int rowLength = 0;

                    using (var groupDisplay = new EditorGUILayout.HorizontalScope())
                    {
                        while (rowLength++ < MemberListView.MaxRowLegnth && j < members.Count)
                        {
                            var member = members[j++];

                            sync.DrawSyncMemberButton(property, member, getName, () => { actionItem = member; });
                        }

                        EditorGUILayout.LabelField("", GUILayout.ExpandWidth(true));
                    }
                }
            }

            if (actionItem != null)
            {
                memberAction?.Invoke(actionItem);
            }
        }

        public static void DrawSyncMemberButton<T>(this SyncStatusManager sync, string collection, T item, Func<T, string> getName, Action callback)
        {
            using (var targetStatus = new GuiTools.ColorScope(sync.Status(collection, item)))
            {
                if (GUILayout.Button(getName(item), GUILayout.ExpandWidth(false)))
                {
                    callback?.Invoke();
                }
            }
        }
    }
}