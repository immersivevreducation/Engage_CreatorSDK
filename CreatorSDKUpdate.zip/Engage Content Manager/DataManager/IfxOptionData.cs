﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class IfxOptionData : IIfxOption, IData<IIfxOption>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public Glossary PrettyName { get; set; }
        public string Value { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }

        public IfxOptionData() { }
        public IfxOptionData(string name, int? id = null)
        {
            Id = id;
            Name = name;
            PrettyName = (Glossary)name;
        }
        public IfxOptionData(IIfxOption ifxOption)
        {
            SetValues(ifxOption);
        }
        public void SetValues(IIfxOption data)
        {
            Id = data.Id;
            Name = data.Name;
            PrettyName = data.PrettyName;
            Value = data.Value;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
        }
    }

    public class IfxOptionDataModule : NamedItemDataModule<IIfxOption, IfxOptionData>
    {
        protected override Func<Task<IList<IIfxOption>>> ClientGetListAsync
            => () => EngageUser.ApiClient.Module<IfxOptionClient>().GetAsync();
        protected override Func<int, Task<IIfxOption>> ClientGetSingleAsync
            => (id) => EngageUser.ApiClient.Module<IfxOptionClient>().GetAsync(id);
        protected override Func<IIfxOption, Task<IIfxOption>> ClientCreateAsync
            => (item) => EngageUser.ApiClient.Module<IfxOptionClient>().CreateAsync(item);
        protected override Func<IIfxOption, Task<bool>> ClientUpdateAsync
            => (item) => EngageUser.ApiClient.Module<IfxOptionClient>().UpdateAsync(item);
    }
}
