﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public interface IData<I>
    {
        void SetValues(I data);
    }

    public abstract class EngageItemDataModule<I, T> : DataModule<I, T> where T : class, I, IData<I>, new() where I : IEngageItem
    {
        protected override string DataKey => EngageUser.GetUserKey($"{typeof(T)} Cache");
        protected override string LastUpdateKey => EngageUser.GetUserKey($"{typeof(T)} Updated");

        #region Client Module Proxy Functions
        protected virtual Func<Task<IList<I>>> ClientGetListAsync { get; }
        protected virtual Func<int, Task<I>> ClientGetSingleAsync { get; }
        protected virtual Func<I, Task<I>> ClientCreateAsync { get; }
        protected virtual Func<I, Task<bool>> ClientUpdateAsync { get; }
        protected virtual Func<I, Task<bool>> ClientDeleteAsync { get; }
        #endregion

        public virtual float Progress { get; protected set; }

        protected DateTime? lastUpdate;
        public override DateTime? LastUpdate
        {
            get
            {
                if (!lastUpdate.HasValue)
                {
                    if (DateTime.TryParse(EditorPrefs.GetString(LastUpdateKey), out DateTime lastUpdate))
                    {
                        LastUpdate = lastUpdate;
                    }
                }

                return lastUpdate;
            }
            protected set => lastUpdate = value;
        }

        protected EngageItemDataModule() : base()
        {
            InitializeData();
        }

        public override void Clear()
        {
            DataCache.Clear();
        }

        public override void Refresh()
        {
            ReloadFromCache();
        }

        public async override Task RefreshAsync()
        {
            // remove all non-local items
            DataCache.RemoveAll(item => item.Id.HasValue);

            EditorPrefs.DeleteKey(DataKey);
            EditorPrefs.DeleteKey(LastUpdateKey);

            await GetAsync();
        }

        protected override void SaveToCache()
        {
            try
            {
                var serialized = JsonConvert.SerializeObject(DataCache);
                EditorPrefs.SetString(DataKey, serialized);

                LastUpdate = DateTime.Now;
                EditorPrefs.SetString(LastUpdateKey, LastUpdate.ToString());
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DataCache{typeof(T)}] Failed to serialize to cache: {ex}");
            }
        }

        protected override void InitializeData()
        {
            ReloadFromCache();
        }

        protected override bool ReloadFromCache()
        {
            if (EditorPrefs.HasKey(DataKey))
            {
                var json = EditorPrefs.GetString(DataKey);
                var cachedUpdate = EditorPrefs.GetString(LastUpdateKey);

                if (DateTime.TryParse(cachedUpdate, out DateTime lastUpdate))
                {
                    LastUpdate = lastUpdate;
                }

                try
                {
                    var data = JsonConvert.DeserializeObject<List<T>>(json);

                    if (data != null)
                    {
                        DataCache.Clear();
                        DataCache.AddRange(data.Cast<I>());
                    }

                    OnCacheChanged?.Invoke();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[DataCache{typeof(T)}] Failed to load from cache: {ex}");
                }
            }

            return false;
        }


        public override I Get(I item) => Get(item.Id.HasValue ? item.Id.Value : -1);
        public virtual I Get(int id)
        {
            return DataCache.FirstOrDefault(item => item.Id == id);
        }
        public virtual bool TryGet(int id, out I item)
        {
            item = Get(id);
            return item != null;
        }

        public override void Create(I item)
        {
            if (item == null)
            {
                Debug.LogError($"[DataModule.{nameof(Create)}] item ({typeof(I)}) was null");
                return;
            }

            try
            {
                var localData = new T();
                localData.SetValues(item);

                DataCache.Add(localData);
            }
            catch (Exception ex)
            {
                Debug.LogError($"[DataModule.{nameof(Create)}] Error creating item Id {item.Id} ({typeof(I)}): {ex}");
            }

            SaveToCache();
        }

        public override void Update(I item)
        {
            if (item == null)
            {
                Debug.LogError($"[DataModule.{nameof(Update)}] item ({typeof(I)}) was null");
                return;
            }

            if (item.Id.HasValue)
            {
                if (TryGet(item.Id.Value, out I oldItem))
                {
                    var itemData = oldItem as T;
                    
                    if (itemData != null)
                    {
                        itemData.SetValues(item);
                        SaveToCache();
                    }
                }
                else
                {
                    Create(item);
                }
            }
        }

        public override bool Delete(I item) => Delete(item.Id.HasValue ? item.Id.Value : -1);

        public virtual bool Delete(int id)
        {
            if (DataCache.RemoveAll(item => item.Id.Value == id) > 0)
            {
                SaveToCache();
                return true;
            }

            return false;
        }


        #region Async Client Module Methods

        public virtual async Task<IList<I>> GetAsync()
        {
            if (!ReloadFromCache())
            {
                DataCache.AddRange(await ClientGetListAsync.Invoke());

                SaveToCache();
            }

            OnCacheChanged?.Invoke();
            return DataCache;
        }

        public virtual async Task<I> GetAsync(int id)
        {
            var item  = await ClientGetSingleAsync.Invoke(id);

            OnCacheChanged?.Invoke();
            return item;
        }

        public virtual async Task<I> CreateAsync(I item)
        {
            var createdItem = await ClientCreateAsync.Invoke(item);

            if (createdItem != null && createdItem.Id.HasValue)
            {
                int id = createdItem.Id.Value;

                createdItem = await GetAsync(id);
                Update(createdItem);
            }

            OnCacheChanged?.Invoke();
            return createdItem;
        }

        public virtual async Task<bool> UpdateAsync(I item)
        {
            var success = await ClientUpdateAsync.Invoke(item);

            if (success)
            {
                Update(item);
            }

            OnCacheChanged?.Invoke();
            return success;
        }
        
        public virtual async Task<bool> DeleteAsync(I item)
        {
            throw new NotImplementedException();
        }
        #endregion
    }

}
