﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class LocationAssetData : AssetData, ILocationAsset, IData<ILocationAsset>
    {
        public int? BaseLocationId { get; set; }
        public int? BrandingGroupId { get; set; }

        public LocationAssetData() { }

        public LocationAssetData(ILocationAsset asset)
        {
            SetValues(asset);
        }

        public LocationAssetData(string name)
        {
            Name = UnityResourceName = name;
        }

        public virtual void SetValues(ILocationAsset data)
        {
            SetValues(data as IAsset);

            BaseLocationId = data.BaseLocationId;
            BrandingGroupId = data.BrandingGroupId;
        }
    }

    public class LocationAssetDataModule : NamedItemDataModule<ILocationAsset, LocationAssetData>
    {
        protected LocationAssetClient ApiClient => EngageUser.ApiClient.Module<LocationAssetClient>();

        protected override Func<Task<IList<ILocationAsset>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<ILocationAsset>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
        protected override Func<ILocationAsset, Task<ILocationAsset>> ClientCreateAsync
            => (item) => ApiClient.CreateAsync(item);
        protected override Func<ILocationAsset, Task<bool>> ClientUpdateAsync
            => (item) => ApiClient.UpdateAsync(item);

        public virtual async Task<bool> UploadThumbnail(ILocationAsset item, string imagePath, Action<float> progressCallback)
        {
            var thumbnailPackage = ThumbnailFormData.Create(imagePath);
            var success = await ApiClient.UploadThumbnail(item, thumbnailPackage, progressCallback);

            if (success)
            {
                Update(await ClientGetSingleAsync(item.Id.Value));
            }

            return success;
        }

        public async Task<bool> UploadBundle(ILocationAsset item, BundleFile localFiles)
        {
            var bundlePackage = BundleFileFormData.Create(
                localFiles.Type,
                localFiles.Platform.ToBundleFilePlatform(),
                localFiles.Bundle.FullName,
                localFiles.Manifest.FullName
                );

            return await ApiClient.UploadBundle(item, bundlePackage, localFiles.UpdateProgress);
        }
    }
}
