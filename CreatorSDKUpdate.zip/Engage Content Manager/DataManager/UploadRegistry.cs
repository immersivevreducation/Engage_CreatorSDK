﻿using UnityEditor;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class UploadRegistry : Dictionary<string, DateTime>
    {
        internal const string uploadHistoryKey = "BundleUploadsHistory";
        internal static string UploadHistoryKey => EngageUser.GetUserKey(uploadHistoryKey);

        public static UploadRegistry GetUploadHistory()
        {
            try
            {
                var history = EditorPrefs.GetString(UploadHistoryKey);
                var uploadedBundles = JsonConvert.DeserializeObject<UploadRegistry>(history) ?? new UploadRegistry();
                return uploadedBundles;
            }
            catch { }

            return new UploadRegistry();
        }

        public void RegisterUpload(BundleFile bundle)
        {
            if (ContainsKey(bundle.CRC))
            {
                this[bundle.CRC] = DateTime.Now;
            }
            else
            {
                Add(bundle.CRC, DateTime.Now);
            }

            Save();
        }

        public void ClearUploadHistory(BundleFile bundle)
        {
            if (Remove(bundle.CRC))
            {
                Save();
            }
        }

        public void ClearUploadHistory()
        {
            Clear();
            Save();
        }

        public void Save()
        {
            if (Count > 0)
            {
                EditorPrefs.SetString(UploadHistoryKey, JsonConvert.SerializeObject(this));
            }
            else
            {
                EditorPrefs.DeleteKey(UploadHistoryKey);
            }
        }
    }
}