﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class GroupData : IGroup, IData<IGroup>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }

        public GroupData() { }
        public GroupData(string name, int? id = null)
        {
            Id = id;
            Name = name;
        }
        public GroupData(IGroup group)
        {
            SetValues(group);
        }

        public void SetValues(IGroup data)
        {
            Id = data.Id;
            Name = data.Name;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
        }
    }

    public class GroupDataModule : NamedItemDataModule<IGroup, GroupData>
    {
        protected override Func<Task<IList<IGroup>>> ClientGetListAsync
            => () => EngageUser.ApiClient.Module<GroupClient>().GetAsync();
        protected override Func<int, Task<IGroup>> ClientGetSingleAsync
            => (id) => EngageUser.ApiClient.Module<GroupClient>().GetAsync(id);
        protected override Func<IGroup, Task<IGroup>> ClientCreateAsync
            => (item) => EngageUser.ApiClient.Module<GroupClient>().CreateAsync(item);
        protected override Func<IGroup, Task<bool>> ClientUpdateAsync
            => (item) => EngageUser.ApiClient.Module<GroupClient>().UpdateAsync(item);
    }
}
