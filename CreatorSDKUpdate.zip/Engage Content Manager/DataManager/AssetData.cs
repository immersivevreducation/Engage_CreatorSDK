﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public class AssetData : IAsset, IData<IAsset>
    {
        public int? Id { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string Name { get; set; }
        public string UnityResourceName { get; set; }
        public Glossary PrettyName { get; set; } = new Glossary();
        public Glossary Description { get; set; } = new Glossary();
        public int? BundleId { get; set; }
        public string Image { get; set; }
        public bool? IsPrivate { get; set; } = true;
        public bool? EditorOnly { get; set; }
        public bool? Unlisted { get; set; }
        public string AssetGuid { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IAssetTag, AssetTag>))]
        public List<IAssetTag> Tags { get; set; } = new List<IAssetTag>();

        [JsonConverter(typeof(EngageItemListConverter<IAssetCollection, AssetCollectionData>))]
        public List<IAssetCollection> Collections { get; set; } = new List<IAssetCollection>();

        [JsonConverter(typeof(EngageItemListConverter<IGroup, GroupData>))]
        public List<IGroup> Groups { get; set; } = new List<IGroup>();

        public virtual void SetValues(IAsset asset)
        {
            Id = asset.Id;
            CreatedAt = asset.CreatedAt;
            UpdatedAt = asset.UpdatedAt;

            Name = asset.Name;

            UnityResourceName = asset.UnityResourceName;
            PrettyName.SetValues(asset.PrettyName);
            Description.SetValues(asset.Description);
            BundleId = asset.BundleId;
            Image = asset.Image;
            IsPrivate = asset.IsPrivate;
            EditorOnly = asset.EditorOnly;
            Unlisted = asset.Unlisted;

            Tags.Clear();
            if (asset.Tags != null)
                Tags.AddRange(asset.Tags);

            Collections.Clear();
            if (asset.Collections != null)
                Collections.AddRange(asset.Collections);

            Groups.Clear();
            if (asset.Groups != null)
                Groups.AddRange(asset.Groups);
        }
    }
}
