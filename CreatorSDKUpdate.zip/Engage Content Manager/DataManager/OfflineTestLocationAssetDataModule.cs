﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class OfflineTestLocationAssetDataModule : NamedItemDataModule<ILocationAsset, LocationAssetData>
    {
        protected override Func<Task<IList<ILocationAsset>>> ClientGetListAsync
            => () => GenerateList();
        protected override Func<int, Task<ILocationAsset>> ClientGetSingleAsync
            => (id) => GenerateItem(id);
        protected override Func<ILocationAsset, Task<ILocationAsset>> ClientCreateAsync
            => (item) => CreateItem(item);
        protected override Func<ILocationAsset, Task<bool>> ClientUpdateAsync
            => (item) => UpdateItem(item);

        public async Task<IList<ILocationAsset>> GenerateList(int count = 10)
        {
            var rand = new Random();
            var list = new List<ILocationAsset>();

            for(int i = 0; i < count; i++)
            {
                var location = new LocationAssetData($"dummy_location_{i:00}")
                {
                    PrettyName = (Glossary)$"Dummy Location {i}",
                    Description = (Glossary)$"A description of Dummy Location {i}, signifying nothing,",
                    BundleId = 52,
                    Id = rand.Next(1, 1000),
                    CreatedAt = DateTime.Now.ToString(),
                    UpdatedAt = DateTime.Now.ToString()
                };
            }

            return list;
        }

        public async Task<ILocationAsset> GenerateItem(int id)
        {
            var rand = new Random();

            var location = new LocationAssetData($"dummy_location_{id:00}")
            {
                PrettyName = (Glossary)$"Dummy Location {id}",
                Description = (Glossary)$"A description of Dummy Location {id}, signifying nothing,",
                BundleId = 52,
                Id = rand.Next(1, 1000),
                CreatedAt = DateTime.Now.ToString(),
                UpdatedAt = DateTime.Now.ToString()
            };

            return location;
        }

        public async Task<ILocationAsset> CreateItem(ILocationAsset item) => item;

        public async Task<bool> UpdateItem(ILocationAsset item) => true;

        public virtual async Task<bool> UploadThumbnail(ILocationAsset item, string imagePath, Action<float> progressCallback)
        {
            var thumbnailPackage = ThumbnailFormData.Create(imagePath);
            var success = true;// await EngageUser.ApiClient.Module<LocationAssetClient>().UploadThumbnail(item, thumbnailPackage, progressCallback);

            if (success)
            {
                Update(await ClientGetSingleAsync(item.Id.Value));
            }

            return success;
        }

        public async Task<bool> UploadBundle(ILocationAsset item, BundleFile localFiles)
        {
            var bundlePackage = BundleFileFormData.Create(
                localFiles.Type,
                localFiles.Platform.ToBundleFilePlatform(),
                localFiles.Bundle.FullName,
                localFiles.Manifest.FullName
                );

            return true;// await EngageUser.ApiClient.Module<LocationAssetClient>().UploadBundle(item, bundlePackage, localFiles.UpdateProgress);
        }
    }
}