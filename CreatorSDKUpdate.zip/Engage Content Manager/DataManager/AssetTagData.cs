﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class AssetTagData : IAssetTag, IData<IAssetTag>
    {
        public int? Id { get; private set; }
        public Glossary Name { get; private set; }
        public string CreatedAt { get; private set; }
        public string UpdatedAt { get; private set; }

        public AssetTagData() { }
        public AssetTagData(string name, int? id = null)
        {
            Id = id;
            Name = (Glossary)name;
        }
        public AssetTagData(IAssetTag tag)
        {
            SetValues(tag);
        }

        public void SetValues(IAssetTag data)
        {
            Id = data.Id;
            Name = data.Name;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
        }
    }

    public class AssetTagDataModule : EngageItemDataModule<IAssetTag, AssetTagData>
    {
        protected override Func<Task<IList<IAssetTag>>> ClientGetListAsync
            => () => EngageUser.ApiClient.Module<AssetTagClient>().GetAsync();
        protected override Func<int, Task<IAssetTag>> ClientGetSingleAsync
            => (id) => EngageUser.ApiClient.Module<AssetTagClient>().GetAsync(id);
        protected override Func<IAssetTag, Task<IAssetTag>> ClientCreateAsync
            => (item) => EngageUser.ApiClient.Module<AssetTagClient>().CreateAsync(item);
        protected override Func<IAssetTag, Task<bool>> ClientUpdateAsync
            => (item) => EngageUser.ApiClient.Module<AssetTagClient>().UpdateAsync(item);
    }
}
