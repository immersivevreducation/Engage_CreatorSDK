﻿using Engage.CreatorSDK;
using Engage.Network;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public class BundleFiles : Dictionary<EngagePlatform, BundleFile>
    {
        public string Name { get; private set; }
        public BundleFileFormData.AssetType Type => Count > 0 && Values.Select(asset => asset.Type).Distinct().Count() == 1 ? Values.First().Type : BundleFileFormData.AssetType.Mixed;
        public BundleProblem Problem => Count > 0 && Values.Any(bundle => bundle.Problem != BundleProblem.None) ? Values.First(bundle => bundle.Problem != BundleProblem.None).Problem : BundleProblem.None;
        public EngagePlatform Platforms => Keys.Aggregate(EngagePlatform.None, (platforms, platform) => platforms |= platform);

        public IEnumerable<string> Contents => Values.SelectMany(bundle => bundle.Contents).Distinct();
        public IEnumerable<string> Assets => Values.SelectMany(bundle => bundle.Assets).Distinct();
        public IEnumerable<string> Scenes => Values.SelectMany(bundle => bundle.Scenes).Distinct();

        public RequestStatus Status { get; private set; }
        public EngagePlatform Uploaded
        {
            get
            {
                var uploads = EngagePlatform.None;

                foreach (var platform in Keys)
                {
                    if (this[platform].Uploaded)
                    {
                        uploads |= platform;
                    }
                }

                return uploads;
            }
        }

        public BundleFiles(string bundleName)
        {
            Name = bundleName;
        }

        #region Static Stuff

        private static readonly Dictionary<string, BundleFiles> bundleInventory = new Dictionary<string, BundleFiles>();
        private static DateTime? lastInventoryUpdate;

        public static Dictionary<string, BundleFiles> GetLocalBundleFileInventory(string assetPath = null, bool forceUpdate = false)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                assetPath = BuildSettings.LocalBuildPath;
            }

            var assetPathInfo = new DirectoryInfo(assetPath);

            if (!assetPathInfo.Exists)
            {
                Debug.LogWarning($"[Bundle Manager] Local Bundle Path cannot be found: {BuildSettings.LocalBuildPath}");
                bundleInventory.Clear();
                lastInventoryUpdate = null;
                return bundleInventory;
            }

            Dictionary<EngagePlatform, DirectoryInfo> directories = new Dictionary<EngagePlatform, DirectoryInfo>();

            // Get the bundle directories by platform
            foreach (var dir in assetPathInfo.EnumerateDirectories())
            {
                if (Enum.TryParse(dir.Name, out EngagePlatform platform))
                {
                    directories.Add(platform, dir);
                }
            }

            // Check if any of the directories have more recent updates
            if (lastInventoryUpdate.HasValue && !forceUpdate)
            {
                if (directories.Values.All(dir => dir.LastWriteTime < lastInventoryUpdate.Value))
                {
                    return bundleInventory;
                }
            }

            bundleInventory.Clear();

            foreach (var platform in directories.Keys)
            {
                var dir = directories[platform];

                Debug.Log($"[{typeof(BundleFiles)}] Searching {dir.FullName}...");

                foreach (var bundleFile in dir.EnumerateFiles($"*{BundleFile.bundleExtension}"))
                {
                    var bundleName = Path.GetFileNameWithoutExtension(bundleFile.Name);

                    if (!bundleInventory.TryGetValue(bundleName, out BundleFiles bundleFiles))
                    {
                        bundleFiles = new BundleFiles(bundleName);
                        bundleInventory.Add(bundleName, bundleFiles);
                    }

                    bundleFiles.TryAdd(platform, BundleFile.GetBundleFile(platform, bundleFile.Directory.FullName, bundleName));
                }
            }

            lastInventoryUpdate = DateTime.Now;
            return bundleInventory;
        }

        #endregion

        public bool TryAdd(EngagePlatform platform, BundleFile file, bool replace = false)
        {
            if (ContainsKey(platform))
            {
                Debug.LogWarning($"[{GetType()}.{nameof(TryAdd)}] {Name} already contains and entry for {platform}");

                if (replace)
                {
                    this[platform] = file;
                }

                return false;
            }
            else
            {
                Add(platform, file);
                return true;
            }
        }

        public void Refresh(string assetPath = null)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                assetPath = BuildSettings.LocalBuildPath;
            }

            var assetPathInfo = new DirectoryInfo(assetPath);

            if (!assetPathInfo.Exists)
            {
                Debug.LogWarning($"[Bundle Manager] Local Bundle Path cannot be found: {assetPath}");
                return;
            }

            Clear();

            foreach (var dir in assetPathInfo.EnumerateDirectories())
            {
                if (Enum.TryParse(dir.Name, out EngagePlatform platform))
                {
                    if (BundleFile.TryGetBundleFile(platform, dir.FullName, Name, out BundleFile localFile))
                    {
                        TryAdd(platform, localFile);
                    }
                }
            }
        }

        public void Refresh(EngagePlatform platform, string assetPath = null)
        {
            if (string.IsNullOrEmpty(assetPath))
            {
                assetPath = BuildSettings.GetLocalBundlePath(platform);
            }

            var assetPathInfo = new DirectoryInfo(assetPath);

            if (assetPathInfo.Exists)
            {
                if (BundleFile.TryGetBundleFile(platform, assetPathInfo.FullName, Name, out BundleFile localFile))
                {
                    TryAdd(platform, localFile);
                }
            }
        }

        public void UpdateStatus()
        {
            if (Values.Any(file => file.Status == RequestStatus.Error))
            {
                Status = RequestStatus.Error;
                return;
            }

            if (Values.Any(file => file.Status == RequestStatus.Requesting))
            {
                Status = RequestStatus.Requesting;
                return;
            }

            if (Values.All(file => file.Status == RequestStatus.Complete))
            {
                Status = RequestStatus.Complete;
                return;
            }

            Status = RequestStatus.None;
        }

        public RequestStatus GetBundleStatus(EngagePlatform platform)
        {
            if (TryGetValue(platform, out BundleFile file))
            {
                return file.Status;
            }
            else
            {
                return RequestStatus.None;
            }
        }

        public bool Rename(string name, bool overwrite)
        {
            bool success = true;
            Name = name;

            foreach (EngagePlatform platform in Keys)
            {
                if (!Rename(platform, Name, overwrite))
                {
                    success = false;
                }
            }

            return success;
        }

        public bool Rename(EngagePlatform platform, string name, bool overwrite)
        {
            if (!TryGetValue(platform, out BundleFile file))
            {
                return false;
            }

            return file.Rename(name, overwrite);
        }
    }

    public enum BundleProblem
    {
        None = 0,
        MixedTypes,
        NameFormat,
        Empty
    }

    public class BundleManifest
    {
        public int ManifestFileVersion { get; set; }
        public string CRC { get; set; }
        public List<string> Assets { get; } = new List<string>();

        public static BundleManifest Load(string manifestPath)
        {
            if (!File.Exists(manifestPath))
            {
                return null;
            }

            var manifest = new BundleManifest();
            var lines = File.ReadAllLines(manifestPath);

            for(int i = 0; i < lines.Length; i++)
            {
                var parts = lines[i].Split(':');

                if (parts.Length == 0)
                    continue;

                switch(parts[0])
                {
                    case nameof(ManifestFileVersion):
                        int.TryParse(parts[1].Trim(), out int fileVersion);
                        manifest.ManifestFileVersion = fileVersion;
                        break;
                    case nameof(CRC):
                        manifest.CRC = parts[1].Trim();
                        break;
                    case nameof(Assets):
                        for(int j = i + 1; j < lines.Length; j++, i++)
                        {
                            if (lines[j].StartsWith("-"))
                            {
                                manifest.Assets.Add(lines[j]);
                            }
                            else
                            {
                                break;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }

            return manifest;
        }

        public static string[] GetAllAssetPaths(string manifestPath, string filter = null)
        {
            return File.ReadAllLines(manifestPath).Where(line => line.EndsWith(filter)).OrderBy(line => line).ToArray();
        }
    }

    public class BundleFile
    {
        public const string dataExtension = ".json";
        public const string bundleExtension = ".engagebundle";
        public const string manifestExtension = ".manifest";

        public FileInfo Bundle { get; }
        public FileInfo Manifest { get; }
        public string CRC { get; }
        public BundleFileFormData.AssetType Type { get; private set; } = BundleFileFormData.AssetType.Undefined;
        public EngagePlatform Platform { get; private set; }

        public RequestStatus Status { get; set; } = RequestStatus.None;
        public float UploadProgress { get; private set; }
        public bool Uploaded { get; set; }//=> EngageUser.WasUploaded(this);

        public BundleProblem Problem { get; private set; } = BundleProblem.None;

        public event Action<BundleFile, float> OnProgressUpdated;

        public List<string> Contents { get; } = new List<string>();

        public string[] Scenes { get; private set; }
        public string[] Assets { get; private set; }

        public FileInfo this[EngageFileType fileType]
        {
            get
            {
                switch (fileType)
                {
                    case EngageFileType.Bundle: return Bundle;
                    case EngageFileType.Manifest: return Manifest;
                    case EngageFileType.Unknown:
                    default: return null;
                }
            }
        }

        public static BundleFile GetBundleFile(EngagePlatform platform, string filePath, string bundleName)
        {
            //  TODO: try load from json

            var bundleFile = new BundleFile(platform, filePath, bundleName);

            if (bundleFile.Bundle.Exists)
            {
                bundleFile.ResetAssetType();
            }

            return bundleFile;
        }

        public static bool TryGetBundleFile(EngagePlatform platform, string filePath, string bundleName, out BundleFile bundleFile)
        {
            bundleFile = new BundleFile(platform, filePath, bundleName);

            if (bundleFile.Bundle.Exists)
            {
                bundleFile.ResetAssetType();
                return true;
            }
            else
            {
                return false;
            }
        }

        public BundleFile(EngagePlatform platform, string path, string bundleName)
        {
            Platform = platform;
            Bundle = new FileInfo(Path.Combine(path, bundleName + bundleExtension));
            Manifest = new FileInfo(Path.Combine(path, bundleName + manifestExtension));
            CRC = BundleManifest.Load(Manifest.FullName)?.CRC;
        }

        public void ResetAssetType()
        {
            Contents.Clear();
            Type = BundleFileFormData.AssetType.Undefined;

            AssetBundle assetBundle = null;

            try
            {
                assetBundle = AssetBundle.LoadFromFile(Bundle.FullName);

                Scenes = assetBundle.GetAllScenePaths();
                Assets = BundleManifest.GetAllAssetPaths(Manifest.FullName, ".prefab");
            }
            catch
            {
                Scenes = new string[0];
                Assets = new string[0];
            }
            finally
            {
                assetBundle?.Unload(true);
            }

            if (Scenes.Length > 0 && Assets.Length > 0)
            {
                Contents.AddRange(Scenes);
                Contents.AddRange(Assets);

                Problem = BundleProblem.MixedTypes;
                Type = BundleFileFormData.AssetType.Mixed;
                return;
            }

            if (Scenes.Length > 0)
            {
                Contents.AddRange(Scenes);

                if (Scenes.Any(scene => Path.GetFileName(scene).Contains(" ")))
                {
                    Problem = BundleProblem.NameFormat;
                }

                Type = BundleFileFormData.AssetType.Location;
                return;
            }

            if (Assets.Length > 0)
            {
                Contents.AddRange(Assets);

                if (Assets.Any(asset => Path.GetFileName(asset).Contains(" ")))
                {
                    Problem = BundleProblem.NameFormat;
                }

                Type = BundleFileFormData.AssetType.IFX;
                return;
            }

            Problem = BundleProblem.Empty;
        }

        public void UpdateProgress(float progress)
        {
            UploadProgress = progress;
            OnProgressUpdated?.Invoke(this, progress);
        }

        public bool Rename(string name, bool overwrite)
        {
            var targetBundleName = Path.Combine(Bundle.Directory.FullName, name + bundleExtension);
            var targetManifestName = Path.Combine(Bundle.Directory.FullName, name + manifestExtension);

            if (File.Exists(targetBundleName))
            {
                if (overwrite)
                {
                    File.Delete(targetBundleName);
                    File.Delete(targetManifestName);
                }
                else
                {
                    return false;
                }
            }

            try
            {
                Bundle.MoveTo(targetBundleName);
                Manifest.MoveTo(targetManifestName);
            }
            catch (Exception ex)
            {
                Debug.LogError("[BundleFile] Rename failed: " + ex);
                return false;
            }

            return true;
        }
    }
}
