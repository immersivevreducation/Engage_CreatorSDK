﻿using System.Linq;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public abstract class NamedItemDataModule<I, T> : EngageItemDataModule<I, T> where T : class, I, IData<I>, new() where I : IEngageItem, INamedItem
    {
        public virtual I GetLocal(string name)
        {
            return DataCache.FirstOrDefault(item => item.Name == name);
        }

        public virtual bool TryGetLocal(string name, out I item)
        {
            item = GetLocal(name);

            return item != null;
        }

        public virtual bool NameExists(string name)
        {
            return DataCache.Any(item => item.Name == name);
        }

        public override void Create(I item)
        {
            if (NameExists(item?.Name))
            {
                Debug.Log($"[NamedDataModule<{typeof(I)}>] An item with Name {item.Name} already exists.");
                return;
            }

            base.Create(item);
        }

        public override void Update(I item)
        {
            if (item == null)
            {
                Debug.LogError($"[DataModule.{nameof(Update)}] item ({typeof(I)}) was null");
                return;
            }

            if (item.Id.HasValue)
            {
                if (TryGet(item.Id.Value, out I oldItem) || TryGetLocal(item.Name, out oldItem))
                {
                    var itemData = oldItem as T;

                    if (itemData != null)
                    {
                        itemData.SetValues(item);
                        SaveToCache();
                    }
                }
                else
                {
                    Create(item);
                }
            }
        }

        public virtual bool DeleteLocal(string name)
        {
            if (DataCache.RemoveAll(item => item.Name == name) > 0)
            {
                SaveToCache();
                return true;
            }

            return false;
        }
    }

}
