﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class AssetCollectionData : IAssetCollection, IData<IAssetCollection>
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public string CreatedAt { get; set; }
        public string UpdatedAt { get; set; }
        public string PrettyName { get; set; }
        public int UserId { get; set; }
        public string Image { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IGroup, Group>))]
        public List<IGroup> Groups { get; } = new List<IGroup>();

        public AssetCollectionData() { }
        public AssetCollectionData(string name, int? id = null)
        {
            Id = id;
            PrettyName = name;
        }
        public AssetCollectionData(IAssetCollection collection)
        {
            SetValues(collection);
        }

        public void SetValues(IAssetCollection data)
        {
            Id = data.Id;
            Name = data.Name;
            PrettyName = data.PrettyName;
            CreatedAt = data.CreatedAt;
            UpdatedAt = data.UpdatedAt;
            UserId = data.UserId;
            Image = data.Image;
        }
    }

    public class AssetCollectionDataModule : NamedItemDataModule<IAssetCollection, AssetCollectionData>
    {
        protected AssetCollectionClient ApiClient => EngageUser.ApiClient.Module<AssetCollectionClient>();
        protected override Func<Task<IList<IAssetCollection>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<IAssetCollection>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
        protected override Func<IAssetCollection, Task<IAssetCollection>> ClientCreateAsync
            => (item) => ApiClient.CreateAsync(item);
        protected override Func<IAssetCollection, Task<bool>> ClientUpdateAsync
            => (item) => ApiClient.UpdateAsync(item);

        public virtual async Task<bool> UploadThumbnail(IAssetCollection item, string imagePath, Action<float> progressCallback)
        {
            var thumbnailPackage = ThumbnailFormData.Create(imagePath);
            var success = await ApiClient.UploadThumbnail(item, thumbnailPackage, progressCallback);

            if (success)
            {
                Update(await ClientGetSingleAsync(item.Id.Value));
            }

            return success;
        }
    }
}
