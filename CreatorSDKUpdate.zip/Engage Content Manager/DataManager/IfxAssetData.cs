﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Engage.AssetManagement.Content
{
    public class IfxAssetData : AssetData, IIfxAsset, IData<IIfxAsset>
    {
        public int CategoryId { get; set; } = 53;
        public string Type { get; set; }

        [JsonConverter(typeof(EngageItemListConverter<IIfxOption, IfxOptionData>))]
        public List<IIfxOption> Options { get; set; } = new List<IIfxOption>();

        public IfxAssetData() { }
        public IfxAssetData(IIfxAsset asset)
        {
            SetValues(asset);
        }
        public IfxAssetData(string name)
        {
            Name = UnityResourceName = name;
        }

        public virtual void SetValues(IIfxAsset data)
        {
            SetValues(data as IAsset);

            CategoryId = data.CategoryId;
            Type = data.Type;

            Options.Clear();

            if (data.Options != null)
                Options.AddRange(data.Options);
        }
    }

    public class IfxAssetDataModule : NamedItemDataModule<IIfxAsset, IfxAssetData>
    {
        protected IfxAssetClient ApiClient => EngageUser.ApiClient.Module<IfxAssetClient>();

        protected override Func<Task<IList<IIfxAsset>>> ClientGetListAsync
            => () => ApiClient.GetAsync();
        protected override Func<int, Task<IIfxAsset>> ClientGetSingleAsync
            => (id) => ApiClient.GetAsync(id);
        protected override Func<IIfxAsset, Task<IIfxAsset>> ClientCreateAsync
            => (item) => ApiClient.CreateAsync(item);
        protected override Func<IIfxAsset, Task<bool>> ClientUpdateAsync
            => (item) => ApiClient.UpdateAsync(item);

        public virtual async Task<bool> UploadThumbnail(IIfxAsset item, string imagePath, Action<float> progressCallback)
        {
            var thumbnailPackage = ThumbnailFormData.Create(imagePath);
            var success = await ApiClient.UploadThumbnail(item, thumbnailPackage, progressCallback);

            if (success)
            {
                Update(await ClientGetSingleAsync(item.Id.Value));
            }

            return success;
        }

        public async Task<bool> UploadBundle(IIfxAsset item, BundleFile localFiles)
        {
            var bundlePackage = BundleFileFormData.Create(
                localFiles.Type,
                localFiles.Platform.ToBundleFilePlatform(),
                localFiles.Bundle.FullName,
                localFiles.Manifest.FullName
                );

            return await ApiClient.UploadBundle(item, bundlePackage, localFiles.UpdateProgress);
        }
    }
}
