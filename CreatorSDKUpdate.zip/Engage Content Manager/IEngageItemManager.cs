﻿using Engage.Network;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public interface IEngageItemManager
    {
        RequestStatus RefreshStatus { get; }
        DateTime? LastRefresh { get; }
        void RefreshFromServer();
    }

    public interface IEngageItemManager<T> : IEngageItemManager
    {
        List<T> ItemDisplayList { get; }
        void RefreshDisplay();
    }

}
