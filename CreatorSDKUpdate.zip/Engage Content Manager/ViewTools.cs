﻿using Engage.Network;
using Engage.UI.Editor;
using System;
using UnityEditor;
using UnityEngine;

namespace Engage.AssetManagement.Content
{
    public static class ViewTools
    {
        private static Texture engageLogo;
        public static Texture ENGAGELogo
        {
            get
            {
                if (engageLogo == null)
                {
                    engageLogo = AssetDatabase.LoadAssetAtPath<Texture>("Assets/ENGAGE_CreatorSDK/Engage Content Manager/ENGAGE Logo A.png");
                }

                return engageLogo;
            }
        }

        public static void DrawAuthenticatingButton(string label, Action authenticatedAction, params GUILayoutOption[] options)
        {
            DrawAuthenticatingButton(label, authenticatedAction, null, options);
        }

        public static void DrawAuthenticatingButton(string label, Action authenticatedAction, bool? enabled = null, params GUILayoutOption[] options)
        {
            if (EngageUser.IsAuthenticated)
            {
                GuiTools.DrawButton(label, authenticatedAction, enabled, options);
            }
            else
            {
                GuiTools.DrawButton(
                    label: new GUIContent(label, enabled.HasValue && enabled.Value ? Labels.NotAuthenticated : null),
                    action: () =>
                    {
                        //EnvironmentSettingsView.Login((success) => { if (success) authenticatedAction(); }, true);
                    },
                    enabled,
                    options);
            }
        }

        public static void DrawLastRefreshDate(DateTime? lastRefresh)
        {
            string lastRefreshString = lastRefresh.HasValue ? lastRefresh.Value.ToString() : Labels.NoLastRefreshValue;

            var lastRefreshLabel = $"{Labels.LastRefresh}\t{lastRefreshString}";

            if (lastRefresh.HasValue && (DateTime.Now - lastRefresh.Value).Days < 2)
            {
                EditorGUILayout.LabelField(lastRefreshLabel, EditorStyles.miniLabel, GUILayout.Width(Screen.width - 50));
            }
            else
            {
                using (var refreshCoding = new GuiTools.ColorScope(CreatorStyle.Red))
                {
                    EditorGUILayout.LabelField(new GUIContent(lastRefreshLabel, Labels.DataStale), EditorStyles.miniLabel, GUILayout.Width(Screen.width - 50));
                }
            }
        }

        public static void DrawRefreshFromServerPanel(IEngageItemManager manager)
        {
            using (var refreshPanel = new EditorGUILayout.HorizontalScope())
            {
                DrawLastRefreshDate(manager.LastRefresh);

                using (var refreshEnabled = new GuiTools.EnabledScope(EngageUser.IsAuthenticated))
                {
                    if (GUI.Button(new Rect(refreshPanel.rect.width - 40, refreshPanel.rect.y - 5, 40, 30), Icons.Refresh.Tooltip("Refresh from server")))
                    {
                        manager.RefreshFromServer();
                    }
                }
            }
        }

        public static void DrawFooter(string status = "")
        {
            using (var footer = new EditorGUILayout.VerticalScope(CreatorStyle.CreateStyle(background: CreatorStyle.DarkTone)))
            {
                //using (var messageColor = new GuiTools.ColorScope(CreatorStyle.Yellow))
                //{
                    EditorGUILayout.LabelField(status, GUILayout.ExpandWidth(true));
                //}

                var color = GUI.color;
                color.a = 0.5f;

                using (var messageColor = new GuiTools.ColorScope(color))
                {
                    var rect = new Rect(footer.rect.width - 180, footer.rect.y, 180, footer.rect.height);
                    EditorGUI.LabelField(rect, $"{ContentManager.Title} [{ContentManager.Version}]", EditorStyles.miniLabel);
                }
            }
        }

        public static void DrawEnvironmentHeader()
        {
            using (var header = new EditorGUILayout.VerticalScope(CreatorStyle.CreateStyle(background: CreatorStyle.DarkTone)))
            {
                if (EngageUser.IsAuthenticated)
                {
                    using (var userPanel = new EditorGUILayout.HorizontalScope())
                    {
                        EditorGUILayout.LabelField(Labels.EngageUser, EngageUser.ApiClient.Module<ApiClientAuthentication>().CurrentUser.Name, EditorStyles.boldLabel, GUILayout.ExpandWidth(true));
                        GuiTools.DrawButton(Labels.Logout, () => EngageUser.RequestLogout(), GUILayout.Width(CreatorStyle.LONG_BUTTON_WIDTH));
                    }
                }
                else
                {
                    GUILayout.Box(ENGAGELogo, GUILayout.ExpandWidth(true));
                    EditorGUILayout.LabelField(Labels.LoginPrompt, EditorStyles.boldLabel);

                    GUILayout.Space(5);

                    EngageUser.UserName = EditorGUILayout.TextField(new GUIContent(Labels.UserName, Labels.UserNameTooltip), EngageUser.UserName);
                    EngageUser.Password = EditorGUILayout.PasswordField(Labels.Password, EngageUser.Password);

                    GUILayout.Space(5);

                    GuiTools.DrawButton(Labels.Login, () => EngageUser.RequestLogin(EngageUser.Password), GUILayout.Width(CreatorStyle.LONG_BUTTON_WIDTH));
                }
            }
        }

        public static string GetGUID(this UnityEngine.Object selectedObject) =>
            AssetDatabase.AssetPathToGUID(AssetDatabase.GetAssetPath(selectedObject));
    }
}
