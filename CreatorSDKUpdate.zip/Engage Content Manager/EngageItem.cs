﻿using Engage.Network;
using Engage.UI.Editor;
using Newtonsoft.Json;
using System;

namespace Engage.AssetManagement.Content
{
    [JsonObject(MemberSerialization.OptIn)]
    public abstract class EngageItem<I, T> : ViewModel, IEngageItem where I : IEngageItem where T : I, IData<I>, new()
    {
        protected readonly T resetItem = new T();

        protected DateTime? created;
        protected DateTime? updated;

        public virtual int? Id { get => resetItem.Id; }
        public virtual string CreatedAt { get => created?.ToString("yyyy-MM-dd") ?? "-"; }
        public virtual string UpdatedAt { get => updated?.ToString("yyyy-MM-dd") ?? "-"; }

        #region Management Status
        protected RequestStatus requestStatus = RequestStatus.None;
        public virtual RequestStatus RequestStatus
        {
            get => requestStatus;
            protected set
            {
                requestStatus = value;
                NotifyPropertyChange(nameof(RequestStatus));
            }
        }
        protected SyncStatusManager syncStatusManager;
        public virtual SyncStatusManager Sync
        {
            get
            {
                if (syncStatusManager == null)
                {
                    InitializeSyncStatusManager();
                }

                return syncStatusManager;
            }
        }

        protected virtual void InitializeSyncStatusManager()
        {
            syncStatusManager = new SyncStatusManager();
            syncStatusManager.OnStatusChanged += NotifyPropertyChange;
        }
        #endregion

        #region Constructors
        public EngageItem() { }
        public EngageItem(I item)
        {
            resetItem.SetValues(item);
            Reset();
        }
        #endregion

        public virtual void Reset()
        {
            created = DateTime.TryParse(resetItem.CreatedAt, out DateTime createdAt) ? createdAt : (DateTime?)null;
            updated = DateTime.TryParse(resetItem.UpdatedAt, out DateTime updatedAt) ? updatedAt : (DateTime?)null;

            NotifyPropertyChange(nameof(Reset));
        }

        public abstract void Create();
        public abstract void Update();
    }
}
