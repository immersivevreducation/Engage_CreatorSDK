﻿using Engage.Network;
using Engage.UI.Editor;
using System;
using System.Collections.Generic;

namespace Engage.AssetManagement.Content
{
    public abstract class EngageItemManager<I, T, M> : ViewModel, IEngageItemManager<T> where I : IEngageItem where T : I where M : DataModule
    {
        protected abstract M DataModule { get; }
        protected abstract IList<I> Cache { get; }

        protected abstract T Create(I item);
        protected abstract T Create(string name);

        protected readonly List<T> itemInventory = new List<T>();
        public List<T> ItemDisplayList { get; } = new List<T>();
        protected virtual Predicate<T> DisplayItem => (item) => true;

        public event Action OnRefreshDisplay;

        public virtual DateTime? LastRefresh => DataModule.LastUpdate;
        public virtual RequestStatus RefreshStatus { get; protected set; }
        public bool Authenticated => EngageUser.IsAuthenticated;

        protected override void Initialize()
        {
            base.Initialize();
        }

        public override void Enable()
        {
            base.Enable();
            DataModule.OnCacheChanged += Refresh;
        }

        public override void Disable()
        {
            base.Disable();
            DataModule.OnCacheChanged -= Refresh;
        }

        protected virtual void RebuildInventory(IList<I> items)
        {
            itemInventory.Clear();

            foreach (I item in items)
            {
                itemInventory.Add(Create(item));
            }

            RefreshDisplay();
        }

        public override void Refresh()
        {
            base.Refresh();
            RebuildInventory(Cache);
        }

        public virtual async void RefreshFromServer()
        {
            RefreshStatus = RequestStatus.Requesting;

            await DataModule.RefreshAsync();

            RefreshStatus = RequestStatus.Complete;

            Refresh();
        }

        public virtual void RefreshDisplay()
        {
            ItemDisplayList.Clear();

            foreach (var item in itemInventory)
            {
                if (DisplayItem(item))
                {
                    ItemDisplayList.Add(item);
                }
            }

            UpdateDisplayView();
        }

        protected void UpdateDisplayView()
        {
            ItemDisplayList.Sort((a, b) => a.ToString().CompareTo(b.ToString()));
            OnRefreshDisplay?.Invoke();
            NotifyPropertyChange(nameof(UpdateDisplayView));
        }
    }
}
