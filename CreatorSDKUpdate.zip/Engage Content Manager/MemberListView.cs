﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System;

namespace Engage.AssetManagement.Content
{
    public static class MemberListView
    {
        public static int MaxRowLegnth { get; set; } = 4;

        public static void DrawMemberListPanel<T>(string property, List<T> members, Func<T, string> getName, Action<T> memberAction, Action<Action<T>, T[]> selectNewMember, Action<T> selectionCallback) where T : class
        {
            T actionItem = null;

            using (var memberLayout = new EditorGUILayout.VerticalScope())
            {
                using (var groupDisplay = new EditorGUILayout.HorizontalScope())
                {
                    if (GUILayout.Button("+", GUILayout.Width(20)))
                    {
                        selectNewMember?.Invoke(selectionCallback, members.ToArray());
                    }

                    EditorGUILayout.LabelField(property, GUILayout.Width(EditorGUIUtility.labelWidth), GUILayout.ExpandWidth(false));
                }

                for (int j = 0; j < members.Count;)
                {
                    int rowLength = 0;

                    using (var groupDisplay = new EditorGUILayout.HorizontalScope())
                    {
                        while (rowLength++ < MaxRowLegnth && j < members.Count)
                        {
                            var member = members[j++];
                            DrawMemberButton(getName?.Invoke(member), () => { actionItem = member; });
                        }

                        EditorGUILayout.LabelField("", GUILayout.ExpandWidth(true));
                    }
                }
            }

            if (actionItem != null)
            {
                memberAction?.Invoke(actionItem);
            }
        }

        public static void DrawMemberButton(string label, Action callback)
        {
            if (GUILayout.Button(label, GUILayout.ExpandWidth(false)))
            {
                callback?.Invoke();
            }
        }
    }
}