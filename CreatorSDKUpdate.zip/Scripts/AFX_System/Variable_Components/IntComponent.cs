﻿using UnityEngine;
namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/Int")]
    public class IntComponent : ValueComponent<int> { }
}
