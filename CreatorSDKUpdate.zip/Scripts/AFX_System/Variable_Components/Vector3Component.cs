﻿using UnityEngine;

namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/Vector3")]
    public class Vector3Component : ValueComponent<Vector3> { }
}
