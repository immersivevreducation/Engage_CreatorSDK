﻿using UnityEngine;

namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/Quaternion")]
    public class QuaternionComponent : ValueComponent<Quaternion> { }
}
