﻿using UnityEngine;
namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/Int")]
    public class ValueComponent<T> : MonoBehaviour
    {
        [SerializeField]
        private T value;

        public T Value { get => value; set => this.value = value; }
    }
}
