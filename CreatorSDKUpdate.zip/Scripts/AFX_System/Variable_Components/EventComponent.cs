﻿using UnityEngine;
using UnityEngine.Events;
namespace AFX
{
    [AddComponentMenu("AFX/Event")]
    public class EventComponent : ValueComponent<UnityEvent> { }
}
