﻿using UnityEngine;

namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/Float")]
    public class FloatComponent : ValueComponent<float> { }
}
