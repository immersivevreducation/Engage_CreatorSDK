﻿using UnityEngine;
namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/Bool")]
    public class BoolComponent : ValueComponent<bool> { }
}
