﻿using System.Collections.Generic;
using UnityEngine;
namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/List/GameObject")]
    public class ListGameObjectComponent : ValueComponent<List<GameObject>> { }
}
