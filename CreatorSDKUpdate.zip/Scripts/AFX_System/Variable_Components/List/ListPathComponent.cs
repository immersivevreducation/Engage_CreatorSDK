﻿using System.Collections.Generic;
using UnityEngine;
namespace AFX
{
    [AddComponentMenu("AFX/ComponentVariables/List/Path")]
    public class ListPathComponent : ValueComponent<List<PathData>> { }
}
