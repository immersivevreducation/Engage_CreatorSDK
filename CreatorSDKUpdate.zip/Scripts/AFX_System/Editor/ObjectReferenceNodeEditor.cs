﻿using XNodeEditor;
using UnityEngine;
namespace AFX
{
    [CustomNodeEditor(typeof(ObjectReferenceNode))]
    public class ObjectReferenceEditor : NodeEditor
    {
        private readonly Color errorColor = new Color(0.5f, 0.2f, 0.2f);

        private ObjectReferenceNode objRefNode;

        public override void OnBodyGUI()
        {
            if (objRefNode == null) objRefNode = target as ObjectReferenceNode;
            serializedObject.Update();
            base.OnBodyGUI();

            if (objRefNode.HasPort("input"))
            {
                if (!objRefNode.GetInputPort("input").IsConnected)
                {
                    objRefNode.ReferenceUse = true;
                    NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("referenceName"));
                }
                else
                {
                    objRefNode.ReferenceUse = false;
                }
            }
            else
            {
                objRefNode.ReferenceUse = true;
                NodeEditorGUILayout.PropertyField(serializedObject.FindProperty("referenceName"));
            }
            serializedObject.ApplyModifiedProperties();
        }

        public override Color GetTint()
        {
            if (Application.isPlaying)
            {
                if (string.IsNullOrEmpty(serializedObject.FindProperty("referenceName").stringValue) || !string.IsNullOrEmpty(serializedObject.FindProperty("error").stringValue))
                {
                    return errorColor;
                }
            }
            return base.GetTint();
        }
    }
}