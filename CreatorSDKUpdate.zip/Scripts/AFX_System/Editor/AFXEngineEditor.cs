﻿using XNodeEditor;
using UnityEngine;
using UnityEditor;
namespace AFX
{
    [InitializeOnLoad]
    [CustomEditor(typeof(AFXEngine))]
    public class AFXEngineEditor : Editor
    {
        AFXEngine afxEngine;
        NodeEditorWindow window;

        public void Awake()
        {
            EditorApplication.playModeStateChanged += LogPlayModeState;
            if (afxEngine == null)
            {
                afxEngine = (AFXEngine)target;
            }
        }

        public override void OnInspectorGUI()
        {
            DrawDefaultInspector();
            EditorApplication.update += RefreshNodeGraph;
            if (GUILayout.Button("Edit Graph"))
            {
                OpenGraphInstance();
            }
        }

        private void LogPlayModeState(PlayModeStateChange state)
        {
            bool isOpen = false;
            if (NodeEditorWindow.current != null)
            {
                isOpen = true;
            }
            //If the editor window is already open swap it to the instance or back to the asset version.
            if (state == PlayModeStateChange.EnteredPlayMode)
            {
                if (isOpen)
                {
                    window = XNodeEditor.NodeEditorWindow.Open(afxEngine.afxNodeGraphRuntimeVersion, afxEngine.afxNodeGraphRuntimeVersion.name);
                }
            }
            if (state == PlayModeStateChange.ExitingPlayMode)
            {
                if (isOpen)
                {
                    window = XNodeEditor.NodeEditorWindow.Open(afxEngine.afxNodeGraphEditorVersion, afxEngine.afxNodeGraphEditorVersion.name);
                }
            }
        }

        public void OpenGraphInstance()
        {
            if (Application.isPlaying)
            {
                window = XNodeEditor.NodeEditorWindow.Open(afxEngine.afxNodeGraphRuntimeVersion, afxEngine.afxNodeGraphRuntimeVersion.name);
                window.Repaint();
            }
            else
            {
                window = XNodeEditor.NodeEditorWindow.Open(afxEngine.afxNodeGraphEditorVersion, afxEngine.afxNodeGraphEditorVersion.name);
                window.Repaint();
            }
        }

        public void RefreshNodeGraph()
        {
            if (Application.isPlaying && Application.isEditor)
            {
                NodeEditorWindow.RepaintAll();
            }
        }
    }
}
