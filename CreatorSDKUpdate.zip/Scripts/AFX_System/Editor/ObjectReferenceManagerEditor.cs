﻿using UnityEngine;
using UnityEditor;

namespace AFX
{
    [CustomEditor(typeof(AFXObjectReferenceManager))]
    public class ObjectReferenceManagerEditor : Editor
    {
        AFXObjectReferenceManager objRefManager;

        void OnEnable()
        {
            if (objRefManager == null)
            {
                objRefManager = (AFXObjectReferenceManager)target;
            }
        }

        public override void OnInspectorGUI()
        {
            //DrawDefaultInspector(); //left in for quick debuging.
            if (GUILayout.Button("Clear Reference Slots"))
            {
                objRefManager.objectRefsEngine.Clear();
            }
            // Display the reference field entries
            foreach (ObjectReference item in objRefManager.objectRefsEngine)
            {
                item.referenceValue = EditorGUILayout.ObjectField(item.referenceName, item.referenceValue, item.myType, true);
            }

            if (GUILayout.Button("Add Reference Slots"))
            {
                objRefManager.AddReferenceSlots();
            }
            PrefabUtility.RecordPrefabInstancePropertyModifications(objRefManager);
        }
    }
}