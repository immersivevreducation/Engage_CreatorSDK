﻿using UnityEngine;
using XNodeEditor;
namespace AFX
{
    [CustomNodeEditor(typeof(AFXActiveNode))]
    public class ActiveNodeEditor : NodeEditor
    {
        private Color enabledColor = new Color(0.2f, 0.4f, 0.2f);
        private Color errorColor = new Color(0.5f, 0.2f, 0.2f);
        public override Color GetTint()
        {
            if (Application.isPlaying)
            {
                if (!string.IsNullOrEmpty(serializedObject.FindProperty("error").stringValue))
                {
                    return errorColor;
                }
                if (serializedObject.FindProperty(nameof(AFXActiveNode.enabled)).boolValue)
                {
                    return enabledColor;
                }
                
            }
            return base.GetTint();
        }
    }
}