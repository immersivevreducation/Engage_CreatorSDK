﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateAssetMenu]
    public class AFXGraph : NodeGraph
    {

    }
}