// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 12/08/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;
using XNode;

namespace AFX
{
    public class AFXNode : Node
    {
        [HideInInspector]
        [SerializeField]
        protected string error;
    }
}
