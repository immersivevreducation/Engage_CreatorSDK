﻿using UnityEngine;
using XNode;

namespace AFX
{
    [AddComponentMenu("AFX/Engine")]
    [RequireComponent(typeof(AFXObjectReferenceManager))]
    public class AFXEngine : MonoBehaviour
    {
        [HideInInspector]
        AFXObjectReferenceManager referenceManager;
        public NodeGraph afxNodeGraphEditorVersion;
        [HideInInspector]
        public NodeGraph afxNodeGraphRuntimeVersion;
        bool ready = false;

        void Awake()
        {
            referenceManager = GetComponent<AFXObjectReferenceManager>();
            afxNodeGraphRuntimeVersion = afxNodeGraphEditorVersion.Copy(); // get an editable runtime version of the graph, instantiates all the nodes too.
            if (afxNodeGraphRuntimeVersion != null)
            {
                InjectObjectRefrences();
                afxNodeGraphRuntimeVersion.AFXAwake?.Invoke();
            }
            else
            {
                Debug.Log("Not Ready");
            }
        }

        private void Start()
        {
            if (ready)
            {
                afxNodeGraphRuntimeVersion.AFXStart?.Invoke();
            }
        }

        private void OnEnable()
        {
            if (ready)
            {
                afxNodeGraphRuntimeVersion.AFXOnEnable?.Invoke();
            }
        }

        void Update()
        {
            if (ready)
            {
                afxNodeGraphRuntimeVersion.AFXUpdate?.Invoke();
            }
        }

        void LateUpdate()
        {
            if (ready)
            {
                afxNodeGraphRuntimeVersion.AFXLateUpdate?.Invoke();
            }
        }

        void FixedUpdate()
        {
            if (ready)
            {
                afxNodeGraphRuntimeVersion.AFXFixedUpdate?.Invoke();
            }
        }

        private void InjectObjectRefrences()
        {
            foreach (ObjectReference objRef in referenceManager.objectRefsEngine)
            {
                afxNodeGraphRuntimeVersion.objectReferencesGraph.Add(objRef.referenceName, objRef.referenceValue);
            }
            ready = true;
        }
    }
}

