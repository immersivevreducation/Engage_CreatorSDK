// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 05/08/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/
using UnityEngine;

namespace AFX
{
    [System.Serializable]
    public class ObjectReference
    {
        public string referenceName;
        public Object referenceValue;
        public System.Type myType;

        public ObjectReference(string referenceNameIN, Object referenceValueIN, System.Type typeIN)
        {
            referenceName = referenceNameIN;
            referenceValue = referenceValueIN;
            myType = typeIN;
        }
    }
}
