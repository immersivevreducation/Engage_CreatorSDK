// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 12/08/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{
    public abstract class AFXActiveNode : AFXNode
    {
        public enum UpdateMode
        {
            Update,
            FixedUpdate,
            LateUpdate,
            Awake,
            Start,
            OnEnable
        }
        [SerializeField]
        protected UpdateMode updateMode = UpdateMode.Update;
        [Input] public bool enabled = true;

        protected override void Init()
        {
            base.Init();
            switch (updateMode)
            {
                case UpdateMode.Update:
                    graph.AFXUpdate += PreExecuteNode;
                    break;
                case UpdateMode.FixedUpdate:
                    graph.AFXFixedUpdate += PreExecuteNode;
                    break;
                case UpdateMode.LateUpdate:
                    graph.AFXLateUpdate += PreExecuteNode;
                    break;
                case UpdateMode.Awake:
                    graph.AFXLateUpdate += PreExecuteNode;
                    break;
                case UpdateMode.Start:
                    graph.AFXLateUpdate += PreExecuteNode;
                    break;
                case UpdateMode.OnEnable:
                    graph.AFXLateUpdate += PreExecuteNode;
                    break;
                default:
                    break;
            }
        }

        private void PreExecuteNode()
        {
            enabled = GetInputValue(nameof(enabled), enabled);
            if (enabled)
            {
                error = null;
                try
                {
                    ExecuteNode();
                }
                catch (System.Exception e)
                {
                    error = e.ToString();
                    throw;
                }
            }
        }

        protected abstract void ExecuteNode();
    }
}
