﻿using System.Collections.Generic;
using UnityEngine;
using System.Linq;

namespace AFX
{
    public class AFXObjectReferenceManager : MonoBehaviour
    {
        [HideInInspector]
        public List<ObjectReference> objectRefsEngine = new List<ObjectReference>();
        public AFXEngine afxEngine;

        private void Start()
        {
            afxEngine = GetComponent<AFXEngine>();
        }


        public void AddReferenceSlots()
        {
            if (afxEngine == null) afxEngine = GetComponent<AFXEngine>();

            //get just the ref nodes into a list
            List<ObjectReferenceNode> objRefNodes = new List<ObjectReferenceNode>();
            foreach (ObjectReferenceNode graphRef in afxEngine.afxNodeGraphEditorVersion.nodes.Where(node => node is ObjectReferenceNode))
            {
                objRefNodes.Add(graphRef);
            }

            //check for nulls or changed names and keep what's left
            if (objectRefsEngine.Count > 0)
            {
                // List to store already filled slots.
                List<ObjectReference> oldlist = new List<ObjectReference>();

                foreach (ObjectReference managerRef in objectRefsEngine)
                {
                    foreach (ObjectReferenceNode graphRef in objRefNodes)
                    {
                        if (DuplicateInListCheck(graphRef, oldlist) || string.IsNullOrEmpty(graphRef.ReferenceName))
                        {
                            continue;
                        }
                        if ((managerRef.referenceName == graphRef.ReferenceName) && managerRef.referenceValue != null)
                        {
                            if (graphRef.ReferenceUse)
                            {
                                oldlist.Add(managerRef);
                            }
                        }
                    }
                }
                objectRefsEngine.Clear();
                objectRefsEngine.AddRange(oldlist);
            }
            //
            foreach (ObjectReferenceNode graphRef in objRefNodes)
            {
                if (DuplicateInListCheck(graphRef, objectRefsEngine) || string.IsNullOrEmpty(graphRef.ReferenceName))
                {
                    continue;
                }

                if (graphRef.ReferenceUse)
                {
                    objectRefsEngine.Add(new ObjectReference(graphRef.ReferenceName, null, graphRef.MyType));
                }
            }
            // orders ref slots by type name then by refname
            objectRefsEngine = objectRefsEngine.OrderBy(o => o.myType.Name).ThenBy(o => o.referenceName).ToList();
        }

        bool DuplicateInListCheck(ObjectReferenceNode objRef, List<ObjectReference> objRefList)
        {
            foreach (ObjectReference reference in objRefList)
            {
                if (objRef.ReferenceName == reference.referenceName)
                {
                    return true;
                }
            }
            return false;
        }
    }
}



