// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 05/08/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{
    public class GrabInfo
    {
        public bool currentlyGrabbed;
        public Transform transform;
        public GameObject offsetGO;
    }
}
