// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 20/07/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{

    public class GrabObject : MonoBehaviour
    {
        #region Setup Fields

        public bool initalized = false;
        

        bool vrMode;

        int primaryHand;
        int secondaryHand;

        [HideInInspector]
        public GrabInfo rightHand;
        [HideInInspector]
        public GrabInfo leftHand;
        [HideInInspector]
        public GrabInfo mouse;

        #endregion

        #region Fields

        GrabInfo holderObject;
        public GrabInfo HolderObject
        {
            get
            {
                if (mouse != null)
                {
                    if (mouse.currentlyGrabbed)
                    {
                        holderObject = mouse;
                        return holderObject;
                    }
                }
                if (rightHand != null)
                {
                    if (rightHand.currentlyGrabbed)
                    {
                        holderObject = rightHand;
                        return holderObject;
                    }
                }
                if (leftHand != null)
                {
                    if (leftHand.currentlyGrabbed)
                    {
                        holderObject = leftHand;
                        return holderObject;
                    }
                }
                if (holderObject != null)
                {
                    return holderObject;
                }
                return null;
            }

        }
        public Collider colliderToGrab;
        public bool maintainOffset;

        public bool requireTriggerPress;

        public bool requireGrippedPress;

        public float maxMouseDistance = 5f;

        #endregion


        void Update()
        {
        }

    }
}
