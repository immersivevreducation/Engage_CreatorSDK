/// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 20/07/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;
using System.Collections.Generic;
namespace AFX
{
    [RequireComponent(typeof(GrabObject))]
    [AddComponentMenu("AFX/Interaction/GrabObject/Throwable")]
    public class GrabObjectThrowable : MonoBehaviour
    {
        GrabObject grabObject;
        Transform grabbedTransform;

        Queue<Vector3> vectorsOverTime = new Queue<Vector3>();
        Queue<Vector3> rotationOverTime = new Queue<Vector3>();
        Rigidbody rigidBody;
        [SerializeField]
        float throwStrength = 1;
        [SerializeField]
        bool useObjectMass = false;

        Vector3 throwVector;
        Vector3 rotVector;
        Vector3 lastPos;
        Vector3 lastRot;

        void OnEnable()
        {
            grabObject = gameObject.GetComponent<GrabObject>();
            grabbedTransform = grabObject.colliderToGrab.transform;
            rigidBody = grabObject.gameObject.GetComponent<Rigidbody>();
        }

        void FixedUpdate()
        {
            if (grabObject.initalized)
            {
                if (grabObject.HolderObject == null)
                {
                    return;
                }
                if (rigidBody == null)
                {
                    return;
                }
                if (grabObject.HolderObject.currentlyGrabbed)
                {
                    rigidBody.velocity = Vector3.zero;
                    rigidBody.angularVelocity = Vector3.zero;
                    throwVector = CalculateThrowVector();
                    rotVector = CalculateThrowRotation();
                }
                if (!grabObject.HolderObject.currentlyGrabbed)
                {
                    if (rotVector != Vector3.zero)
                    {
                        if (useObjectMass)
                        {
                            rigidBody.AddTorque(rotVector * throwStrength, ForceMode.Impulse);
                        }
                        else
                        {
                            rigidBody.AddTorque(rotVector * throwStrength, ForceMode.VelocityChange);
                        }

                        rotVector = Vector3.zero;
                        rotationOverTime.Clear();
                    }
                    if (throwVector != Vector3.zero)
                    {
                        if (useObjectMass)
                        {
                            rigidBody.AddForce(throwVector * throwStrength, ForceMode.Impulse);
                        }
                        else
                        {
                            rigidBody.AddForce(throwVector * throwStrength, ForceMode.VelocityChange);
                        }

                        throwVector = Vector3.zero;
                        vectorsOverTime.Clear();
                    }
                }
            }
        }

        Vector3 CalculateThrowVector()
        {

            Vector3 velocity = (grabbedTransform.position - lastPos) / Time.deltaTime;
            vectorsOverTime.Enqueue(velocity);
            if (vectorsOverTime.Count > 10)
            {
                vectorsOverTime.Dequeue();
            }


            Vector3 sum = new Vector3();
            foreach (var item in vectorsOverTime)
            {
                sum += item;
            }
            lastPos = grabbedTransform.position;
            return sum / vectorsOverTime.Count;
        }

        Vector3 CalculateThrowRotation()
        {

            Vector3 velocity = (grabbedTransform.eulerAngles - lastRot) / Time.deltaTime;
            rotationOverTime.Enqueue(velocity);
            if (rotationOverTime.Count > 10)
            {
                rotationOverTime.Dequeue();
            }
            Vector3 sum = new Vector3();
            foreach (var item in rotationOverTime)
            {
                sum += item;
            }
            lastRot = grabbedTransform.localEulerAngles;
            return sum / rotationOverTime.Count;
        }
    }
}
