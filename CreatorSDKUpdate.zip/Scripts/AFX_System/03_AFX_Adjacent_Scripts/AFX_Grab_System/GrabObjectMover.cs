// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 20/07/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{
    [RequireComponent(typeof(GrabObject))]
    [AddComponentMenu("AFX/Interaction/GrabObject/Mover")]
    public class GrabObjectMover : MonoBehaviour
    {
        GrabObject grabObject;
        Transform grabbedTransform;
        public bool movable = true;
        public bool rotatable = true;

        void OnEnable()
        {
            grabObject = gameObject.GetComponent<GrabObject>();
            grabbedTransform = grabObject.colliderToGrab.transform;
        }

        void LateUpdate()
        {
            if (grabObject == null)
            {
                return;
            }

            if (grabObject.HolderObject != null)
            {
                MoveHeldObject(grabObject.HolderObject);
            }
        }

        private void MoveHeldObject(GrabInfo grabinfo)
        {
            if (grabinfo == null)
            {
                return;
            }
            if (grabinfo.currentlyGrabbed)
            {
                if (grabObject.maintainOffset)
                {
                    if (movable)
                    {
                        grabbedTransform.position = grabinfo.offsetGO.transform.position;
                    }
                    if (rotatable)
                    {
                        grabbedTransform.rotation = grabinfo.offsetGO.transform.rotation;
                    }
                }
                else
                {
                    if (movable)
                    {
                        grabbedTransform.position = grabinfo.transform.transform.position;
                    }
                    if (rotatable)
                    {
                        grabbedTransform.rotation = grabinfo.transform.transform.rotation;
                    }
                }
            }
        }
    }
}
