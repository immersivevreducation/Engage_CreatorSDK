using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine;

namespace AFX
{
    [AddComponentMenu("AFX/AttachTo/Object To Player")]
    public class AttachObjectToPlayerBody : MonoBehaviour
    {
        [SerializeField]
        GameObject objectToAttach;

        [SerializeField]
        bool useParenting;
        [Space]
        [SerializeField]
        bool allowOffset;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool attachToBodyPartWhenClose;
        [SerializeField]
        float attachDistance;
        [SerializeField]
        bool lockWhenAttached;
        [Space]
        [SerializeField]
        UnityEvent eventToFireWhenAttaching;
        [SerializeField]
        UnityEvent eventToFireWhenDetaching;

        public enum TargetBodyParts
        {
            none,
            Any,
            playerRoot,
            playerHead,
            playerChest,
            playerHips,
            playerHandL,
            playerHandR,
            playerFootL,
            playerFootR
        }
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        TargetBodyParts bodyPart;    
    }
}
