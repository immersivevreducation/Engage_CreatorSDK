// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 20/07/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{
    [RequireComponent(typeof(GrabObject))]
    [AddComponentMenu("AFX/Interaction/GrabObject/Secondary Grab Point")]
    public class GrabObjectSecondaryGrabPoint : MonoBehaviour
    {
        [Header("---------------------------------")]
        public GrabObject primaryGrabObject;
        public Transform medianObject;

        GrabObject grabObject;
        enum TakeRotationFrom
        {
            Primary,
            Secondary,
            Blend
        }

        [SerializeField]
        TakeRotationFrom takeRotationFrom;
        Vector3 worldUp = new Vector3();
        Vector3 WorldUp
        {
            get
            {
                switch (takeRotationFrom)
                {
                    case TakeRotationFrom.Primary:
                        worldUp = primaryGrabObject.gameObject.transform.up;
                        break;
                    case TakeRotationFrom.Secondary:
                        worldUp = grabbedTransform.up;
                        break;
                    case TakeRotationFrom.Blend:
                        worldUp = primaryGrabObject.gameObject.transform.up + grabbedTransform.up;
                        break;
                    default:
                        break;
                }
                return worldUp;
            }
        }

        Transform grabbedTransform;

        void OnEnable()
        {
            grabObject = gameObject.GetComponent<GrabObject>();
            grabbedTransform = grabObject.colliderToGrab.transform;
        }

        void LateUpdate()
        {
            if (grabObject == null)
            {
                return;
            }
            bool grabbedSecondary = false;
            if (grabObject.HolderObject != null)
            {
                grabbedSecondary = grabObject.HolderObject.currentlyGrabbed;
            }
            bool grabbedPrimary = false;
            if (primaryGrabObject.HolderObject != null)
            {
                grabbedSecondary = primaryGrabObject.HolderObject.currentlyGrabbed;
            }
            if (medianObject != null)
            {
                bool grabbed = false;
                if (grabObject.HolderObject != null)
                {
                    grabbed = grabObject.HolderObject.currentlyGrabbed;
                }
                SecondaryObjectMedian(grabbedSecondary, grabbedPrimary);
            }
            else
            {
                PointToSecondaryObject(grabbedSecondary);
            }
        }

        private void PointToSecondaryObject(bool grabbed)
        {
            if (grabbed)
            {
                primaryGrabObject.gameObject.transform.LookAt(grabbedTransform, WorldUp);
            }
        }

        private void SecondaryObjectMedian(bool secondaryGrabbed, bool primaryGrabbed)
        {
            medianObject.position = (primaryGrabObject.transform.position + grabbedTransform.position) / 2;
            medianObject.transform.LookAt(grabbedTransform, WorldUp);
            medianObject.RotateAround(medianObject.position, medianObject.up, 90);
        }
    }
}
