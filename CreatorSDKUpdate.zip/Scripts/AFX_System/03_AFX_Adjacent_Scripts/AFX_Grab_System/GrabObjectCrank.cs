// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 20/07/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{
    [RequireComponent(typeof(GrabObject))]
    [AddComponentMenu("AFX/Interaction/GrabObject/Crank")]
    public class GrabObjectCrank : MonoBehaviour
    {
        GrabObject grabObject;
        Transform grabbedTransform;
        Vector3? lastCrankAngle;
        Vector3 colliderCenter;

        [SerializeField]
        bool crankAroundX;
        [SerializeField]
        bool crankAroundY;
        [SerializeField]
        bool crankAroundZ;

        void OnEnable()
        {
            grabObject = gameObject.GetComponent<GrabObject>();
            grabbedTransform = grabObject.colliderToGrab.transform;
            colliderCenter = AFXColliders.GetCollidersCentersByType(grabObject.colliderToGrab);
        }

        void LateUpdate()
        {
            if (grabObject == null)
            {
                return;
            }

            if (grabObject.HolderObject != null)
            {
                if (grabObject.maintainOffset)
                {
                    Crank(grabObject.HolderObject.offsetGO.transform);
                }
                else
                {
                    Crank(grabObject.HolderObject.transform);
                }
            }
        }

        private void Crank(Transform handIN)
        {
            if (crankAroundX)
            {
                CrankLikeRotation(handIN.transform, grabbedTransform.transform.TransformDirection(Vector3.right));
                return;
            }
            if (crankAroundY)
            {
                CrankLikeRotation(handIN.transform, grabbedTransform.transform.TransformDirection(Vector3.up));
                return;
            }
            if (crankAroundZ)
            {
                CrankLikeRotation(handIN.transform, grabbedTransform.transform.TransformDirection(Vector3.forward));
                return;
            }
        }

        private void CrankLikeRotation(Transform handIn, Vector3 axisOfRotation)
        {
            Vector3 handPosProjected = Vector3.ProjectOnPlane(handIn.position - grabbedTransform.TransformPoint(colliderCenter), axisOfRotation);
            if (lastCrankAngle.HasValue)
            {
                float amountToRotatate = Vector3.Angle(handPosProjected, lastCrankAngle.Value);
                float direction = Vector3.Dot(Vector3.Cross(handPosProjected, lastCrankAngle.Value).normalized, axisOfRotation);
                grabbedTransform.Rotate(axisOfRotation, amountToRotatate * -direction, Space.World);
            }
            lastCrankAngle = handPosProjected;
        }
    }
}
