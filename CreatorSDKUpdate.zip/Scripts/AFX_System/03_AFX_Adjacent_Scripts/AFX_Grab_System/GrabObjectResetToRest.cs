// /*-------------------------------------------
// ---------------------------------------------
// Creation Date: 18/08/22
// Author: tlynch
// Description: ENGAGE
// Engage XR
// ---------------------------------------------
// -------------------------------------------*/

using UnityEngine;

namespace AFX
{
    [RequireComponent(typeof(GrabObject))]
    [AddComponentMenu("AFX/Interaction/GrabObject/Reset To Rest Point")]
    public class GrabObjectResetToRest : MonoBehaviour
    {
        [SerializeField] private Transform restTransform;
        GrabObject grabObject;
        Transform grabbedTransform;

        void Awake()
        {
            grabObject = gameObject.GetComponent<GrabObject>();
            grabbedTransform = grabObject.colliderToGrab.transform;
        }

        void LateUpdate()
        {
            if (grabObject == null)
            {
                return;
            }

            if (grabObject.HolderObject != null)
            {
                if (!grabObject.HolderObject.currentlyGrabbed)
                {
                    ResetObjectToRestPos();
                }
            }
        }

        private void ResetObjectToRestPos()
        {
            grabbedTransform.position = restTransform.position;
            grabbedTransform.rotation = restTransform.rotation;
        }
    }
}
