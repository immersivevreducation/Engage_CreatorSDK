﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;

namespace AFX
{
    [AddComponentMenu("AFX/Path/Path Data")]
    public class PathData : MonoBehaviour
    {
        public Path path;      
    }    
}
