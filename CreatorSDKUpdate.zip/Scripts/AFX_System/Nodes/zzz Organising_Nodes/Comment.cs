﻿using UnityEngine;

namespace AFX
{
    [NodeWidth(300)]
    [CreateNodeMenu("")]
    public class Comment : AFXNode
    {
        [SerializeField]
        [TextArea(10, 50)]
        private string comment;
    }
}