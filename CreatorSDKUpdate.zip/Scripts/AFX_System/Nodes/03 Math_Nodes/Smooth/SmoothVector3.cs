﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Smooth/Smooth Vector3")]
    public class SmoothVector3 : AFXActiveNode
    {
        [SerializeField]
        [Input] private Vector3 vector3In;
        [SerializeField]
        [Input] private float smoothingAmountIn;

        [SerializeField]
        [Output] private Vector3 vector3Out = Vector3.zero;

        public override object GetValue(NodePort port)
        {
            return vector3Out;
        }

        void SmoothVector3s()
        {
            vector3In = GetInputValue(nameof(vector3In), vector3In);
            
            if (vector3Out != vector3In)
            {
                smoothingAmountIn = GetInputValue(nameof(smoothingAmountIn), smoothingAmountIn);
                if (smoothingAmountIn != 0f)
                {
                    float t = (1f * Time.deltaTime) / smoothingAmountIn;
                    vector3Out.x = Mathf.Lerp(vector3Out.x, vector3In.x, t);
                    vector3Out.y = Mathf.Lerp(vector3Out.y, vector3In.y, t);
                    vector3Out.z = Mathf.Lerp(vector3Out.z, vector3In.z, t);
                }                
            }
        }

        protected override void ExecuteNode()
        {
            SmoothVector3s();
        }
    }
}