﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Smooth/SmoothFloat")]
    public class SmoothFloat : AFXActiveNode
    {
        [SerializeField]
        [Input] private float floatIn;
        [SerializeField]
        [Input] private float smoothingAmountIn;

        [SerializeField]
        [Output] private float floatOut = 0f;

        public override object GetValue(NodePort port)
        {
            return floatOut;
        }

        void SmoothFloats()
        {
            floatIn = GetInputValue(nameof(floatIn), floatIn);

            if (floatOut != floatIn)
            {
                smoothingAmountIn = GetInputValue(nameof(smoothingAmountIn), smoothingAmountIn);
                if (smoothingAmountIn != 0f)
                {
                    float t = (1f * Time.deltaTime) / smoothingAmountIn;
                    floatOut = Mathf.Lerp(floatOut, floatIn, t);
                }
            }
        }

        protected override void ExecuteNode()
        {
            SmoothFloats();
        }
    }
}