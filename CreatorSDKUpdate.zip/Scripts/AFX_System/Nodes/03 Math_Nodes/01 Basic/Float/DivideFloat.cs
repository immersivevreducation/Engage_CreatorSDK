﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Basic/Float/Divide")]
    public class DivideFloat : AFXNode
    {
        [SerializeField]
        [Input] private float a = 1f;
        [SerializeField]
        [Input] private float b = 1f;

        [SerializeField]
        [Output] private float output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            if (b != 0)
            {
                return a / b;
            }
            return a;
        }
    }
}