﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Basic/Float/Subtract")]
    public class SubtractFloat : AFXNode
    {
        [SerializeField]
        [Input] private float a = 1f;
        [SerializeField]
        [Input] private float b = 1f;

        [SerializeField]
        [Output] private float output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            return a - b;
        }
    }
}