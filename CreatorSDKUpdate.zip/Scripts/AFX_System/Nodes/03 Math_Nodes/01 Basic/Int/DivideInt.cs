﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Basic/Int/Divide")]
    public class DivideInt : AFXNode
    {
        [SerializeField]
        [Input] private int a = 1;
        [SerializeField]
        [Input] private int b = 1;

        [SerializeField]
        [Output] private int output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            if (b != 0)
            {
                return a / b;
            }
            return a;
        }
    }
}