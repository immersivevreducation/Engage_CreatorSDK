﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Basic/Int/Subtract")]
    public class SubtractInt : AFXNode
    {
        [SerializeField]
        [Input] private int a = 1;
        [SerializeField]
        [Input] private int b = 1;

        [SerializeField]
        [Output] private int output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            return a - b;
        }
    }
}