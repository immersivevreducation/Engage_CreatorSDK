using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Basic/Vector3/Add")]
    public class AddVector3 : AFXNode
    {
        [SerializeField]
        [Input] private Vector3 a;
        [SerializeField]
        [Input] private Vector3 b;

        [SerializeField]
        [Output] private Vector3 output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            return a + b;
        }
    }
}