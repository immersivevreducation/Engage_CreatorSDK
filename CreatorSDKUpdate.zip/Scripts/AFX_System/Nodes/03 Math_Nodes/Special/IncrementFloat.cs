﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Special/Increment Float")]
    public class IncrementFloat : AFXActiveNode
    {
        [SerializeField]
        [Input] private bool reset = false;
        [SerializeField]
        [Input(ShowBackingValue.Always)] private float floatIn;
        [SerializeField]
        [Input] private float incrementIn;

        [SerializeField]
        [Output] private float output;

        private float newValue;
        private float oldValue;

        protected override void Init()
        {
            base.Init();
            floatIn = GetInputValue(nameof(floatIn), floatIn);
            newValue = floatIn;
            oldValue = floatIn;
        }

        public override object GetValue(NodePort port)
        {
            return newValue;
        }

        void CountUp()
        {
            reset = GetInputValue(nameof(reset), reset);
            if (reset)
            {
                newValue = oldValue;
            }

            incrementIn = GetInputValue(nameof(incrementIn), incrementIn);
            newValue += incrementIn;
            floatIn = newValue;
        }

        protected override void ExecuteNode()
        {
            CountUp();
        }
    }
}