﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Advanced/Lerp/Lerp Float")]
    public class LerpFloat : AFXNode
    {
        [SerializeField]
        [Input] private float a;
        [SerializeField]
        [Input] private float b;
        [SerializeField]
        [Input] private float lerpAmountIn;
        [SerializeField]
        [Output] private float output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            lerpAmountIn = GetInputValue(nameof(lerpAmountIn), lerpAmountIn);

            return Mathf.Lerp(a, b, lerpAmountIn);
        }
    }
}