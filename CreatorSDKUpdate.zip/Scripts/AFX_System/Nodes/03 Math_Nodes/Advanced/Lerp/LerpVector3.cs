﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Advanced/Lerp/Lerp Vector3")]
    public class LerpVector3 : AFXNode
    {
        [SerializeField]
        [Input] private Vector3 a;
        [SerializeField]
        [Input] private Vector3 b;
        [SerializeField]
        [Input] private float lerpAmountIn;

        [SerializeField]
        [Output] private Vector3 output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);
            lerpAmountIn = GetInputValue(nameof(lerpAmountIn), lerpAmountIn);

            return Vector3.Lerp(a, b, lerpAmountIn);
        }
    }
}