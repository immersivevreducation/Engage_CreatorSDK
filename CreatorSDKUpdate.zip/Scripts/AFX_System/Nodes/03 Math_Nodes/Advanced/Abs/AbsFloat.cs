﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Advanced/Abs/Float")]
    public class AbsFloat : AFXNode
    {
        [SerializeField]
        [Input] private float floatIn;

        [SerializeField]
        [Output] private float floatOut;

        public override object GetValue(NodePort port)
        {
            floatIn = GetInputValue(nameof(floatIn), floatIn);
            floatOut = Mathf.Abs(floatIn);
            return floatOut;
        }
    }
}