﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Advanced/Min")]
    public class MinFloat : AFXNode
    {
        [SerializeField]
        [Input] private float a;
        [SerializeField]
        [Input] private float b;

        [SerializeField]
        [Output] private float floatOut;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);

            return Mathf.Min(a, b);
        }
    }
}