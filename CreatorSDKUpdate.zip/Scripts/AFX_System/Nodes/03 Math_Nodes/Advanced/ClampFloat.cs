﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Advanced/Clamp Float")]
    public class ClampFloat : AFXNode
    {
        [SerializeField]
        [Input] private float floatIn;
        [SerializeField]
        [Input] private float min;
        [SerializeField]
        [Input] private float max;

        [SerializeField]
        [Output] private float output;

        public override object GetValue(NodePort port)
        {
            floatIn = GetInputValue(nameof(floatIn), floatIn);
            min = GetInputValue(nameof(min), min);
            max = GetInputValue(nameof(max), max);

            return Mathf.Clamp(floatIn, min, max);
        }
    }
}