﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Advanced/Max Float")]
    public class MaxFloat : AFXNode
    {
        [SerializeField]
        [Input] private float a;
        [SerializeField]
        [Input] private float b;

        [SerializeField]
        [Output] private float floatOut;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);

            return Mathf.Max(a, b);
        }
    }
}