﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Conversion/Bool To Float")]
    public class BoolToFloat : AFXNode
    {
        [SerializeField]
        [Input] private bool boolIn;
        [Header("float output if false")]
        [SerializeField]
        [Input] private float falseValueIn = 0;
        [Header("float output if true")]
        [SerializeField]
        [Input] private float trueValueIn = 1;

        [SerializeField]
        [Output] private float floatOut;

        public override object GetValue(NodePort port)
        {
            boolIn = GetInputValue(nameof(boolIn), boolIn);
            if (boolIn)
            {
                trueValueIn = GetInputValue(nameof(trueValueIn), trueValueIn);
                return trueValueIn;
            }
            else
            {
                falseValueIn = GetInputValue(nameof(falseValueIn), falseValueIn);
                return falseValueIn;
            }
        }
    }
}