﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Conversion/Int To Float")]
    public class IntToFloat : AFXNode
    {
        [SerializeField]
        [Input] private int intIn;

        [SerializeField]
        [Output] private float floatOut;

        public override object GetValue(NodePort port)
        {
            intIn = GetInputValue(nameof(intIn), intIn);
            return (float)intIn;
        }
    }
}