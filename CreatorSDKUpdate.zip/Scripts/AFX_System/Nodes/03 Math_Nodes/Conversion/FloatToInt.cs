﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Math/Conversion/Float To Int")]
    public class FloatToInt : AFXNode
    {
        [SerializeField]
        [Input] private float floatIn;

        [SerializeField]
        [Output] private int intOut;

        public override object GetValue(NodePort port)
        {
            floatIn = GetInputValue(nameof(floatIn), floatIn);

            return (int)floatIn;
        }
    }
}