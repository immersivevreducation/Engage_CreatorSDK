﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Create/Random/Float")]
    public class RandomFloat : AFXActiveNode
    {
        [SerializeField]
        [Input] private float min;
        [SerializeField]
        [Input] private float max;

        [SerializeField]
        [Output(ShowBackingValue.Always)] private float floatOut = 0;

        public override object GetValue(NodePort port)
        {
            return floatOut;
        }

        void GenerateRandomValue()
        {
            min = GetInputValue(nameof(min), min);
            max = GetInputValue(nameof(max), max);
            floatOut = Random.Range(min, max);
        }

        protected override void ExecuteNode()
        {
            GenerateRandomValue();
        }
    }
}