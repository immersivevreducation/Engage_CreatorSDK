﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Invert/Invert Float")]
    public class InvertFloat : AFXNode
    {
        [SerializeField]
        [Input] private float a = 1f;

        [SerializeField]
        [Output] private float output;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            return a * -1f;
        }
    }
}