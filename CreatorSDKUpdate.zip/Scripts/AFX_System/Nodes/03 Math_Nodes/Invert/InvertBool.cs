﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Math/Invert/Invert Bool")]
    public class InvertBool : AFXNode
    {
        [SerializeField]
        [Input] private bool boolIn = false;

        [SerializeField]
        [Output] private bool boolOut = false;

        public override object GetValue(NodePort port)
        {
            boolIn = GetInputValue(nameof(boolIn), boolIn);
            if (boolIn)
            {
                return false;
            }
            return true;
        }
    }
}