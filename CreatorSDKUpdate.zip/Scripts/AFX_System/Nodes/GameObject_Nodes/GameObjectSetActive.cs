﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("GameObject/Set Active")]
    public class GameObjectSetActive : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private GameObject gameObjectIn;
        [SerializeField]
        [Input] private bool setActive = false;

        void SetGOActive()
        {
            gameObjectIn = GetInputValue(nameof(gameObjectIn), gameObjectIn);
            setActive = GetInputValue(nameof(setActive), setActive);

            gameObjectIn.SetActive(setActive);
        }

        protected override void ExecuteNode()
        {
            SetGOActive();
        }
    }
}
