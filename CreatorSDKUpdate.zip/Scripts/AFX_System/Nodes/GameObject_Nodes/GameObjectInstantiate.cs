﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("GameObject/Instantiate")]
    public class GameObjectInstantiate : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private GameObject gameObjectIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform parentIn;
        [SerializeField]
        [Input] private int maximumObjectCountIn;
        [SerializeField]
        [Input] private Vector3 spawnPositionIn;
        [SerializeField]
        [Input] private Quaternion spawnRotationIn;

        [SerializeField]
        [Output] private GameObject[] objectPool;

        private int placeInPool = 0;

        protected override void Init()
        {
            base.Init();
            objectPool = new GameObject[maximumObjectCountIn];
        }

        public override object GetValue(NodePort port)
        {
            return objectPool;
        }

        void SpawnGO()
        {
            if (objectPool.Length != maximumObjectCountIn)
            {
                objectPool = new GameObject[maximumObjectCountIn];
            }
            gameObjectIn = GetInputValue(nameof(gameObjectIn), gameObjectIn);
            parentIn = GetInputValue(nameof(parentIn), parentIn);
            spawnPositionIn = GetInputValue(nameof(spawnPositionIn), spawnPositionIn);
            spawnRotationIn = GetInputValue(nameof(spawnRotationIn), spawnRotationIn);

            if (objectPool[placeInPool] == null)
            {
                GameObject createdObj = Instantiate(gameObjectIn, spawnPositionIn, spawnRotationIn);
                createdObj.name = "objectPool " + placeInPool.ToString();
                if (GetInputPort(nameof(parentIn)).IsConnected)
                {
                    createdObj.transform.SetParent(parentIn);
                }
                else
                {
                    createdObj.transform.SetParent(gameObjectIn.transform);
                }
                objectPool[placeInPool] = createdObj;
                placeInPool++;
                if (placeInPool > objectPool.Length - 1)
                {
                    placeInPool = 0;
                }
            }
            else
            {
                GameObject objectInPool = GetInputValue("objectPool " + placeInPool.ToString(), objectPool[placeInPool]);
                objectInPool.SetActive(true);
                objectInPool.transform.position = spawnPositionIn;
                objectInPool.transform.rotation = spawnRotationIn;
                placeInPool++;
                if (placeInPool > objectPool.Length - 1)
                {
                    placeInPool = 0;
                }
            }
        }

        protected override void ExecuteNode()
        {
            SpawnGO();
        }
    }
}
