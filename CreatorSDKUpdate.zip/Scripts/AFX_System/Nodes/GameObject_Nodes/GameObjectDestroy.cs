﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("GameObject/Destroy")]
    public class GameObjectDestroy : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private GameObject gameObjectIn;

        void DestroyGO()
        {
            gameObjectIn = GetInputValue(nameof(gameObjectIn), gameObjectIn);
            Destroy(gameObjectIn);
        }

        protected override void ExecuteNode()
        {
            DestroyGO();
        }
    }
}
