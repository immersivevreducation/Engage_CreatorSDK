﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Input/Get Button")]
    public class GetButton : AFXNode
    {
        [SerializeField]
        [Input] private string buttonName;

        [SerializeField]
        [Output] private bool boolOut = false;

        public override object GetValue(NodePort port)
        {
            buttonName = GetInputValue(nameof(buttonName), buttonName);
            return Input.GetButton(buttonName);
        }
    }
}