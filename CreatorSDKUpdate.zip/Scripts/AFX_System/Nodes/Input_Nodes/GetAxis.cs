﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Input/Get Axis")]
    public class GetAxis : AFXNode
    {
        [SerializeField]
        [Input] private string axisName;

        [SerializeField]
        [Output] private float floatOut;

        public override object GetValue(NodePort port)
        {
            axisName = GetInputValue(nameof(axisName), axisName);

            return Input.GetAxis(axisName);
        }
    }
}