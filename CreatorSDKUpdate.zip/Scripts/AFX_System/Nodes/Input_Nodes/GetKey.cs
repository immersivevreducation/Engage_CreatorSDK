﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Input/Get Key")]
    public class GetKey : AFXNode
    {
        [SerializeField]
        [Input] private string keyName;

        [SerializeField]
        [Output] private bool boolOut = false;

        public override object GetValue(NodePort port)
        {
            keyName = GetInputValue(nameof(keyName), keyName);
            return Input.GetKey(keyName);
        }
    }
}