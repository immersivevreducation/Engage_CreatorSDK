﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Physics/Special/Wheel Collider")]
    public class WheelCollider : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private UnityEngine.WheelCollider wheelColliderIn;
        [SerializeField]
        [Input] private float steerAngleIn;
        [SerializeField]
        [Input] private float motorTorqueIn;
        [SerializeField]
        [Input] private float brakeTorqueIn;

        [SerializeField]
        [Output] private float rpmOut;
        [SerializeField]
        [Output] private bool isGroudedOut;
        [SerializeField]
        [Output] private Vector3 colliderPosition;
        [SerializeField]
        [Output] private Quaternion colliderRotation;

        public override object GetValue(NodePort port)
        {
            wheelColliderIn = GetInputValue(nameof(wheelColliderIn), wheelColliderIn);
            if (port.fieldName == nameof(rpmOut))
            {
                return wheelColliderIn.rpm;
            }
            if (port.fieldName == nameof(isGroudedOut))
            {
                return wheelColliderIn.isGrounded;
            }
            if (port.fieldName == nameof(colliderPosition))
            {
                return colliderPosition;
            }
            if (port.fieldName == nameof(colliderRotation))
            {
                return colliderRotation;
            }
            return null;
        }

        void ApplyWheelSettings()
        {
            wheelColliderIn = GetInputValue(nameof(wheelColliderIn), wheelColliderIn);
            steerAngleIn = GetInputValue(nameof(steerAngleIn), steerAngleIn);
            motorTorqueIn = GetInputValue(nameof(motorTorqueIn), motorTorqueIn);
            brakeTorqueIn = GetInputValue(nameof(brakeTorqueIn), brakeTorqueIn);

            wheelColliderIn.steerAngle = steerAngleIn;
            wheelColliderIn.motorTorque = motorTorqueIn;
            wheelColliderIn.brakeTorque = brakeTorqueIn;
            wheelColliderIn.GetWorldPose(out colliderPosition, out colliderRotation);
        }

        protected override void ExecuteNode()
        {
            ApplyWheelSettings();
        }
    }
}
