﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Move Rigidbody Position")]
    public class MovePosition : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] private Vector3 vector3In;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        void MoveRBPosition()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            vector3In = GetInputValue(nameof(vector3In), vector3In);

            rigidbodyIn.MovePosition(vector3In);
        }

        protected override void ExecuteNode()
        {
            MoveRBPosition();
        }
    }
}
