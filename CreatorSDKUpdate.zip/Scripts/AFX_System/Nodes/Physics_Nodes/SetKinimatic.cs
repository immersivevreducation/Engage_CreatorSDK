﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Set Kinimatic")]
    public class SetKinimatic : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] private bool kinimaticIn;

        void SetKinimaticSettings()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            kinimaticIn = GetInputValue(nameof(kinimaticIn), kinimaticIn);

            rigidbodyIn.isKinematic = kinimaticIn;
        }

        protected override void ExecuteNode()
        {
            SetKinimaticSettings();
        }
    }
}
