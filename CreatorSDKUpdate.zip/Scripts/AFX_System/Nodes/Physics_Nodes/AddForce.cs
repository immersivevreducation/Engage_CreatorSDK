﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Add Force")]
    public class AddForce : AFXActiveNode
    {
        [SerializeField]
        public ForceMode forceMode;

        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] public bool worldSpace = false;
        [SerializeField]
        [Input] private Vector3 forceIn;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        void ApplyForce()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            worldSpace = GetInputValue(nameof(worldSpace), worldSpace);
            forceIn = GetInputValue(nameof(forceIn), forceIn);
            if (worldSpace)
            {
                rigidbodyIn.AddForce(forceIn, forceMode);
            }
            else
            {
                rigidbodyIn.AddRelativeForce(forceIn, forceMode);
            }
        }

        protected override void ExecuteNode()
        {
            ApplyForce();
        }
    }
}
