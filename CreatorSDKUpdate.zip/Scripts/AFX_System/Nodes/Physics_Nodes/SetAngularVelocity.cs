using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Set Angular Velocity")]
    public class SetAngularVelocity : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] private Vector3 angularVelocityIn;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        void SetAngularVelocityOnRB()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            angularVelocityIn = GetInputValue(nameof(angularVelocityIn), angularVelocityIn);
            rigidbodyIn.angularVelocity = angularVelocityIn;
        }

        protected override void ExecuteNode()
        {
            SetAngularVelocityOnRB();
        }
    }
}
