﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Add Torque")]
    public class AddTorque : AFXActiveNode
    {

        [SerializeField]
        private ForceMode forceMode;        

        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] private bool worldSpace = false;
        [SerializeField]
        [Input] private Vector3 forceIn;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        void ApplyTorque()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            worldSpace = GetInputValue(nameof(worldSpace), worldSpace);
            forceIn = GetInputValue(nameof(forceIn), forceIn);
            if (worldSpace)
            {
                rigidbodyIn.AddTorque(forceIn, forceMode);
            }
            else
            {
                rigidbodyIn.AddRelativeTorque(forceIn, forceMode);
            }
        }

        protected override void ExecuteNode()
        {
            ApplyTorque();
        }
    }
}
