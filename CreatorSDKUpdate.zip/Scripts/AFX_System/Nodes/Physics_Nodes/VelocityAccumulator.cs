﻿using System.Collections.Generic;
using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Physics/Special/Accumulate Force")]
    public class VelocityAccumulator : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private bool clearQueue = false;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;
        [SerializeField]
        [Input] private int queueLength = 10;

        [SerializeField]
        [Output] private Vector3 velocityVector;
        [SerializeField]
        [Output] private Vector3 torqueVector;

        private Queue<Vector3> vectorsOverTime = new Queue<Vector3>();
        private Queue<Vector3> rotationOverTime = new Queue<Vector3>();
        private Vector3 lastPos;
        private Vector3 lastRot;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        public override object GetValue(NodePort port)
        {
            if (port.fieldName == nameof(velocityVector))
            {
                return velocityVector;
            }
            if (port.fieldName == nameof(torqueVector))
            {
                return torqueVector;
            }
            return null;
        }

        void AccumulateForce()
        {
            if (GetInputValue(nameof(clearQueue), clearQueue))
            {
                vectorsOverTime.Clear();
                rotationOverTime.Clear();
            }
            velocityVector = CalculateThrowVector();
            torqueVector = CalculateThrowRotation();
        }

        Vector3 CalculateThrowVector()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            queueLength = GetInputValue(nameof(queueLength), queueLength);
            Vector3 velocity = (transformIn.position - lastPos) / Time.deltaTime;
            vectorsOverTime.Enqueue(velocity);
            if (vectorsOverTime.Count > queueLength)
            {
                vectorsOverTime.Dequeue();
            }
            Vector3 sum = new Vector3();
            foreach (var item in vectorsOverTime)
            {
                sum += item;
            }
            lastPos = transformIn.position;
            return sum / vectorsOverTime.Count;
        }

        Vector3 CalculateThrowRotation()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            queueLength = GetInputValue(nameof(queueLength), queueLength);
            Vector3 velocity = (transformIn.eulerAngles - lastRot) / Time.deltaTime;
            rotationOverTime.Enqueue(velocity);
            if (rotationOverTime.Count > queueLength)
            {
                rotationOverTime.Dequeue();
            }
            Vector3 sum = new Vector3();
            foreach (var item in rotationOverTime)
            {
                sum += item;
            }
            lastRot = transformIn.localEulerAngles;
            return sum / rotationOverTime.Count;
        }

        protected override void ExecuteNode()
        {
            AccumulateForce();
        }
    }
}
