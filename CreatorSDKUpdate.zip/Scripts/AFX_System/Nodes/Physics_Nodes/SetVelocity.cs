using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Set Velocity")]
    public class SetVelocity : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] private Vector3 velocityIn;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        void SetVelocityOnRB()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            velocityIn = GetInputValue(nameof(velocityIn), velocityIn);

            rigidbodyIn.velocity = velocityIn;
        }

        protected override void ExecuteNode()
        {
            SetVelocityOnRB();
        }
    }
}
