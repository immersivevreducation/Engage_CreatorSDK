﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Physics/Rigidbody/Move Rigidbody Rotation")]
    public class MoveRotation : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Rigidbody rigidbodyIn;
        [SerializeField]
        [Input] private Quaternion quaternionIn;

        private void Awake()
        {
            updateMode = UpdateMode.FixedUpdate;
        }

        void MoveRBRotation()
        {
            rigidbodyIn = GetInputValue(nameof(rigidbodyIn), rigidbodyIn);
            quaternionIn = GetInputValue(nameof(quaternionIn), quaternionIn);

            rigidbodyIn.MoveRotation(quaternionIn);
        }

        protected override void ExecuteNode()
        {
            MoveRBRotation();
        }
    }
}
