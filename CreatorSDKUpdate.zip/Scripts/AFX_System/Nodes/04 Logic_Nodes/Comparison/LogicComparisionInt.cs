﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Logic/Comparision/Int")]
    public class LogicComparisionInt : AFXNode
    {
        public enum AFXGreaterThanLessThanChoice
        {
            greaterThan,
            lessThan,
            greaterThanEqual,
            lessThanEqual,
            Equal,
            NotEqual
        }

        [SerializeField]
        private AFXGreaterThanLessThanChoice pick;
        [SerializeField]
        [Input] private int a;
        [SerializeField]
        [Input] private int b;
        [SerializeField]
        [Output] private bool boolOut = false;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);

            switch (pick)
            {
                case AFXGreaterThanLessThanChoice.greaterThan:
                    if (a > b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.lessThan:
                    if (a < b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.greaterThanEqual:
                    if (a >= b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.lessThanEqual:
                    if (a <= b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.Equal:
                    if (a == b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.NotEqual:
                    if (a != b)
                    {
                        return true;
                    }
                    break;
                default:
                    return false;
            }
            return false;
        }
    }
}