﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Logic/Comparision/Float")]
    public class LogicComparisionFloat : AFXNode
    {
        public enum AFXGreaterThanLessThanChoice
        {
            greaterThan,
            lessThan,
            greaterThanEqual,
            lessThanEqual,
            Equal,
            NotEqual
        }

        [SerializeField]
        private AFXGreaterThanLessThanChoice pick;
        [SerializeField]
        [Input] private float a;
        [SerializeField]
        [Input] private float b;
        [SerializeField]
        [Output] private bool boolOut = false;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);

            switch (pick)
            {
                case AFXGreaterThanLessThanChoice.greaterThan:
                    if (a > b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.lessThan:
                    if (a < b)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.greaterThanEqual:
                    if (a >= b - Mathf.Epsilon)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.lessThanEqual:
                    if (a <= b + Mathf.Epsilon)
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.Equal:
                    if (Mathf.Approximately(a, b))
                    {
                        return true;
                    }
                    break;
                case AFXGreaterThanLessThanChoice.NotEqual:
                    if (!Mathf.Approximately(a, b))
                    {
                        return true;
                    }
                    break;
                default:
                    return false;
            }
            return false;
        }
    }
}