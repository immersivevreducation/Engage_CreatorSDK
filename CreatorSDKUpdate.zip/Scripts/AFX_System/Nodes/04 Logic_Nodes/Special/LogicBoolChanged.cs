﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Logic/Special/If value Changed/If Bool Changed")]
    public class LogicBoolChanged : AFXNode
    {
        [SerializeField]
        [Input] private bool valueIn;

        [SerializeField]
        [Output] private bool boolOut = false;

        private bool oldValue;

        protected override void Init()
        {
            base.Init();
            valueIn = GetInputValue(nameof(valueIn), valueIn);
            oldValue = valueIn;
        }

        public override object GetValue(NodePort port)
        {
            valueIn = GetInputValue(nameof(valueIn), valueIn);

            if (oldValue != valueIn)
            {
                oldValue = valueIn;
                return true;
            }
            return false;
        }
    }
}