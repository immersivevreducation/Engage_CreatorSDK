﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Logic/Special/Count Down Timer")]
    public class LogicCountDownTimer : AFXActiveNode
    {
        [SerializeField]
        [Input] private float timer = 1f;
        [SerializeField]
        [Input] private bool restart = true;

        [SerializeField]
        [Output] private float timeRemaining;
        [SerializeField]
        [Output] private bool boolOut = false;

        protected override void Init()
        {
            base.Init();
            timer = GetInputValue(nameof(timer), timer);
            timeRemaining = timer;
        }

        void CountDownTimer()
        {
            restart = GetInputValue(nameof(restart), restart);
            if (boolOut == true && restart)
            {
                boolOut = false;
                timer = GetInputValue(nameof(timer), timer); ;
                timeRemaining = timer;
                return;
            }
            timeRemaining -= Time.deltaTime;
            if (timeRemaining <= 0)
            {
                boolOut = true;
            }
        }

        // Return the correct value of an output port when requested
        public override object GetValue(NodePort port)
        {
            if (port.fieldName == nameof(timeRemaining))
            {
                return timeRemaining;
            }
            if (port.fieldName == nameof(boolOut))
            {
                return boolOut;
            }
            return null;
        }

        protected override void ExecuteNode()
        {
            CountDownTimer();
        }
    }
}