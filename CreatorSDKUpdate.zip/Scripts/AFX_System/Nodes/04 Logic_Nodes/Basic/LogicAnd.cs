﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Logic/Basic/AND")]
    public class LogicAnd : AFXNode
    {
        [SerializeField]
        [Input] private bool a = false;
        [SerializeField]
        [Input] private bool b = false;

        [SerializeField]
        [Output] private bool boolOut = false;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);

            if (a && b)
            {
                return true;
            }
            return false;
        }
    }
}