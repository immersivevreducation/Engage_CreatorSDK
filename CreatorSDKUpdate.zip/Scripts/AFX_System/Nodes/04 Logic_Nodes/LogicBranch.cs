﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Logic/Branch")]
    public class LogicBranch : AFXNode
    {
        [SerializeField]
        [Input] private bool boolIn = false;

        [SerializeField]
        [Output(ShowBackingValue.Never)] private bool ifTrue = false;
        [SerializeField]
        [Output(ShowBackingValue.Never)] private bool ifFalse = false;

        public override object GetValue(NodePort port)
        {
            boolIn = GetInputValue(nameof(boolIn), boolIn);
            if (port.fieldName == nameof(ifTrue))
            {
                if (boolIn)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            if (port.fieldName == nameof(ifFalse))
            {
                if (!boolIn)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            return null;
        }
    }
}