using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Collision/Approxomite")]
    public class CollisionApproxomite : AFXNode
    {
        [SerializeField]
        [Input] private Collider colliderA;
        [SerializeField]
        [Input] private Collider colliderB;

        [SerializeField]
        [Output] private bool boolOut;

        public override object GetValue(NodePort port)
        {
            colliderA = GetInputValue(nameof(colliderA), colliderA);
            colliderB = GetInputValue(nameof(colliderB), colliderB);
            return AFXColliders.ColliderContainsCollider(colliderA, colliderB);
        }
    }
}
