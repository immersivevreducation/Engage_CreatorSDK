using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Collision/Contains Point")]
    public class ColliderContainsPoint : AFXNode
    {
        [SerializeField]
        [Input] private Collider colliderIn;
        [SerializeField]
        [Input] private Vector3 vector3In;

        [SerializeField]
        [Output] private bool boolOut;

        public override object GetValue(NodePort port)
        {
            colliderIn = GetInputValue(nameof(colliderIn), colliderIn);
            vector3In = GetInputValue(nameof(vector3In), vector3In);
            return AFXColliders.ColliderContainsPoint(colliderIn, vector3In);
        }       
    }
}
