using System;
using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Collision/Bounds")]
    [Serializable]
    public class CollisionBounds : AFXNode
    {
        [SerializeField]
        [Input] private Collider colliderA;
        [SerializeField]
        [Input] private Collider colliderB;

        [SerializeField]
        [Output] private bool boolOut;

        public override object GetValue(NodePort port)
        {
            colliderA = GetInputValue(nameof(colliderA), colliderA);
            colliderB = GetInputValue(nameof(colliderB), colliderB);
            return GetCollisionBounds(colliderA, colliderB);
        }


        private static bool GetCollisionBounds(Collider colliderA, Collider colliderB)
        {
            if (colliderB.bounds.Intersects(colliderA.bounds))
            {
                return true;
            }
            return false;
        }
    }
}
