﻿using UnityEngine;
using UnityEngine.Events;

namespace AFX
{
    [CreateNodeMenu("Event/UnityEvent")]
    public class UnityEventInvoke : AFXActiveNode
    {
        [SerializeField]
        [Input] private UnityEvent unityEventIn;

        void InvokeEvent()
        {
            unityEventIn = GetInputValue(nameof(unityEventIn), unityEventIn);
            unityEventIn.Invoke();
        }

        protected override void ExecuteNode()
        {
            InvokeEvent();
        }
    }
}
