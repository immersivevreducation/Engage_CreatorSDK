﻿using XNode;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Engage/Networking/Photon Network Info")]
    public class PhotonNetworkInfo : AFXNode
    {
        [SerializeField]
        [Output] private bool isMasterClient;
        [SerializeField]
        [Output] private int playerCount;
        [SerializeField]
        [Output] private float networkTime;
        [SerializeField]
        [Output] private int localPlayerId;
        [SerializeField]
        [Output] private int masterClientId;

        public override object GetValue(NodePort port)
        {
            return null;
        }
    }
}
