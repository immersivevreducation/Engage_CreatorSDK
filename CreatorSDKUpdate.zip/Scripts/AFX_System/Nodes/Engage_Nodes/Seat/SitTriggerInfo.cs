﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Seat/Sit Trigger")]
    public class SitTriggerInfo : AFXNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private LVR_SitTrigger sitTriggerIn;

        [SerializeField]
        [Output] private bool playerInSeatOut;



        public override object GetValue(NodePort port)
        {
            return false;
        }
    }
}
