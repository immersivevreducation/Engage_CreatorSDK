﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Grab System/Secondary GrabPoint Settings")]
    public class GrabObjectSecondarySettings : AFXActiveNode
    {
        [SerializeField]
        [Input] private GrabObjectSecondaryGrabPoint secondaryGrabPointIn;
        [SerializeField]
        [Input] private GrabObject primaryGrabObjectIn;
        [SerializeField]
        [Input] private Transform restTransformIn;

        [SerializeField]
        [Output] private GrabObject primaryGrabObjectOut;

        public override object GetValue(NodePort port)
        {
            secondaryGrabPointIn = GetInputValue(nameof(secondaryGrabPointIn), secondaryGrabPointIn);
            primaryGrabObjectOut = secondaryGrabPointIn.primaryGrabObject;
            return primaryGrabObjectOut;
        }

        void UpdateGrabedObjectSettings()
        {
            if (GetInputPort(nameof(secondaryGrabPointIn)).IsConnected)
            {
                secondaryGrabPointIn = GetInputValue(nameof(secondaryGrabPointIn), secondaryGrabPointIn);
                
                if (GetInputPort(nameof(primaryGrabObjectIn)).IsConnected)
                {
                    primaryGrabObjectIn = GetInputValue(nameof(primaryGrabObjectIn), primaryGrabObjectIn);
                    secondaryGrabPointIn.primaryGrabObject = primaryGrabObjectIn;
                }
            }
        }

        protected override void ExecuteNode()
        {
            UpdateGrabedObjectSettings();
        }
    }
}