﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Grab System/GrabObject Settings")]
    public class GrabObjectSettings : AFXActiveNode
    {
        [SerializeField]
        [Input] private GrabObject grabObjectIn;
        [SerializeField]
        [Input] private Collider colliderToGrabIn;
        [SerializeField]
        [Input] private bool maintainOffsetIn;
        [SerializeField]
        [Input] private bool requireTriggerPressIn;
        [SerializeField]
        [Input] private bool requireGrippedPressIn;
        [SerializeField]
        [Input] private float maxMouseDistanceIn;

        [SerializeField]
        [Output] private Collider colliderToGrabOut;
        [SerializeField]
        [Output] private bool isGrabbedOut;
        [SerializeField]
        [Output] private bool maintainOffsetOut;
        [SerializeField]
        [Output] private bool requireTriggerPressOut;
        [SerializeField]
        [Output] private bool requireGrippedPressOut;
        [SerializeField]
        [Output] private float maxMouseDistanceOut;

        public override object GetValue(NodePort port)
        {
            grabObjectIn = GetInputValue(nameof(grabObjectIn), grabObjectIn);
            if (port.fieldName == nameof(colliderToGrabOut))
            {
                colliderToGrabOut = grabObjectIn.colliderToGrab;
                return colliderToGrabOut;
            }

            if (port.fieldName == nameof(isGrabbedOut))
            {
                if (grabObjectIn.HolderObject != null)
                {
                    isGrabbedOut = grabObjectIn.HolderObject.currentlyGrabbed;
                    return isGrabbedOut;
                }
            }

            if (port.fieldName == nameof(maintainOffsetOut))
            {
                maintainOffsetOut = grabObjectIn.maintainOffset;
                return maintainOffsetOut;
            }

            if (port.fieldName == nameof(requireTriggerPressOut))
            {
                requireTriggerPressOut = grabObjectIn.requireTriggerPress;
                return requireTriggerPressOut;
            }

            if (port.fieldName == nameof(requireGrippedPressOut))
            {
                requireGrippedPressOut = grabObjectIn.requireGrippedPress;
                return requireGrippedPressOut;
            }

            return null;
        }

        void UpdateGrabedObjectSettings()
        {
            if (GetInputPort(nameof(grabObjectIn)).IsConnected)
            {
                grabObjectIn = GetInputValue(nameof(grabObjectIn), grabObjectIn);

                colliderToGrabIn = GetInputValue(nameof(colliderToGrabIn), colliderToGrabIn);
                grabObjectIn.colliderToGrab = colliderToGrabIn;

                maintainOffsetIn = GetInputValue(nameof(maintainOffsetIn), maintainOffsetIn);
                grabObjectIn.maintainOffset = maintainOffsetIn;

                requireTriggerPressOut = GetInputValue(nameof(requireTriggerPressOut), requireTriggerPressOut);
                grabObjectIn.requireTriggerPress = requireTriggerPressOut;

                requireGrippedPressOut = GetInputValue(nameof(requireGrippedPressOut), requireGrippedPressOut);
                grabObjectIn.requireGrippedPress = requireGrippedPressOut;

                maxMouseDistanceOut = GetInputValue(nameof(maxMouseDistanceOut), maxMouseDistanceOut);
                grabObjectIn.maxMouseDistance = maxMouseDistanceOut;
            }
        }

        protected override void ExecuteNode()
        {
            UpdateGrabedObjectSettings();
        }
    }
}