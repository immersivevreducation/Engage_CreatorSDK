﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Grab System/Is Grabbed")]
    public class GrabObjectIsGrabbed: AFXNode
    {
        [SerializeField]
        [Input] private GrabObject grabObjectIn;

        [SerializeField]
        [Output] private bool isGrabbedOut;

        public override object GetValue(NodePort port)
        {
            grabObjectIn = GetInputValue(nameof(grabObjectIn), grabObjectIn);
            if (grabObjectIn.HolderObject != null)
            {
                isGrabbedOut = grabObjectIn.HolderObject.currentlyGrabbed;
                return isGrabbedOut;
            }
            return false;
        }
    }
}