﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Grab System/GrabObject Mover Settings")]
    public class GrabObjectMoverSettings : AFXActiveNode
    {
        [SerializeField]
        [Input] private GrabObjectMover grabObjectMoverIn;
        [SerializeField]
        [Input] private bool movableIn;
        [SerializeField]
        [Input] private bool rotatableIn;

        [SerializeField]
        [Output] private bool movableOut;
        [SerializeField]
        [Output] private bool rotatableOut;

        public override object GetValue(NodePort port)
        {
            grabObjectMoverIn = GetInputValue(nameof(grabObjectMoverIn), grabObjectMoverIn);
            if (port.fieldName == nameof(movableIn))
            {
                movableIn = grabObjectMoverIn.movable;
                return movableIn;
            }

            if (port.fieldName == nameof(rotatableIn))
            {
                rotatableIn = grabObjectMoverIn.rotatable;
                return rotatableIn;
            }
            return null;
        }

        void UpdateGrabedObjectSettings()
        {
            if (GetInputPort(nameof(grabObjectMoverIn)).IsConnected)
            {
                grabObjectMoverIn = GetInputValue(nameof(grabObjectMoverIn), grabObjectMoverIn);
                movableIn = GetInputValue(nameof(movableIn), movableIn);
                rotatableIn = GetInputValue(nameof(rotatableIn), rotatableIn);

                grabObjectMoverIn.movable = movableIn;
                grabObjectMoverIn.rotatable = rotatableIn;
            }
        }

        protected override void ExecuteNode()
        {
            UpdateGrabedObjectSettings();
        }
    }
}