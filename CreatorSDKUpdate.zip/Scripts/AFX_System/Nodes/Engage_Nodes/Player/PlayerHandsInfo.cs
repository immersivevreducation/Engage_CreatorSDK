﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Player/Hands")]
    public class PlayerHandsInfo : AFXNode
    {
        [SerializeField]
        [Output] private Transform primaryHandTransformOut;
        [SerializeField]
        [Output] private Transform secondaryHandTransformOut;
        [SerializeField]
        [Output] private bool grippedPrimaryOut;
        [SerializeField]
        [Output] private bool grippedSecondaryOut;
        [SerializeField]
        [Output] private bool triggerPrimaryOut;
        [SerializeField]
        [Output] private bool triggerSecondaryOut;

        public override object GetValue(NodePort port)
        {            
            return null;
        }
    }
}
