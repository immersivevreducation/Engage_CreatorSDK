﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Player/Info")]
    public class PlayerInfo : AFXNode
    {        
        [SerializeField]
        [Output(ShowBackingValue.Never)] private GameObject playerGameObjectOut;
        [SerializeField]
        [Output] private string displayNameOut;
        [SerializeField]
        [Output] private bool isVROut;
        [SerializeField]
        [Output] private bool IsAndroidOut;
        [SerializeField]
        [Output] private bool IsDesktopOut;
        [SerializeField]
        [Output] private bool IsHeadset6dofOut;
        [SerializeField]
        [Output] private bool IsIOSOut;
        [SerializeField]
        [Output] private bool IsMacOut;
        [SerializeField]
        [Output] private bool IsPhoneOut;
        [SerializeField]
        [Output] private bool IsWindowsOut;
        [SerializeField]
        [Output] private string DeviceNameOut;
        [SerializeField]
        [Output] private bool isSessionHost;
        [SerializeField]
        [Output] private int id; 

        public override object GetValue(NodePort port)
        {            
            return null;
        }     
    }
}
