﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Player/Body")]
    public class PlayerBodyInfo : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Never)] private GameObject playerGameObjectOut;
        [SerializeField]
        [Output] private Transform playerTransformOut;
        [SerializeField]
        [Output] private Collider playerColliderOut;

        public override object GetValue(NodePort port)
        {
            return null;
        }
    }
}
