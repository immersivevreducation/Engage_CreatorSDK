﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Engage/Player/Camera")]
    public class PlayerCameraInfo : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Never)] private Camera playerCameraOut;
        [SerializeField]
        [Output] private Transform transformOut;

        public override object GetValue(NodePort port)
        {            
            return null;
        }
    }
}
