﻿using UnityEngine;
using Engage.IFX.NetworkStates;

namespace AFX
{
    [CreateNodeMenu("Networking/NetworkStateModules/Take Ownership")]
    public class TakeNetworkStateOwnership : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private NetworkStateModule moduleIn;
        [Header("Unconnected=local player")]
        [SerializeField]
        [Input(ShowBackingValue.Never)] private int playerIDIn;

        void SetOwnership()
        {
            moduleIn = GetInputValue(nameof(moduleIn), moduleIn);
            if (GetInputPort(nameof(playerIDIn)).IsConnected)
            {
                playerIDIn = GetInputValue(nameof(playerIDIn), playerIDIn);
                moduleIn.SetFixedOwnership(playerIDIn);
            }
            else
            {
                moduleIn.SetFixedOwnerMe();
            }
        }

        protected override void ExecuteNode()
        {
            SetOwnership();
        }
    }
}
