﻿using UnityEngine;
using Engage.IFX.NetworkStates;

namespace AFX
{
    [CreateNodeMenu("Networking/NetworkStateModules/Release Ownership")]
    public class ReleaseNetworkStateOwnership : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private NetworkStateModule moduleIn;

        void ReleaseOwnership()
        {
            moduleIn = GetInputValue(nameof(moduleIn), moduleIn);
            moduleIn.ReleaseFixedOwnership();
        }

        protected override void ExecuteNode()
        {
            ReleaseOwnership();
        }
    }
}
