﻿using UnityEngine;
using XNode;
using Engage.IFX.NetworkStates;

namespace AFX
{
    [CreateNodeMenu("Networking/NetworkStateModules/Read Ownership")]
    public class ReadNetworkStateOwnership : AFXNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private NetworkStateModule moduleIn;
        [SerializeField]
        [Input] private int playerIDIn;

        [SerializeField]
        [Output] private bool playerIsOwnerOut;
        [SerializeField]
        [Output] private bool playerCanControlOut;

        public override object GetValue(NodePort port)
        {
            return null;
        }     
    }
}
