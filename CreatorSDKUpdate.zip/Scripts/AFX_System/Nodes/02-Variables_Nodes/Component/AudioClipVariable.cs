﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Variables/Component/AudioClip")]
    public class AudioClipVariable : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Always)] private AudioClip audioClipOut;

        public override object GetValue(NodePort port)
        {
            return audioClipOut;
        }
    }
}