﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Variables/Component/Color")]
    public class ColorVariable : AFXNode
    {
        [SerializeField]
        [Input] private Color colorIn;
        [SerializeField]
        [Input] private float rIn;
        [SerializeField]
        [Input] private float gIn;
        [SerializeField]
        [Input] private float bIn;

        [SerializeField]
        [Output] private Color colorOut;
        [SerializeField]
        [Output] private float rOut;
        [SerializeField]
        [Output] private float gOut;
        [SerializeField]
        [Output] private float bOut;

        public override object GetValue(NodePort port)
        {
            if (GetInputPort(nameof(colorIn)).IsConnected)
            {
                colorIn = GetInputValue(nameof(colorIn), colorIn);
            }

            if (GetInputPort(nameof(rIn)).IsConnected)
            {
                colorIn.r = GetInputValue(nameof(rIn), rIn);
            }
            if (GetInputPort(nameof(gIn)).IsConnected)
            {
                colorIn.g = GetInputValue(nameof(gIn), gIn);
            }
            if (GetInputPort(nameof(bIn)).IsConnected)
            {
                colorIn.b = GetInputValue(nameof(bIn), bIn);
            }

            if (port.fieldName == nameof(colorIn))
            {
                return colorIn;
            }
            if (port.fieldName == nameof(rOut))
            {
                return colorIn.r;
            }
            if (port.fieldName == nameof(gOut))
            {
                return colorIn.g;
            }
            if (port.fieldName == nameof(bOut))
            {
                return colorIn.b;
            }
            return colorIn;
        }
    }
}