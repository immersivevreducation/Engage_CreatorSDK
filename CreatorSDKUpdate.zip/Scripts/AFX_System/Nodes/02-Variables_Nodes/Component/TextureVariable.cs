﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Variables/Component/Texture")]
    public class TextureVariable : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Always)] private Texture textureOut;

        public override object GetValue(NodePort port)
        {
            return textureOut;
        }
    }
}