﻿using System.Collections.Generic;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/GameObject/Functions/Remove GameObject")]
    public class ListRemoveGameObject : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private List<GameObject> listGOIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private GameObject toRemove;
        [SerializeField]
        [Input] private int removeAtIndex;

        void RemoveFromList()
        {
            listGOIn = GetInputValue(nameof(listGOIn), listGOIn);
            toRemove = GetInputValue(nameof(toRemove), toRemove);
            if (GetInputPort(nameof(toRemove)).IsConnected)
            {
                listGOIn.Remove(toRemove);
            }
            else
            {
                if (removeAtIndex < listGOIn.Count)
                {
                    listGOIn.RemoveAt(removeAtIndex);
                    error = null;
                }
                else
                {
                    error = $"[{this.name}] Index Out Of range: {removeAtIndex}";
                    Debug.LogError(error);
                }
            }
        }

        protected override void ExecuteNode()
        {
            RemoveFromList();
        }
    }
}
