﻿using System.Collections.Generic;
using UnityEngine;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/GameObject/Functions/Add GameObject")]
    public class ListAddGameObject : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private List<GameObject> listGOIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private GameObject toAdd;

        void AddToList()
        {
            listGOIn = GetInputValue(nameof(listGOIn), listGOIn);
            toAdd = GetInputValue(nameof(toAdd), toAdd);
            listGOIn.Add(toAdd);
        }

        protected override void ExecuteNode()
        {
            AddToList();
        }
    }
}
