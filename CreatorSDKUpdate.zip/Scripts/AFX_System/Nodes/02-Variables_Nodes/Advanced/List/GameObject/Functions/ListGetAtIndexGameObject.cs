﻿using System.Collections.Generic;
using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/GameObject/Functions/Get At Index")]
    public class ListGetAtIndexGameObject : AFXNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private List<GameObject> listGOIn;
        [SerializeField]
        [Input] private int index;
        [SerializeField]
        [Output(ShowBackingValue.Never)] private GameObject gameObjectOut;
        [SerializeField]
        [Output(ShowBackingValue.Never)] private bool isNull;

        public override object GetValue(NodePort port)
        {
            listGOIn = GetInputValue(nameof(listGOIn), listGOIn);
            index = GetInputValue(nameof(index), index);

            if (index > listGOIn.Count - 1)
            {
                return null;
            }

            if (port.fieldName == nameof(gameObjectOut))
            {
                if (listGOIn[index] != null)
                {
                    return listGOIn[index];
                }
            }

            if (port.fieldName == nameof(isNull))
            {
                if (listGOIn[index] != null)
                {
                    isNull = false;
                    return isNull;
                }
                else
                {
                    isNull = true;
                    return isNull;
                }
            }
            return null;
        }
    }
}
