﻿using System.Collections.Generic;
using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/Path/Path List")]
    public class ListPath : AFXNode
    {
        [SerializeField]
        [Input] private List<PathData> listIn = new List<PathData>();
        [SerializeField]
        [Output] private List<PathData> listOut = new List<PathData>();
        [SerializeField]
        [Output] private int count;

        List<NodePort> dynamicNodesInput = new List<NodePort>(); 
        List<NodePort> dynamicNodesOutput = new List<NodePort>(); 

        public override object GetValue(NodePort port)
        {
            listIn = GetInputValue(nameof(listIn), listIn);
            //check if there are too many input node ports for the size of the list and remove them
            if (dynamicNodesInput.Count != listIn.Count)
            {
                foreach (NodePort item in dynamicNodesInput)
                {
                    RemoveDynamicPort(item);
                }
                dynamicNodesInput.Clear();
                //dynamically add ports for list size
                for (int i = 0; i < listIn.Count; i++)
                {
                    dynamicNodesInput.Add(AddDynamicInput(typeof(PathData), fieldName: i.ToString() + "In"));
                }
            }
            
            //check if there are too many output node ports for the size of the list and remove them
            if (dynamicNodesOutput.Count != listIn.Count)
            {
                foreach (NodePort item in dynamicNodesOutput)
                {
                    RemoveDynamicPort(item);
                }
                dynamicNodesOutput.Clear();
                //dynamically add ports for list size
                for (int i = 0; i < listIn.Count; i++)
                {
                    dynamicNodesOutput.Add(AddDynamicOutput(typeof(PathData), fieldName: i.ToString() + "Out"));
                }
            }           

            // assign the count
            if (port.fieldName == nameof(count))
            {
                return listIn.Count;
            }

            //assign Inputs
            for (int i = 0; i < listIn.Count; i++)
            {
                listIn[i] = GetInputValue(i.ToString() + "In", listIn[i]);
            }

            //assign outputs
            for (int i = 0; i < listIn.Count; i++)
            {
                if (port.fieldName == i.ToString() + "Out")
                {
                    return GetInputValue(i.ToString() + "Out", listIn[i]);
                }
            }

            //assign listOut
            if (port.fieldName == nameof(listOut))
            {
                return GetInputValue(nameof(listIn), listIn);
            }
            return null;
        }
    }
}