﻿using System.Collections.Generic;
using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/Path/Functions/Get At Index")]
    public class ListGetAtIndexPath : AFXNode
    {       
        [SerializeField]
        [Input(ShowBackingValue.Never)] private List<PathData> listPathIn;
        [SerializeField]
        [Input] private int index;
        [SerializeField]
        [Output(ShowBackingValue.Never)] private PathData pathDataOut;
        [SerializeField]
        [Output(ShowBackingValue.Never)] private bool isNull;

        public override object GetValue(NodePort port)
        {
            listPathIn = GetInputValue(nameof(listPathIn), listPathIn);
            index = GetInputValue(nameof(index), index);

            if (index > listPathIn.Count -1)
            {
                return null;
            }

            if (port.fieldName == nameof(pathDataOut))
            {
                if (listPathIn[index] != null)
                {
                    return listPathIn[index];
                }                
            }

            if (port.fieldName == nameof(isNull))
            {               
                if (listPathIn[index] != null)
                { 
                    isNull = false;
                    return isNull;
                }
                else
                {
                    isNull = true;
                    return isNull;
                }               
            }
            return null;            
        }        
    }
}
