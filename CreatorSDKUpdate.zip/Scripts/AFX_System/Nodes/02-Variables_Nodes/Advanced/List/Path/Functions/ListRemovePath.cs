﻿using System.Collections.Generic;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/Path/Functions/Remove Path")]
    public class ListRemovePath : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private List<PathData> listPathIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private PathData toRemove;
        [SerializeField]
        [Input] private int removeAtIndex;

        void RemoveFromList()
        {
            listPathIn = GetInputValue(nameof(listPathIn), listPathIn);
            toRemove = GetInputValue(nameof(toRemove), toRemove);
            if (GetInputPort(nameof(toRemove)).IsConnected)
            {
                listPathIn.Remove(toRemove);
            }
            else
            {
                if (removeAtIndex < listPathIn.Count)
                {
                    listPathIn.RemoveAt(removeAtIndex);
                    error = null;
                }
                else
                {
                    error = $"[{this.name}] Index Out Of range: {removeAtIndex}";
                    Debug.LogError(error);
                }
            }
        }

        protected override void ExecuteNode()
        {
            RemoveFromList();
        }
    }
}
