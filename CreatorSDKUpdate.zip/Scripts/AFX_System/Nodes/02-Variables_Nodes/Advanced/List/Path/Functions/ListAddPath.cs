﻿using System.Collections.Generic;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/List/Path/Functions/Add Path")]
    public class ListAddPath : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private List<PathData> listPathIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private PathData toAdd;

        void AddToList()
        {
            listPathIn = GetInputValue(nameof(listPathIn), listPathIn);
            toAdd = GetInputValue(nameof(toAdd), toAdd);
            listPathIn.Add(toAdd);
        }

        protected override void ExecuteNode()
        {
            AddToList();
        }
    }
}
