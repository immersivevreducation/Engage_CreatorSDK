﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/Vector/Quaternion")]
    public class QuaternionVariable : AFXNode
    {
        [SerializeField]
        [Input] private Quaternion quaternionIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float xIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float yIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float zIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float wIn;

        [SerializeField]
        [Output] private Quaternion QuaternionOut;
        [SerializeField]
        [Output] private float xOut;
        [SerializeField]
        [Output] private float yOut;
        [SerializeField]
        [Output] private float zOut;
        [SerializeField]
        [Output] private float wOut;

        public override object GetValue(NodePort port)
        {
            quaternionIn = GetInputValue(nameof(quaternionIn), quaternionIn);

            if (GetInputPort(nameof(xIn)).IsConnected)
            {
                quaternionIn.x = GetInputValue(nameof(xIn), xIn);
            }
            if (GetInputPort(nameof(yIn)).IsConnected)
            {
                quaternionIn.y = GetInputValue(nameof(yIn), yIn);
            }
            if (GetInputPort(nameof(zIn)).IsConnected)
            {
                quaternionIn.z = GetInputValue(nameof(zIn), zIn);
            }
            if (GetInputPort(nameof(wIn)).IsConnected)
            {
                quaternionIn.w = GetInputValue(nameof(wIn), wIn);
            }

            if (port.fieldName == nameof(QuaternionOut))
            {
                return quaternionIn;
            }
            if (port.fieldName == nameof(xOut))
            {
                return quaternionIn.x;
            }
            if (port.fieldName == nameof(yOut))
            {
                return quaternionIn.y;
            }
            if (port.fieldName == nameof(zOut))
            {
                return quaternionIn.z;
            }
            if (port.fieldName == nameof(wOut))
            {
                return quaternionIn.w;
            }
            return null;
        }
    }
}