﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/Vector/Vector 3")]
    public class Vector3Variable : AFXNode
    {
        [SerializeField]
        [Input] private Vector3 vector3In;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float xIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float yIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float zIn;

        [SerializeField]
        [Output] private Vector3 vector3Out;
        [SerializeField]
        [Output] private float xOut;
        [SerializeField]
        [Output] private float yOut;
        [SerializeField]
        [Output] private float zOut;

        public override object GetValue(NodePort port)
        {
            vector3In = GetInputValue(nameof(vector3In), vector3In);

            if (GetInputPort(nameof(xIn)).IsConnected)
            {
                vector3In.x = GetInputValue(nameof(xIn), xIn);
            }
            if (GetInputPort(nameof(yIn)).IsConnected)
            {
                vector3In.y = GetInputValue(nameof(yIn), yIn);
            }
            if (GetInputPort(nameof(zIn)).IsConnected)
            {
                vector3In.z = GetInputValue(nameof(zIn), zIn);
            }

            if (port.fieldName == nameof(vector3Out))
            {
                return vector3In;
            }
            if (port.fieldName == nameof(xOut))
            {
                return vector3In.x;
            }
            if (port.fieldName == nameof(yOut))
            {
                return vector3In.y;
            }
            if (port.fieldName == nameof(zOut))
            {
                return vector3In.z;
            }
            return null;
        }
    }
}