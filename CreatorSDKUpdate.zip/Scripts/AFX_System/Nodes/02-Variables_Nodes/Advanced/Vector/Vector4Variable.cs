﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/Vector/Vector 4")]
    public class Vector4Variable : AFXNode
    {
        [SerializeField]
        [Input] private Vector4 vector4In;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float xIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float yIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float zIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float wIn;
        [SerializeField]
        [Output] private Vector4 vector4Out;
        [SerializeField]
        [Output] private float xOut;
        [SerializeField]
        [Output] private float yOut;
        [SerializeField]
        [Output] private float zOut;
        [SerializeField]
        [Output] private float wOut;

        public override object GetValue(NodePort port)
        {
            vector4In = GetInputValue(nameof(vector4In), vector4In);

            if (GetInputPort(nameof(xIn)).IsConnected)
            {
                vector4In.x = GetInputValue(nameof(xIn), xIn);
            }
            if (GetInputPort(nameof(yIn)).IsConnected)
            {
                vector4In.y = GetInputValue(nameof(yIn), yIn);
            }
            if (GetInputPort(nameof(zIn)).IsConnected)
            {
                vector4In.z = GetInputValue(nameof(zIn), zIn);
            }
            if (GetInputPort(nameof(wIn)).IsConnected)
            {
                vector4In.w = GetInputValue(nameof(wIn), wIn);
            }

            if (port.fieldName == nameof(vector4Out))
            {
                return vector4In;
            }
            if (port.fieldName == nameof(xOut))
            {
                return vector4In.x;
            }
            if (port.fieldName == nameof(yOut))
            {
                return vector4In.y;
            }
            if (port.fieldName == nameof(zOut))
            {
                return vector4In.z;
            }
            if (port.fieldName == nameof(wOut))
            {
                return vector4In.w;
            }
            return null;
        }
    }
}