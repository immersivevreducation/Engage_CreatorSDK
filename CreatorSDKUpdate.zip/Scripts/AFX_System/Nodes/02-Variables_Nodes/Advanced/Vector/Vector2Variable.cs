﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/Vector/Vector 2")]
    public class Vector2Variable : AFXNode
    {
        [SerializeField]
        [Input] private Vector2 vector2In;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float xIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float yIn;
        [SerializeField]
        [Output] private Vector2 vector2Out;
        [SerializeField]
        [Output] private float xOut;
        [SerializeField]
        [Output] private float yOut;

        public override object GetValue(NodePort port)
        {
            vector2In = GetInputValue(nameof(vector2In), vector2In);

            if (GetInputPort(nameof(xIn)).IsConnected)
            {
                vector2In.x = GetInputValue(nameof(xIn), xIn);
            }
            if (GetInputPort(nameof(yIn)).IsConnected)
            {
                vector2In.y = GetInputValue(nameof(yIn), yIn);
            }

            if (port.fieldName == nameof(vector2Out))
            {
                return vector2In;
            }
            if (port.fieldName == nameof(xOut))
            {
                return vector2In.x;
            }
            if (port.fieldName == nameof(yOut))
            {
                return vector2In.y;
            }
            return null;
        }
    }
}