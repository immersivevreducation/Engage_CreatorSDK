﻿using System.Collections.Generic;
using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Variables/Advanced/Array/GameObject")]
    public class ArrayGameObject : AFXNode
    {
        [SerializeField]
        [Input] private GameObject[] arrayIn;
        [SerializeField]
        [Output] private GameObject[] arrayOut;
        [SerializeField]
        [Output] private int length;

        List<NodePort> dynamicNodesInput = new List<NodePort>();
        List<NodePort> dynamicNodesOutput = new List<NodePort>();

        public override object GetValue(NodePort port)
        {
            arrayIn = GetInputValue(nameof(arrayIn), arrayIn);
            //check if there are too many input node ports for the size of the list and remove them
            if (dynamicNodesInput.Count != arrayIn.Length)
            {
                foreach (NodePort item in dynamicNodesInput)
                {
                    RemoveDynamicPort(item);
                }
                dynamicNodesInput.Clear();
                //dynamically add ports for list size
                for (int i = 0; i < arrayIn.Length; i++)
                {
                    dynamicNodesInput.Add(AddDynamicInput(typeof(GameObject), fieldName: i.ToString() + "In"));
                }
            }

            //check if there are too many output node ports for the size of the list and remove them
            if (dynamicNodesOutput.Count != arrayIn.Length)
            {
                foreach (NodePort item in dynamicNodesOutput)
                {
                    RemoveDynamicPort(item);
                }
                dynamicNodesOutput.Clear();
                //dynamically add ports for list size
                for (int i = 0; i < arrayIn.Length; i++)
                {
                    dynamicNodesOutput.Add(AddDynamicOutput(typeof(GameObject), fieldName: i.ToString() + "Out"));
                }
            }

            // assign the count
            if (port.fieldName == nameof(length))
            {
                return arrayIn.Length;
            }

            //assign Inputs
            for (int i = 0; i < arrayIn.Length; i++)
            {
                arrayIn[i] = GetInputValue(i.ToString() + "In", arrayIn[i]);
            }

            //assign outputs
            for (int i = 0; i < arrayIn.Length; i++)
            {
                if (port.fieldName == i.ToString() + "Out")
                {
                    return GetInputValue(i.ToString() + "Out", arrayIn[i]);
                }
            }

            //assign listOut
            if (port.fieldName == nameof(arrayIn))
            {
                return GetInputValue(nameof(arrayIn), arrayIn);
            }
            return null;
        }
    }
}