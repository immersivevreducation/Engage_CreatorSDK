﻿using XNode;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Basic/String")]
    public class StringVariable : AFXNode
    {
        [TextArea(10, 50)]
        [SerializeField]
        [Output(ShowBackingValue.Always)] private string stringOut;

        public override object GetValue(NodePort port)
        {
            return stringOut;
        }
    }
}