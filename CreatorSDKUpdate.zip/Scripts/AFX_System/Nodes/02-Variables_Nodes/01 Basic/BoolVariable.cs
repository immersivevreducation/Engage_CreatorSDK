﻿using XNode;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Basic/Bool")]
    public class BoolVariable : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Always)] private bool boolOut;

        public override object GetValue(NodePort port)
        {
            return boolOut;
        }
    }
}