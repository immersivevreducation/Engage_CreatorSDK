﻿using XNode;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Basic/Float")]
    public class FloatVariable : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Always)] private float floatOut;

        public override object GetValue(NodePort port)
        {
            return floatOut;
        }
    }
}