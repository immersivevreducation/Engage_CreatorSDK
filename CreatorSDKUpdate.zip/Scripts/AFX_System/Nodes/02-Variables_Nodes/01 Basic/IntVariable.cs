﻿using XNode;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Variables/Basic/Int")]
    public class IntVariable : AFXNode
    {
        [SerializeField]
        [Output(ShowBackingValue.Always)] private int intOut;

        public override object GetValue(NodePort port)
        {
            return intOut;
        }
    }
}