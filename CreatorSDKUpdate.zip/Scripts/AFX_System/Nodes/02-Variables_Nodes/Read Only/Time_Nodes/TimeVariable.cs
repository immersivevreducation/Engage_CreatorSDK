﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Variables/Read Only/Time")]
    public class TimeVariable : AFXNode
    {
        [SerializeField]
        [Output] private float time;
        [SerializeField]
        [Output] private float deltaTime;
        [SerializeField]
        [Output] private float fixedTime;
        [SerializeField]
        [Output] private float realtimeSinceStartup;

        public override object GetValue(NodePort port)
        {
            if (port.fieldName == nameof(time))
            {
                return Time.time;
            }
            if (port.fieldName == nameof(deltaTime))
            {
                return Time.deltaTime;
            }
            if (port.fieldName == nameof(fixedTime))
            {
                return Time.fixedTime;
            }
            if (port.fieldName == nameof(realtimeSinceStartup))
            {
                return Time.realtimeSinceStartup;
            }
            return null;
        }
    }
}