﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Distance")]
    public class Distance : AFXNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Vector3 a;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Vector3 b;

        [SerializeField]
        [Output] private float distanceOut;

        public override object GetValue(NodePort port)
        {
            a = GetInputValue(nameof(a), a);
            b = GetInputValue(nameof(b), b);

            return Vector3.Distance(a, b);
        }              
    }
}
