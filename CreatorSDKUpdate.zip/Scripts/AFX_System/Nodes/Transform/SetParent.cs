﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Set Parent")]
    public class SetParent : AFXActiveNode
    {
        [SerializeField]
        [Input] private bool keepOffset = false;
        [SerializeField]
        [Input] private Transform childIn;
        [SerializeField]
        [Input] private Transform parentIn;

        [SerializeField]
        [Output] private Transform oldParentOut;

        public override object GetValue(NodePort port)
        {
            oldParentOut = GetInputValue(nameof(oldParentOut), oldParentOut);
            return oldParentOut;
        }

        void Parent()
        {
            childIn = GetInputValue(nameof(childIn), childIn);
            parentIn = GetInputValue(nameof(parentIn), parentIn);
            if (childIn.parent != parentIn)
            {
                oldParentOut = childIn.parent;
                keepOffset = GetInputValue(nameof(keepOffset), keepOffset);
                childIn.SetParent(parentIn, keepOffset);
            }
        }

        protected override void ExecuteNode()
        {
            Parent();
        }
    }
}
