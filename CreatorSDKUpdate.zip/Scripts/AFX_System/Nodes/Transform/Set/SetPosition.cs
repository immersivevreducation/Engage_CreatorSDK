﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Transform/Set/Set Position")]
    public class SetPosition : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;
        [SerializeField]
        [Input] private bool worldSpace = false;
        [SerializeField]
        [Input] private Vector3 vector3In;

        void SetPositions()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            worldSpace = GetInputValue(nameof(worldSpace), worldSpace);
            vector3In = GetInputValue(nameof(vector3In), vector3In);
            
            InputToPosition(vector3In, transformIn, worldSpace);
        }

        public void InputToPosition(Vector3 input, Transform transformIN, bool worldSpace)
        {
            if (worldSpace)
            {
                transformIN.transform.position = input;
            }
            else
            {
                transformIN.transform.localPosition = input;
            }
        }

        protected override void ExecuteNode()
        {
            SetPositions();
        }
    }
}
