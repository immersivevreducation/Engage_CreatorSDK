﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Transform/Set/Set Rotation")]
    public class SetRotation : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;
        [SerializeField]
        [Input] private bool worldSpace = false;
        [SerializeField]
        [Input] private Quaternion quaternionIn;

        void SetRotations()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            worldSpace = GetInputValue(nameof(worldSpace), worldSpace);
            quaternionIn = GetInputValue(nameof(quaternionIn), quaternionIn);

            InputToQuaternion(quaternionIn, transformIn, worldSpace);
        }

        public void InputToQuaternion(Quaternion input, Transform transformIN, bool worldSpace)
        {
            if (worldSpace)
            {
                transformIN.transform.rotation = input;
            }
            else
            {
                transformIN.transform.localRotation = input;
            }
        }

        protected override void ExecuteNode()
        {
            SetRotations();
        }
    }
}
