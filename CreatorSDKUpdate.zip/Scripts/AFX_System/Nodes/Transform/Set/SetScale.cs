﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Transform/Set/Set Scale")]
    public class SetScale : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;
        [SerializeField]
        [Input] private Vector3 vector3In;

        void SetScales()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            vector3In = GetInputValue(nameof(vector3In), vector3In);
            transformIn.transform.localScale = vector3In;
        }

        protected override void ExecuteNode()
        {
            SetScales();
        }
    }
}
