﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Transform/Transform Look At")]
    public class TransformLookAt : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform lookAtTransformIn;
        [SerializeField]
        [Input] private Vector3 worldUpIn;

        void LookAt()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            lookAtTransformIn = GetInputValue(nameof(lookAtTransformIn), lookAtTransformIn);
            worldUpIn = GetInputValue(nameof(worldUpIn), worldUpIn);

            transformIn.LookAt(lookAtTransformIn, worldUpIn);
        }

        protected override void ExecuteNode()
        {
            LookAt();
        }
    }
}
