﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Get/Get Quaternion Angle")]
    public class GetQuaternionAngle : AFXNode
    {
        [Header("Connect either transform A+B or Quaternion A+B not both")]
        [SerializeField]
        [Input] private Transform transformA;
        [SerializeField]
        [Input] private Transform transformB;
        [SerializeField]
        [Input] private Quaternion quaternionA;
        [SerializeField]
        [Input] private Quaternion quaternionB;

        [SerializeField]
        [Output] private float angleOut;     
        
        public override object GetValue(NodePort port)
        {
            if (GetInputPort(nameof(transformA)).IsConnected && GetInputPort(nameof(transformB)).IsConnected)
            {
                transformA = GetInputValue(nameof(transformA), transformA);
                transformB = GetInputValue(nameof(transformB), transformB);
                return Quaternion.Angle(transformA.rotation, transformB.rotation);
            }
            quaternionA = GetInputValue(nameof(quaternionA), quaternionA);
            quaternionB = GetInputValue(nameof(quaternionB), quaternionB);
            return Quaternion.Angle(quaternionA, quaternionB);
        }
    }
}