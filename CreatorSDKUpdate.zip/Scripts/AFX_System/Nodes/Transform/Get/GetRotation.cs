﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Get/Get Rotation")]
    public class GetRotation : AFXNode
    {        
        [SerializeField]
        [Input] private Transform transformIn;
        [SerializeField]
        [Input] private bool local = true;

        [SerializeField]
        [Output] private Vector3 eulerAnglesOut;
        [SerializeField]
        [Output] private Quaternion rotationOut;

        public override object GetValue(NodePort port)
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            local = GetInputValue(nameof(local), local);
            if (local)
            {
                if (port.fieldName == nameof(eulerAnglesOut))
                {
                    return transformIn.localEulerAngles;
                }
            }
            else
            {
                if (port.fieldName == nameof(eulerAnglesOut))
                {
                    return transformIn.eulerAngles;
                }
                return eulerAnglesOut;
            }
            if (port.fieldName == nameof(rotationOut))
            {
                return transformIn.rotation;
            }
            return null;
        }
    }
}