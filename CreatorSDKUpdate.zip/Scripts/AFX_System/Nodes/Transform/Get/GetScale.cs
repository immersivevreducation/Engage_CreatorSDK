﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Get/Get Scale")]
    public class GetScale : AFXNode
    {
        
        [SerializeField]
        [Input] private Transform transformIn;
        [SerializeField]
        [Input] private bool lossy = false;

        [SerializeField]
        [Output] private Vector3 scaleOut;  
        
        public override object GetValue(NodePort port)
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            lossy = GetInputValue(nameof(lossy), lossy);
            if (lossy)
            {
                if (port.fieldName == nameof(scaleOut))
                {
                    return transformIn.lossyScale;
                }
                return scaleOut;
            }
            else
            {
                if (port.fieldName == nameof(scaleOut))
                {
                    return transformIn.localScale;
                }
                return scaleOut;
            }
        }
    }
}