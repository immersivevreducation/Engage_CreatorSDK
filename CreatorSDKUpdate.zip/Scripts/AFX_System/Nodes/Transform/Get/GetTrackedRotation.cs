﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Get/Tracked Rotation")]
    public class GetTrackedRotation : AFXActiveNode
    {
        public enum Axis { X, Y, Z }

        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;

        [SerializeField]
        [Output] private float rotationDegreeCount;

        public Axis axis = Axis.X;
        private float delta;
        private Vector3 lastRotation;

        private Vector3 baseAxis;
        private Vector3 baseFacing;

        protected override void Init()
        {
            base.Init();
            switch (axis)
            {
                case Axis.X:
                    baseAxis = Vector3.right;
                    baseFacing = Vector3.forward;
                    break;
                case Axis.Y:
                    baseAxis = Vector3.up;
                    baseFacing = Vector3.right;
                    break;
                case Axis.Z:
                    baseAxis = Vector3.forward;
                    baseFacing = Vector3.up;
                    break;
            }
        }

        public override object GetValue(NodePort port)
        {
            return rotationDegreeCount;
        }

        void GetTrackedRotations()
        {
            float output = rotationDegreeCount;
            transformIn = GetInputValue(nameof(transformIn), transformIn);

            var axis = transformIn.localRotation * baseAxis;
            var facing = transformIn.localRotation * baseFacing;

            delta = Vector3.SignedAngle(Vector3.ProjectOnPlane(lastRotation, axis), facing, axis);
            lastRotation = facing;

            output += delta;
            rotationDegreeCount = output;
        }

        protected override void ExecuteNode()
        {
            GetTrackedRotations();
        }
    }
}
