﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Get/Get Signed Angle")]
    public class GetSignedAngle : AFXNode
    {
        [SerializeField]
        [Input] private Vector3 from;
        [SerializeField]
        [Input] private Vector3 to;
        [SerializeField]
        [Input] private Vector3 axis;

        [SerializeField]
        [Output] private float angleOut;     
        
        public override object GetValue(NodePort port)
        {
            from = GetInputValue(nameof(from), from);
            to = GetInputValue(nameof(to), to);
            axis = GetInputValue(nameof(axis), axis);
            angleOut = Vector3.SignedAngle(from, to, axis);
            return angleOut;
        }
    }
}