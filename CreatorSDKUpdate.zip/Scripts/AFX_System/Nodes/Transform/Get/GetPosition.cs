﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Get/Get Position")]
    public class GetPosition : AFXNode
    {
        [SerializeField]
        [Input] private Transform transformIn;
        [SerializeField]
        [Input] private bool worldSpace = false;

        [SerializeField]
        [Output] private Vector3 positionOut;  
        
        public override object GetValue(NodePort port)
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            worldSpace = GetInputValue(nameof(worldSpace), worldSpace);
            if (worldSpace)
            {
                if (port.fieldName == nameof(positionOut))
                {
                    return transformIn.position;
                }
                return positionOut;
            }
            else
            {
                if (port.fieldName == nameof(positionOut))
                {
                    return transformIn.localPosition;
                }
                return positionOut;
            }
        }
    }
}