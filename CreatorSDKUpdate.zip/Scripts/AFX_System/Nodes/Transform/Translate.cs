﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Transform/Translate")]
    public class Translate : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Transform transformIn;
        [SerializeField]
        [Input] private bool worldSpace = false;
        [SerializeField]
        [Input] private Vector3 vector3In;

        void TranslatePosition()
        {
            transformIn = GetInputValue(nameof(transformIn), transformIn);
            worldSpace = GetInputValue(nameof(worldSpace), worldSpace);
            vector3In = GetInputValue(nameof(vector3In), vector3In);
            if (worldSpace)
            {
                transformIn.Translate(vector3In, Space.World);
            }
            else
            {
                transformIn.Translate(vector3In, Space.Self);
            }
        }

        protected override void ExecuteNode()
        {
            TranslatePosition();
        }
    }
}
