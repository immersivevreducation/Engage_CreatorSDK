﻿using UnityEngine;
using XNode;

namespace AFX
{
    [CreateNodeMenu("Transform/Move Towards")]
    public class MoveTowards : AFXActiveNode
    {
        [SerializeField]
        [Input] private Vector3 fromIn;
        [SerializeField]
        [Input] private Vector3 toIn;
        [SerializeField]
        [Input] private float deltaIn;

        [SerializeField]
        [Output(ShowBackingValue.Never)] private Vector3 currentVector3Out;

        public override object GetValue(NodePort port)
        {
            return currentVector3Out;
        }

        void MoveToward()
        {
            fromIn = GetInputValue(nameof(fromIn), fromIn);
            toIn = GetInputValue(nameof(toIn), toIn);
            deltaIn = GetInputValue(nameof(deltaIn), deltaIn);

            currentVector3Out = Vector3.MoveTowards(fromIn, toIn, deltaIn);
        }

        protected override void ExecuteNode()
        {
            MoveToward();
        }
    }
}
