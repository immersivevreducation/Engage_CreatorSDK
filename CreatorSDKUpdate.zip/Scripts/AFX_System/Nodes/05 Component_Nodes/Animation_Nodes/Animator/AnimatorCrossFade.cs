﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/CrossFade")]
    public class AnimatorCrossFade : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private bool fixedTime;
        [SerializeField]
        [Input] private string stateName;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private int stateNameHash;
        [SerializeField]
        [Input] private float transitionDuration = 0.5f;
        [SerializeField]
        [Input] private int layer = 0;
        [SerializeField]
        [Input] private float timeOffset;
        [SerializeField]
        [Input] private float transitionTime;

        public void CrossFade()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            fixedTime = GetInputValue(nameof(fixedTime), fixedTime);
            stateName = GetInputValue(nameof(stateName), stateName);
            stateNameHash = GetInputValue(nameof(stateNameHash), stateNameHash);
            transitionDuration = GetInputValue(nameof(transitionDuration), transitionDuration);
            timeOffset = GetInputValue(nameof(timeOffset), timeOffset);
            transitionTime = GetInputValue(nameof(transitionTime), transitionTime);

            if (GetInputPort(nameof(stateNameHash)).IsConnected)
            {
                if (fixedTime)
                {
                    animatorIn.CrossFadeInFixedTime(stateNameHash, transitionDuration, layer, timeOffset, transitionTime);
                }
                else
                {
                    animatorIn.CrossFade(stateNameHash, transitionDuration, layer, timeOffset, transitionTime);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(stateName))
                {
                    if (fixedTime)
                    {
                        animatorIn.CrossFadeInFixedTime(stateName, transitionDuration);
                    }
                    else
                    {
                        animatorIn.CrossFade(stateName, transitionDuration);
                    }
                }
                else
                {
                    error = $"[{this.name}] State Name Empty";
                }
            }            
        }

        protected override void ExecuteNode()
        {
            CrossFade();
        }
    }
}
