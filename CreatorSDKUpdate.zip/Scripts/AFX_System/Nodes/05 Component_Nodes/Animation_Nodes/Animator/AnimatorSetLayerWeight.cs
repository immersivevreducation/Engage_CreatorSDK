﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Set Layer Weight")]
    public class AnimatorSetLayerWeight : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private int layerIndex = 0;
        [SerializeField]
        [Input] private float weight;

        public void SetLayerWeight()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            layerIndex = GetInputValue(nameof(layerIndex), layerIndex);
            weight = GetInputValue(nameof(weight), weight);

            animatorIn.SetLayerWeight(layerIndex, weight);
        }

        protected override void ExecuteNode()
        {
            SetLayerWeight();
        }
    }
}
