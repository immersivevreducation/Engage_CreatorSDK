﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/CrossFade Simple")]
    public class AnimatorCrossFadeSimple : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Inherited)] private Animator animatorIn;
        [SerializeField]
        [Input] private bool fixedTime;
        [SerializeField]
        [Input] private string stateName;
        [SerializeField]
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Strict)] private int stateNameHash;
        [SerializeField]
        [Input] private float transitionDuration = 0.5f;


        public void CrossFade()
        {
            animatorIn = GetInputValue("animatorIn", animatorIn);
            fixedTime = GetInputValue("fixedTime", fixedTime);
            stateName = GetInputValue("stateName", stateName);
            stateNameHash = GetInputValue("stateNameHash", stateNameHash);
            transitionDuration = GetInputValue("transitionDuration", transitionDuration);

            if (GetInputPort(nameof(stateNameHash)).IsConnected)
            {
                if (fixedTime)
                {
                    animatorIn.CrossFadeInFixedTime(stateNameHash, transitionDuration);
                }
                else
                {
                    animatorIn.CrossFade(stateNameHash, transitionDuration);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(stateName))
                {
                    if (fixedTime)
                    {
                        animatorIn.CrossFadeInFixedTime(stateName, transitionDuration);
                    }
                    else
                    {
                        animatorIn.CrossFade(stateName, transitionDuration);
                    }
                }
                else
                {
                    error = $"[{this.name}] State Name Empty";
                }
            }            
        }

        protected override void ExecuteNode()
        {
            CrossFade();
        }
    }
}
