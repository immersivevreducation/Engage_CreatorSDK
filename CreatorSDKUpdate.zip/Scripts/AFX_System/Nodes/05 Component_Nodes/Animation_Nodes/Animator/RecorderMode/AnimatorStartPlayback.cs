﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Start Playback")]
    public class AnimatorStartPlayback : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Inherited)] private Animator animatorIn;


        public void StartPlayback()
        {
            animatorIn = GetInputValue("animatorIn", animatorIn);
            animatorIn.StartPlayback();
        }

        protected override void ExecuteNode()
        {
            StartPlayback();
        }
    }
}
