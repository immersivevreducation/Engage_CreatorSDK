﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Playback Time")]
    public class AnimatorPlaybackTime : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Inherited)] private Animator animatorIn;
        [SerializeField]
        [Input(ShowBackingValue.Unconnected, ConnectionType.Override, TypeConstraint.Inherited)] private float playbackTimeIn;


        public void PlaybackTime()
        {
            animatorIn = GetInputValue("animatorIn", animatorIn);
            playbackTimeIn = GetInputValue("playbackTimeIn", playbackTimeIn);
            animatorIn.playbackTime = playbackTimeIn;
        }

        protected override void ExecuteNode()
        {
            PlaybackTime();
        }
    }
}
