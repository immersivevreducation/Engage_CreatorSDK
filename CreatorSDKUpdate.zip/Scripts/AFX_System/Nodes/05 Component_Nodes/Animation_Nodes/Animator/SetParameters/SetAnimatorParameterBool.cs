﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Set Parameter/Bool")]
    public class SetAnimatorParameterBool : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private string parameterNameBool;
        [SerializeField]
        [Input] private bool parameterBool;

        public void SetParamaterBool()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            parameterNameBool = GetInputValue(nameof(parameterBool), parameterNameBool);

            if (!string.IsNullOrEmpty(parameterNameBool))
            {
                parameterBool = GetInputValue(nameof(parameterBool), parameterBool);
                animatorIn.SetBool(parameterNameBool, parameterBool);
            }
            else
            {
                error = $"[{this.name}] Parameter Name Empty";
            }
        }

        protected override void ExecuteNode()
        {
            SetParamaterBool();
        }
    }
}