﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Set Parameter/Float")]
    public class SetAnimatorParameterFloat : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private string parameterNameFloat;
        [SerializeField]
        [Input] private float parameterFloat;

        public void SetParamaterFloat()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            parameterNameFloat = GetInputValue(nameof(parameterNameFloat), parameterNameFloat);

            if (!string.IsNullOrEmpty(parameterNameFloat))
            {
                parameterFloat = GetInputValue(nameof(parameterFloat), parameterFloat);
                animatorIn.SetFloat(parameterNameFloat, parameterFloat);
            }
            else
            {
                error = $"[{this.name}] Parameter Name Empty";
            }
        }

        protected override void ExecuteNode()
        {
            SetParamaterFloat();
        }
    }
}