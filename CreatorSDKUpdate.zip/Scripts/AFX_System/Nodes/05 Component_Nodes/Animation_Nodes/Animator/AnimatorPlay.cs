﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Play")]
    public class AnimatorPlay : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private bool fixedTime;
        [SerializeField]
        [Input] private string stateName;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private int stateNameHash;
        [SerializeField]
        [Input] private int layer = -1;
        [SerializeField]
        [Input] private float time = 0;

        public void Play()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            fixedTime = GetInputValue(nameof(fixedTime), fixedTime);
            stateName = GetInputValue(nameof(stateName), stateName);
            stateNameHash = GetInputValue(nameof(stateNameHash), stateNameHash);
            layer = GetInputValue(nameof(layer), layer);
            time = GetInputValue(nameof(time), time);

            if (GetInputPort(nameof(stateNameHash)).IsConnected)
            {
                if (fixedTime)
                {
                    animatorIn.PlayInFixedTime(stateNameHash, layer, time);
                }
                else
                {
                    animatorIn.Play(stateNameHash, layer, time);
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(stateName))
                {
                    if (fixedTime)
                    {
                        animatorIn.PlayInFixedTime(stateName, layer, time);
                    }
                    else
                    {
                        animatorIn.Play(stateName, layer, time);
                    }
                }
                else
                {
                    error = $"[{this.name}] State Name Empty";
                }
            }            
        }

        protected override void ExecuteNode()
        {
            Play();
        }
    }
}
