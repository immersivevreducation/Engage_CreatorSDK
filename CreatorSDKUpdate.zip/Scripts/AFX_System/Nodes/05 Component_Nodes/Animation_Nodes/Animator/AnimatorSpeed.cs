﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator/Set Speed")]
    public class AnimatorSpeed : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private float speed = 0;

        public void SetSpeed()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            speed = GetInputValue(nameof(speed), speed);

            animatorIn.speed = speed;
        }

        protected override void ExecuteNode()
        {
            SetSpeed();
        }
    }
}
