﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Animation/Animator")]
    public class AnimatorSettings : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Animator animatorIn;
        [SerializeField]
        [Input] private string paramaterNameBool;
        [SerializeField]
        [Input] private bool paramaterBool;
        [SerializeField]
        [Input] private string paramaterNameFloat;
        [SerializeField]
        [Input] private float paramaterFloat;

        public void AnimatorParamaterUpdate()
        {
            animatorIn = GetInputValue(nameof(animatorIn), animatorIn);
            paramaterNameBool = GetInputValue(nameof(paramaterNameBool), paramaterNameBool);
            paramaterNameFloat = GetInputValue(nameof(paramaterNameFloat), paramaterNameFloat);

            if (!string.IsNullOrEmpty(paramaterNameBool))
            {
                paramaterBool = GetInputValue(nameof(paramaterBool), paramaterBool);
                animatorIn.SetBool(paramaterNameBool, paramaterBool);
            }
            
            if (!string.IsNullOrEmpty(paramaterNameFloat))
            {
                paramaterFloat = GetInputValue(nameof(paramaterFloat), paramaterFloat);
                animatorIn.SetFloat(paramaterNameFloat, paramaterFloat);
            }
        }

        protected override void ExecuteNode()
        {
            AnimatorParamaterUpdate();
        }
    }
}
