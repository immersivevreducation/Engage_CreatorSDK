﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Material/Set/Int")]
    public class SetMaterialInt : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Material materialIn;
        [SerializeField]
        [Input] private string intPropertyName;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private int intIn;

        private int propertyId = -1;

        protected override void Init()
        {
            base.Init();
            intPropertyName = GetInputValue(nameof(intPropertyName), intPropertyName);
            if (!string.IsNullOrEmpty(intPropertyName))
            {
                propertyId = Shader.PropertyToID(intPropertyName);
            }
        }

        void SetInt()
        {
            materialIn = GetInputValue(nameof(materialIn), materialIn);
            intIn = GetInputValue(nameof(intIn), intIn);
            materialIn.SetInt(propertyId, intIn);
        }

        protected override void ExecuteNode()
        {
            SetInt();
        }
    }
}
