﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Material/Set/Float")]
    public class SetMaterialFloat : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Material materialIn;
        [SerializeField]
        [Input] private string floatPropertyName;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private float floatIn;

        private int propertyId = -1;

        protected override void Init()
        {
            base.Init();
            floatPropertyName = GetInputValue(nameof(floatPropertyName), floatPropertyName);
            if (!string.IsNullOrEmpty(floatPropertyName))
            {
                propertyId = Shader.PropertyToID(floatPropertyName);
            }
        }

        void SetFloat()
        {
            materialIn = GetInputValue(nameof(materialIn), materialIn);
            floatIn = GetInputValue(nameof(floatIn), floatIn);
            materialIn.SetFloat(propertyId, floatIn);
        }

        protected override void ExecuteNode()
        {
            SetFloat();
        }
    }
}
