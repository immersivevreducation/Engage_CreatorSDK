﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Material/Set/Color")]
    public class SetMaterialColor : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Material materialIn;
        [SerializeField]
        [Input] private string colorPropertyName = "_Color";
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Color colorIn;

        private int propertyId = -1;

        protected override void Init()
        {
            base.Init();
            colorPropertyName = GetInputValue(nameof(colorPropertyName), colorPropertyName);
            if (!string.IsNullOrEmpty(colorPropertyName))
            {
                propertyId = Shader.PropertyToID(colorPropertyName);
            }
        }

        void SetColor()
        {
            materialIn = GetInputValue(nameof(materialIn), materialIn);
            colorIn = GetInputValue(nameof(colorIn), colorIn);
            materialIn.SetColor(propertyId, colorIn);
        }

        protected override void ExecuteNode()
        {
            SetColor();
        }
    }
}
