﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Material/Set/Vector")]
    public class SetMaterialVector : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Material materialIn;
        [SerializeField]
        [Input] private string vectorPropertyName;
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Vector4 vectorIn;

        private int propertyId = -1;

        protected override void Init()
        {
            base.Init();
            vectorPropertyName = GetInputValue(nameof(vectorPropertyName), vectorPropertyName);
            if (!string.IsNullOrEmpty(vectorPropertyName))
            {
                propertyId = Shader.PropertyToID(vectorPropertyName);
            }
        }

        void SetVector()
        {
            materialIn = GetInputValue(nameof(materialIn), materialIn);
            vectorIn = GetInputValue(nameof(vectorIn), vectorIn);
            materialIn.SetVector(propertyId, vectorIn);
        }

        protected override void ExecuteNode()
        {
            SetVector();
        }
    }
}
