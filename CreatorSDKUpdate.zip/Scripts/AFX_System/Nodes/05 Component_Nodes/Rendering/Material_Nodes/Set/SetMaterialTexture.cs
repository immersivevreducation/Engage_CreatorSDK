﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Material/Set/Texture")]
    public class SetMaterialTexture : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Material materialIn;
        [SerializeField]
        [Input] private string texturePropertyName = "_MainTex";
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Texture textureIn;

        private int propertyId = -1;

        protected override void Init()
        {
            base.Init();
            texturePropertyName = GetInputValue(nameof(texturePropertyName), texturePropertyName);
            if (!string.IsNullOrEmpty(texturePropertyName))
            {
                propertyId = Shader.PropertyToID(texturePropertyName);
            }
        }

        void SetTexture()
        {
            materialIn = GetInputValue(nameof(materialIn), materialIn);
            textureIn = GetInputValue(nameof(textureIn), textureIn);
            materialIn.SetTexture(propertyId, textureIn);
        }

        protected override void ExecuteNode()
        {
            SetTexture();
        }
    }
}
