﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Material/Material - Generic")]
    public class MaterialGenericSettings : AFXActiveNode
    {
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Strict)] public Material materialIn;
        [Input] public string colorPropertyName = "Color";
        [Input(ShowBackingValue.Never)] public Color colorIn;
        [Input] public string texturePropertyName = "MainTex";
        [Input(ShowBackingValue.Never)] public Texture textureIn;
        [Input] public string floatPropertyName;
        [Input] public float floatIn;
        [Input] public string intPropertyName;
        [Input] public int intIn;
        [Input] public string vectorPropertyName;
        [Input] public Vector4 vectorIn;  

        void AdjustMaterial()
        {            
            if (this.GetInputValue("enabled", enabled))
            {
                Material matIn = GetInputValue("materialIn", materialIn);
                Color colorIN = GetInputValue("colorIn", colorIn);
                string colorName = GetInputValue("colorPropertyName", colorPropertyName);
                string textureName = GetInputValue("texturePropertyName", texturePropertyName);
                string floatName = GetInputValue("floatPropertyName", floatPropertyName);
                string intName = GetInputValue("intPropertyName", intPropertyName);
                string VecName = GetInputValue("vectorPropertyName", vectorPropertyName);

                if (GetInputPort("colorIn").IsConnected)
                {
                    if (!string.IsNullOrEmpty(colorName))
                    {
                        if (matIn.HasProperty(colorName))
                        {
                            matIn.SetColor(colorName, GetInputValue("colorIn", colorIn));
                        }
                    }
                }

                if (GetInputPort("textureIn").IsConnected)
                {
                    if (!string.IsNullOrEmpty(textureName))
                    {
                        if (matIn.HasProperty(textureName))
                        {
                            matIn.SetTexture(textureName, GetInputValue("textureIn", textureIn));
                        }
                    }
                }                   
                
                if (!string.IsNullOrEmpty(floatName))
                {
                    if (matIn.HasProperty(floatName))
                    {
                        matIn.SetFloat(floatName, GetInputValue("floatIn", floatIn));
                    }
                }
                
                if (!string.IsNullOrEmpty(intName))
                {
                    if (matIn.HasProperty(intName))
                    {
                        matIn.SetInt(intName, GetInputValue("intIn", intIn));
                    }
                }
               
                if (!string.IsNullOrEmpty(VecName))
                {
                    if (matIn.HasProperty(VecName))
                    {
                        matIn.SetVector(VecName, GetInputValue("vectorIn", vectorIn));
                    }
                }                
            }
        }

        protected override void ExecuteNode()
        {
            AdjustMaterial();
        }
    }
}
