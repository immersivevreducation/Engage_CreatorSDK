﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Renderer Is Visable")]
    public class RendererIsVisable : AFXNode
    {
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Strict)] public Renderer rendererIn;
        [Output] public Material materialout;
        [Output] public Material sharedMaterialOut;
        [Output] public bool isVisable;

        protected override void Init()
        {
            base.Init();
        }

        public override object GetValue(NodePort port)
        {
            rendererIn = GetInputValue("rendererIn", rendererIn);            
            return rendererIn.isVisible;
        }
    }
}
