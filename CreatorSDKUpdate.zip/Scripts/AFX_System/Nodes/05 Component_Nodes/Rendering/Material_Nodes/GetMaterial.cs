﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Get Material")]
    public class GetMaterial : AFXNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Renderer rendererIn;
        [SerializeField]
        [Input] private bool sharedMaterial = false;
        [SerializeField]
        [Input] private int materialIndex = 0;

        [SerializeField]
        [Output] private Material materialOut;

        public override object GetValue(NodePort port)
        {
            rendererIn = GetInputValue(nameof(rendererIn), rendererIn);
            materialIndex = GetInputValue(nameof(materialIndex), materialIndex);
            if (sharedMaterial)
            {
                if (materialIndex < rendererIn.sharedMaterials.Length)
                {
                    error = null;
                    return rendererIn.sharedMaterials[materialIndex];
                }
                else
                {
                    error = $"[{this.name}] Index Out Of range: {materialIndex}";
                    Debug.LogError(error);
                }
            }
            else
            {
                if (materialIndex < rendererIn.materials.Length)
                {
                    error = null;
                    return rendererIn.materials[materialIndex];
                }
                else
                {
                    error = $"[{this.name}] Index Out Of range: {materialIndex}";
                    Debug.LogError(error);
                }

            }
            return null;
        }
    }
}
