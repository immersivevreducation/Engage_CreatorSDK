﻿using UnityEngine;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Camera/Set/Field Of View")]
    public class SetCameraFieldOfView : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Strict)] private Camera cameraIn;
        [SerializeField]
        [Input] private float fieldOfView;

        public void FieldOfViewUpdate()
        {
            cameraIn = GetInputValue(nameof(cameraIn), cameraIn);
            cameraIn.fieldOfView = GetInputValue(nameof(fieldOfView), fieldOfView);
        }

        protected override void ExecuteNode()
        {
            FieldOfViewUpdate();
        }
    }
}
