﻿using UnityEngine;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Camera/Set/Render Texture")]
    public class SetCameraTargetTexture : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Camera cameraIn;
        [SerializeField]
        [Input] private RenderTexture renderTexture;

        public void SetRenderTexture()
        {
            cameraIn = GetInputValue(nameof(cameraIn), cameraIn);
            cameraIn.targetTexture = GetInputValue(nameof(renderTexture), renderTexture);
        }

        protected override void ExecuteNode()
        {
            SetRenderTexture();
        }
    }
}
