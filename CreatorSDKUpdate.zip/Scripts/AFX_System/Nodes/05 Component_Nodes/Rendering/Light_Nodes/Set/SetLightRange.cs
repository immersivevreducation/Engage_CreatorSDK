﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Light/Set/Range")]
    public class SetLightRange : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Light lightIn;

        [SerializeField]
        [Input] private float rangeIn;

        public void LightUpdate()
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);
            rangeIn = GetInputValue(nameof(rangeIn), rangeIn);
            lightIn.range = rangeIn;
        }

        protected override void ExecuteNode()
        {
            LightUpdate();
        }
    }
}
