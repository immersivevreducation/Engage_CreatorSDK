﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Light/Set/Type")]
    public class SetLightRenderMode : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Light lightIn;
        [SerializeField]
        private LightRenderMode renderModeIn;

        public void LightUpdate()
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);
            lightIn.renderMode = renderModeIn;
        }

        protected override void ExecuteNode()
        {
            LightUpdate();
        }
    }
}
