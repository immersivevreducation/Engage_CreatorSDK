﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Light/Set/color")]
    public class SetLightColor : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Light lightIn;

        [SerializeField]
        [Input] private Color colorIn;

        public void LightUpdate()
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);
            colorIn = GetInputValue(nameof(colorIn), colorIn);
            lightIn.color = colorIn;
        }

        protected override void ExecuteNode()
        {
            LightUpdate();
        }
    }
}
