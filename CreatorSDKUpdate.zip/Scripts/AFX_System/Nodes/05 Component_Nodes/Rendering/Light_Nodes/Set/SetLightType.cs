﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Light/Set/Type")]
    public class SetLightType : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Light lightIn;
        [SerializeField]
        private LightType typeIn;

        public void LightUpdate()
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);
            lightIn.type = typeIn;
        }

        protected override void ExecuteNode()
        {
            LightUpdate();
        }
    }
}
