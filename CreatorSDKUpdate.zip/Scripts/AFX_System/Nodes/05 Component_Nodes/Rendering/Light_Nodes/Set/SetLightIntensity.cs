﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Light/Set/Intensity")]
    public class SetLightIntensity : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Light lightIn;

        [SerializeField]
        [Input] private float intensityIn;

        public void LightUpdate()
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);
            intensityIn = GetInputValue(nameof(intensityIn), intensityIn);
            lightIn.intensity = intensityIn;
        }

        protected override void ExecuteNode()
        {
            LightUpdate();
        }
    }
}
