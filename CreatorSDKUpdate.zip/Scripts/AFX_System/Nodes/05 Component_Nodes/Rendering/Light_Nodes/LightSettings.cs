﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Rendering/Light/Light")]
    public class LightSettings : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Light lightIn;
        [SerializeField]
        [Input] private LightType typeIn;
        [SerializeField]
        [Input] private LightRenderMode lightRenderModeIn;
        [SerializeField]
        [Input] private float rangeIn;
        [SerializeField]
        [Input] private Color colorIn;
        [SerializeField]
        [Input] private float intensityIn;

        [SerializeField]
        [Output] private float rangeOut;
        [SerializeField]
        [Output] private Color colorOut;
        [SerializeField]
        [Output] private float intensityOut;

        public override object GetValue(NodePort port)
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);
            if (port.fieldName == nameof(rangeOut))
            {
                rangeOut = lightIn.range;
                return rangeOut;
            }
            if (port.fieldName == nameof(colorOut))
            {
                colorOut = lightIn.color;
                return colorOut;
            }
            if (port.fieldName == nameof(colorOut))
            {
                intensityOut = lightIn.intensity;
                return colorOut;
            }
            return null;
        }

        public void LightUpdate()
        {
            lightIn = GetInputValue(nameof(lightIn), lightIn);

            rangeIn = GetInputValue(nameof(rangeIn), rangeIn);
            colorIn = GetInputValue(nameof(colorIn), colorIn);
            intensityIn = GetInputValue(nameof(intensityIn), intensityIn);

            typeIn = GetInputValue(nameof(typeIn), typeIn);
            lightRenderModeIn = GetInputValue(nameof(lightRenderModeIn), lightRenderModeIn);

            lightIn.range = rangeIn;
            lightIn.color = colorIn;
            lightIn.intensity = intensityIn;
            lightIn.type = typeIn;
            lightIn.renderMode = lightRenderModeIn;
        }

        protected override void ExecuteNode()
        {
            LightUpdate();
        }
    }
}
