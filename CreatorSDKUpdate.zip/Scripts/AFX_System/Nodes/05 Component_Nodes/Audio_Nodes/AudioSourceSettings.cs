﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/Audio/AudioSource")]
    public class AudioSourceSettings : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never, ConnectionType.Override, TypeConstraint.Strict)] private AudioSource audioSourceIn;
        [SerializeField]
        [Input] private AudioClip audioClipIn;
        [SerializeField]
        [Input] private bool loopIn;
        [SerializeField]
        [Input] private float volumeIn;
        [SerializeField]
        [Input] private float pitchIn;

        [SerializeField]
        [Output] private bool isPlayingOut;
        [SerializeField]
        [Output] private float timeOut;

        public override object GetValue(NodePort port)
        {
            audioSourceIn = GetInputValue(nameof(audioSourceIn), audioSourceIn);
            if (port.fieldName == nameof(isPlayingOut))
            {
                isPlayingOut = audioSourceIn.isPlaying;
                return isPlayingOut;
            }

            if (port.fieldName == nameof(timeOut))
            {
                timeOut = audioSourceIn.time;
                return timeOut;
            }
            return null;
        }

        public void AudioSourceUpdate()
        {
            audioSourceIn = GetInputValue(nameof(audioSourceIn), audioSourceIn);
            audioClipIn = GetInputValue(nameof(audioClipIn), audioClipIn);
            loopIn = GetInputValue(nameof(loopIn), loopIn);
            volumeIn = GetInputValue(nameof(volumeIn), volumeIn);
            pitchIn = GetInputValue(nameof(pitchIn), pitchIn);

            if (audioSourceIn.clip != audioClipIn)
            {
                audioSourceIn.clip = audioClipIn;
            }
            audioSourceIn.loop = loopIn;
            audioSourceIn.volume = volumeIn;
            audioSourceIn.pitch = pitchIn;
        }

        protected override void ExecuteNode()
        {
            AudioSourceUpdate();
        }
    }
}
