﻿using UnityEngine;
using XNode;
namespace AFX
{
    [CreateNodeMenu("Component/FX/Particle/Particle System")]
    public class ParticleSystemSettings : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private ParticleSystem particleSystemIn;
        [SerializeField]
        [Input] private float rateOverTimeIn;

        public void ParticleUpdate()
        {
            particleSystemIn = GetInputValue(nameof(particleSystemIn), particleSystemIn);
            rateOverTimeIn = GetInputValue(nameof(rateOverTimeIn), rateOverTimeIn);
            var emission = particleSystemIn.emission;
            emission.rateOverTime = rateOverTimeIn;
        }

        protected override void ExecuteNode()
        {
            ParticleUpdate();
        }
    }
}
