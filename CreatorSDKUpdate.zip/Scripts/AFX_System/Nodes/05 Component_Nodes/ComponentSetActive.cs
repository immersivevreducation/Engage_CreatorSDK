﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Component/Set Active")]
    public class ComponentSetActive : AFXActiveNode
    {
        [SerializeField]
        [Input(ShowBackingValue.Never)] private Behaviour behaviourIn;
        [SerializeField]
        [Input] private bool setActive = false;

        void SetComponentActive()
        {
            behaviourIn = GetInputValue(nameof(behaviourIn), behaviourIn);
            setActive = GetInputValue(nameof(setActive), setActive);
            behaviourIn.enabled = setActive;
        }

        protected override void ExecuteNode()
        {
            SetComponentActive();
        }
    }
}
