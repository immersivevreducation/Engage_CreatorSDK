﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Rendering/Camera")]
    public class CameraReference : ObjectReferenceNode<Camera>{}    
}