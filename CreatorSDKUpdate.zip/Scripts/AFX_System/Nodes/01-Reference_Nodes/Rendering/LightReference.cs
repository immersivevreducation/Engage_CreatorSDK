﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Rendering/Light")]
    public class LightReference : ObjectReferenceNode<Light>{}
}