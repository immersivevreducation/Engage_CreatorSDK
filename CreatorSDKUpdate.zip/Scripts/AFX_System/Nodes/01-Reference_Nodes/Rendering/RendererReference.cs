﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Rendering/Renderer")]
    public class RendererReference : ObjectReferenceNode<Renderer>{}
}