﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Behaviour")]
    public class BehaviourReference : ObjectReferenceNode<Behaviour>{}
}