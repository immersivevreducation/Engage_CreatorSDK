﻿using System;
using UnityEngine;
using XNode;
namespace AFX
{
    [NodeTint(.4f, 0.5f, 0.6f)]
    [CreateNodeMenu("")]
    public class ValueReferenceNode<T> : ObjectReferenceNode<ValueComponent<T>>
    {
        [SerializeField]
        [Input] protected bool writeValue = false;
        [SerializeField]
        [Input(ShowBackingValue.Never)] protected T valueIn;
        [SerializeField]
        [Output(ShowBackingValue.Never)] protected T valueOut;

        // Use this for initialization
        protected override void Init()
        {
            base.Init();
            graph.AFXUpdate += WriteValue;
        }

        protected virtual void WriteValue()
        {
            if (GetInputValue(nameof(writeValue), writeValue))
            {
                var component = ObjectOut;

                if (GetPort(nameof(valueIn)).IsConnected)
                {
                    component.Value = GetInputValue(nameof(valueIn), valueIn);
                }
            }
        }

        // Return the correct value of an output port when requested
        public override object GetValue(NodePort port)
        {
            var component = ObjectOut;

            return component.Value;
        }
    }
}