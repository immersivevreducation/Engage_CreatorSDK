﻿using UnityEngine;
using XNode;

namespace AFX
{
    [NodeTint(0.3f, 0.3f, 0.4f)]
    [CreateNodeMenu("", 0)]
    public abstract class ObjectReferenceNode : AFXNode
    {
        public abstract System.Type MyType { get; }
        [HideInInspector]
        [SerializeField]
        protected string referenceName;
        [HideInInspector]
        [SerializeField]
        protected bool referenceUse = true;

        public string ReferenceName => referenceName;
        public bool ReferenceUse { get { return referenceUse; } set { referenceUse = value; } }
    }

    [NodeTint(0.3f, 0.3f, 0.4f)]
    [CreateNodeMenu("", 0)]
    public class ObjectReferenceNode<T> : ObjectReferenceNode where T : Object
    {
        public override System.Type MyType => typeof(T);

        [SerializeField]
        [Output(ShowBackingValue.Never)] protected T objectOut;

        public virtual T ObjectOut
        {
            get
            {
                if (objectOut == null)
                {
                    if (this.graph.objectReferencesGraph.TryGetValue(referenceName, out Object objectRef))
                    {
                        objectOut = (T)objectRef;
                        error = null;
                    }
                    else
                    {
                        error = $"[{this.name}] No reference found for: {referenceName}";
                        #if UNITY_EDITOR
                        Debug.Log(error);
                        #endif
                    }
                }

                return objectOut;
            }
        }

        public override object GetValue(NodePort port) => ObjectOut;
    }
}