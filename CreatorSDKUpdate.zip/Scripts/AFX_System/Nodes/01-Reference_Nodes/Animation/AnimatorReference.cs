﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Animation/Animator")]
    public class AnimatorReference : ObjectReferenceNode<Animator> { }
}