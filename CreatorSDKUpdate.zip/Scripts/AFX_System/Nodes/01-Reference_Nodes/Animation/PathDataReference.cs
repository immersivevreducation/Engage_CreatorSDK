﻿namespace AFX
{
    [CreateNodeMenu("Reference/Animation/PathData")]
    public class PathDataReference : ObjectReferenceNode<PathData>{}
}