﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Variable/Vector3")]
    public class Vector3Reference : ValueReferenceNode<Vector3> { }
}