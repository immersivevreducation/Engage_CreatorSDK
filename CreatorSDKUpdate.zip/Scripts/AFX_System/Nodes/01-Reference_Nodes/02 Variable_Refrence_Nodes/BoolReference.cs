﻿
namespace AFX
{
    [CreateNodeMenu("Reference/Variable/Bool")]
    public class BoolReference : ValueReferenceNode<bool> { }
}