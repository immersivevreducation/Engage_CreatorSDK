﻿using System.Collections.Generic;
using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Variable/List/GameObject")]
    public class ListGameObjectReference : ValueReferenceNode<List<GameObject>> { }
}