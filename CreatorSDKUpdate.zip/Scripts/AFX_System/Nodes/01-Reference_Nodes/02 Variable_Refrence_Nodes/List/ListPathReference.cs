﻿using System;
using System.Collections.Generic;

namespace AFX
{
    [CreateNodeMenu("Reference/Variable/List/Path")]
    public class ListPathReference : ValueReferenceNode<List<PathData>> { }
}