﻿using UnityEngine;
using UnityEngine.Events;
using XNode;

namespace AFX
{
    [NodeTint(.4f, 0.5f, 0.6f)]
    [CreateNodeMenu("Reference/UnityEvent")]
    public class UnityEventReference : ObjectReferenceNode
    {
        public override System.Type MyType => typeof(EventComponent);
        [SerializeField]
        [Output(ShowBackingValue.Never)] private UnityEvent unityEventOut;


        public override object GetValue(NodePort port)
        {
            if (graph.objectReferencesGraph.TryGetValue(referenceName, out Object objectRef))
            {
                EventComponent eventComponent = (EventComponent)objectRef;
                error = null;
                return eventComponent.Value;
            }
            else
            {
                error = $"[{this.name}] No reference found for: {referenceName}";
                #if UNITY_EDITOR
                Debug.Log(error);
                #endif
            }
            return null;
        }
    }
}