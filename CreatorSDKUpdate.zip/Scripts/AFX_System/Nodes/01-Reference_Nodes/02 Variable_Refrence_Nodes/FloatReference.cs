﻿namespace AFX
{
    [CreateNodeMenu("Reference/Variable/Float")]
    public class FloatReference : ValueReferenceNode<float> { }
}