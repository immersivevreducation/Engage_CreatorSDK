﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Variable/Quaternion")]
    public class QuaternionReference : ValueReferenceNode<Quaternion> { }
}