﻿namespace AFX
{
    [CreateNodeMenu("Reference/Variable/Int")]
    public class IntReference : ValueReferenceNode<int> { }
}