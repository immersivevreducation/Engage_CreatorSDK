﻿namespace AFX
{
    [CreateNodeMenu("Reference/Engage/GrabObject System/Mover")]
    public class GrabObjectMoverReference : ObjectReferenceNode<GrabObjectMover>{}
}