﻿namespace AFX
{
    [CreateNodeMenu("Reference/Engage/GrabObject System/Secondary Grab Point")]
    public class GrabObjectSecondaryReference : ObjectReferenceNode<GrabObjectSecondaryGrabPoint>{}
}