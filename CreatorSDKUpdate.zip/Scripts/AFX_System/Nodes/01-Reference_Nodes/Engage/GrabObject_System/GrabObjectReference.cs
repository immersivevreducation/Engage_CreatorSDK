﻿namespace AFX
{
    [CreateNodeMenu("Reference/Engage/GrabObject System/GrabObject")]
    public class GrabObjectReference : ObjectReferenceNode<GrabObject>{}
}