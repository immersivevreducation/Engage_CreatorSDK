﻿namespace AFX
{
    [CreateNodeMenu("Reference/Engage/Sit Trigger")]
    public class SitTriggerReference : ObjectReferenceNode<LVR_SitTrigger> { }
}