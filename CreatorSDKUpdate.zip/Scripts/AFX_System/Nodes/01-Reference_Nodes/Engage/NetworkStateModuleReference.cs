﻿using Engage.IFX.NetworkStates;

namespace AFX
{
    [CreateNodeMenu("Reference/Engage/NetworkStateModule")]
    public class NetworkStateModuleReference : ObjectReferenceNode<NetworkStateModule>{}
}