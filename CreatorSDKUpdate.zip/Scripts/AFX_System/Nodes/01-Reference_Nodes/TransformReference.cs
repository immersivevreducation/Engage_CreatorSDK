﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Transform")]
    public class TransformReference : ObjectReferenceNode<Transform> { }
}