﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Physics/Rigidbody")]
    public class RigidbodyReference : ObjectReferenceNode<Rigidbody>{}
}