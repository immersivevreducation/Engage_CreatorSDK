﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/FX/Particle")]
    public class ParticleSystemReference : ObjectReferenceNode<ParticleSystem> { }
}