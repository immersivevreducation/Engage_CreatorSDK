﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Collider")]
    public class ColliderReference : ObjectReferenceNode<Collider> { }
}