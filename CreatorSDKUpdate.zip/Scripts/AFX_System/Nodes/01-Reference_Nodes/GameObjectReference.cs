﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/GameObject")]
    public class GameObjectReference : ObjectReferenceNode<GameObject> { }
}