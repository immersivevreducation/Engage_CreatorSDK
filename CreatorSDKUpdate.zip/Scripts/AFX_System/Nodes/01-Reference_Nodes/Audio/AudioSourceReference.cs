﻿using UnityEngine;

namespace AFX
{
    [CreateNodeMenu("Reference/Audio/AudioSource")]
    public class AudioSourceReference : ObjectReferenceNode<AudioSource>{}
}