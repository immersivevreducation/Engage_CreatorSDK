﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Engage.Utility
{
    public class DeactivateThisObjectIfCondition : AbstractConditionCheck
    {
        /// <summary>
        /// Deactivate THIS Object if Condition is met.
        /// </summary>

        private void OnEnable(){}
    }


}
