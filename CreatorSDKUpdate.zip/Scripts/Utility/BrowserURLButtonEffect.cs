using UnityEngine;
using UnityEngine.UI;

namespace Engage.IFX.Options
{
    public class BrowserURLButtonEffect : MonoBehaviour
    {
        [SerializeField] private Text labelText;
        [SerializeField] private string url;

        public void LoadURLAndOpenMenu()
        {
        }

        public void LoadURLInPersonalBrowser()
        {
        }

        public void LoadURLInPersonalBrowser(string url)
        {
        }

        public void OpenMenuToPersonalBrowserPage()
        {
        }
    }
}
