using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Serialization;

namespace Engage.Utility
{
    public abstract class AbstractConditionCheck : MonoBehaviour
    {
        [Header("")]
        [Header("Conditions")]
        [Header("")]
        [SerializeField]
        protected bool ifMobilePlatform;
        [SerializeField]
        protected bool ifDesktopPlatform;
        [SerializeField]
        protected bool ifAndroid;
        [SerializeField]
        protected bool ifNotAndroid;
        [SerializeField]
        protected bool ifWindows;
        [SerializeField]
        protected bool ifNotWindows;
        [SerializeField]
        protected bool ifIOS;
        [SerializeField]
        protected bool ifNotIOS;
        [SerializeField]
        protected bool ifUsingPhone;
        [SerializeField]
        protected bool ifNotUsingPhone;
        [SerializeField]
        protected bool ifEngageFrontEnd;
        [SerializeField]
        protected bool ifViveSessionsFrontEnd;
        [SerializeField]
        protected bool ifEngageMajorApp;
        [SerializeField]
        protected bool ifViveSessionsMajorApp;
        [SerializeField]
        protected bool ifMonitorMode;
        [SerializeField]
        protected bool ifVRMode;
        [SerializeField]
        protected bool if3Dof;
        [SerializeField]
        protected bool if6Dof;
        [SerializeField]
        protected bool ifIsEditor;
        [SerializeField]
        protected bool ifNotEditor;
        [SerializeField]
        protected bool ifUsingOculusWindows;
        [SerializeField]
        protected bool ifNotUsingOculusWindows;
        [SerializeField]
        protected bool ifUsingOculusAndroid;
        [SerializeField]
        protected bool ifNotUsingOculusAndroid;
        [SerializeField]
        protected bool ifUsingSteamVR;
        [SerializeField]
        protected bool ifNotUsingSteamVR;
        [SerializeField]
        protected bool ifUsingWaveVRFocus;
        [SerializeField]
        protected bool ifNotUsingWaveVRFocus;
        [SerializeField]
        protected bool ifUsingPico;
        [SerializeField]
        protected bool ifNotUsingPico;
        [SerializeField]
        protected bool ifProduction;
        [SerializeField]
        protected bool ifNotProduction;
        [SerializeField]
        protected bool ifAdmin;
        [SerializeField]
        protected bool ifNotAdmin;
        [SerializeField]
        [FormerlySerializedAs("ifCreatorOrAdmin")]
        protected bool ifStaffOrAdmin;
        [SerializeField]
        [FormerlySerializedAs("ifNotCreatorOrAdmin")]
        protected bool ifNotStaffOrAdmin;
        [SerializeField]
        protected bool ifCameraOperator;
        [SerializeField]
        protected bool ifNotCameraOperator;
        [SerializeField]
        protected bool ifCommunityAdmin;
        [SerializeField]
        protected bool ifNotCommunityAdmin;
        [SerializeField]
        protected bool ifPremium;
        [SerializeField]
        protected bool ifNotPremium;
        [SerializeField]
        protected bool ifSubscriptionPro;
        [SerializeField]
        protected bool ifNotSubscriptionPro;
        [SerializeField]
        protected bool ifSubscriptionEnterprise;
        [SerializeField]
        protected bool ifNotSubscriptionEnterprise;
        [SerializeField]
        protected bool ifSubscriptionLite;
        [SerializeField]
        protected bool ifNotSubscriptionLite;
        [SerializeField]
        protected bool ifDefaultGroupWhiteLabel;
        [SerializeField]
        protected bool ifNotDefaultGroupWhiteLabel;
        [SerializeField]
        protected bool ifDefaultGroupPremiumVoipEnabled;
        [SerializeField]
        protected bool ifNotDefaultGroupPremiumVoipEnabled;
    }
}
