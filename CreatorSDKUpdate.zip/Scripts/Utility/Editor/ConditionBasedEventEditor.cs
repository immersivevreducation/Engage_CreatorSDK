﻿using UnityEditor;

namespace Engage.Utility
{
    [CustomEditor(typeof(ConditionBasedEvent))]
    public class ConditionBasedEventEditor : AbstractConditionCheckEditor
    {

    }
}