using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;


namespace Engage.Utility
{
    public class AbstractConditionCheckEditor : Editor
    {
        private bool isEditing = false;
        private Dictionary<string, string> baseFields;
        private Dictionary<string, string> nonBaseFields;

        protected virtual void OnEnable()
        {
            baseFields = typeof(AbstractConditionCheck).GetFields(BindingFlags.DeclaredOnly | BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance)
                .Where(f => f.IsPublic || (!f.IsPublic && Attribute.IsDefined(f, typeof(SerializeField)))).Select(f => f.Name).ToDictionary(f => f);
            nonBaseFields = typeof(AbstractConditionCheck).GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance)
                .Where(f => !baseFields.ContainsKey(f.Name))
                .Where(f => f.IsPublic || (!f.IsPublic && Attribute.IsDefined(f, typeof(SerializeField)))).Select(f => f.Name).ToDictionary(f => f);
        }

        public override void OnInspectorGUI()
        {
            using (new EditorGUI.DisabledScope(true))
            {
                EditorGUILayout.PropertyField(serializedObject.FindProperty("m_Script"));
            }

            EditorGUILayout.Space();
            EditorGUILayout.LabelField("Conditions", EditorStyles.boldLabel);
            EditorGUILayout.Space();
            if (!isEditing)
            {
                DrawInspector(p => baseFields.ContainsKey(p.propertyPath) && p.propertyType == SerializedPropertyType.Boolean && p.boolValue,
                    p => EditorGUILayout.LabelField(p.displayName));

                EditorGUILayout.Space();
                if (GUILayout.Button("Edit"))
                {
                    isEditing = true;
                } 
            }
            else
            {
                DrawInspector(p => baseFields.ContainsKey(p.propertyPath) && p.propertyType == SerializedPropertyType.Boolean);

                EditorGUILayout.Space();
                if (GUILayout.Button("Collapse"))
                {
                    isEditing = false;
                }
            }
            DrawInspector(p => nonBaseFields.ContainsKey(p.propertyPath) || p.propertyType != SerializedPropertyType.Boolean);
        }

        internal bool DrawInspector(Func<SerializedProperty,bool> propertiesFilter, Action<SerializedProperty> drawer = null)
        {
            EditorGUI.BeginChangeCheck();
            serializedObject.UpdateIfRequiredOrScript();
            SerializedProperty iterator = serializedObject.GetIterator();
            iterator.NextVisible(true);
            while (iterator.NextVisible(false))
            {
                if ("m_Script" != iterator.propertyPath && propertiesFilter(iterator))
                {
                    if (drawer == null)
                    {
                        EditorGUILayout.PropertyField(iterator, true);
                    }
                    else
                    {
                        drawer(iterator);
                    }
                }
            }

            serializedObject.ApplyModifiedProperties();
            return EditorGUI.EndChangeCheck();
        }
    }
}