﻿using UnityEngine;
using UnityEngine.Events;

namespace Engage.Utility
{
    public class ConditionBasedEvent : AbstractConditionCheck
    {
        [Header("")]
        [Header("Event will fire if a specified condition is met")]
        [Header("Use function DoConditionBasedEvent")]
        [Header("")]
        public UnityEvent eventToInvoke;

        public void DoConditionBasedEvent(){}
    }
}
