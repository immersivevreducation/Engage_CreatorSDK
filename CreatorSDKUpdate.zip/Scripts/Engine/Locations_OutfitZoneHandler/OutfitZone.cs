﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class OutfitZone : MonoBehaviour
{
    public int outfit_override;
}
