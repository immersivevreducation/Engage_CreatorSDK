﻿using UnityEngine;

public class EditorOrMainAppGameObjectSwitch : MonoBehaviour {
    public GameObject[] editorOnlyObjects;
    public GameObject[] mainAppOnlyObjects;
    public GameObject[] offOnPhoneObjects;


}
