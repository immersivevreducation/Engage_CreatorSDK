﻿using UnityEngine;
using System.Collections;

public class GUIGamesSortingGamePickup : MonoBehaviour {
	public GameObject showObject;
	public string sortingGame;
	public string[] sortingGameItems;
}
