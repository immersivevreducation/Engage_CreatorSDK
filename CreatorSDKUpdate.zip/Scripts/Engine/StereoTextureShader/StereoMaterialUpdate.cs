using UnityEngine;

namespace Engage.Media
{
    public class StereoMaterialUpdate : MonoBehaviour
	{
        private void LateUpdate()
        {}

        public void SetRenderer(Renderer renderer)
        {}
    }
}
