using UnityEngine;

namespace Engage.IFX.Options
{

    public class PortalSpawnPoint : MonoBehaviour
    {
        public void SetIFXStringArgument(string argument){}
    }
}