using UnityEngine;
using UnityEngine.UI;

namespace Engage.IFX.Options
{
    public class SessionPortalEffect : MonoBehaviour
    {
        [Space]
        [Header("Required")]
        [SerializeField] 
        private Collider portalTrigger;
        [Space]
        [Header("Optional features")]
        [SerializeField]
        private Renderer rendererForImage;
        [SerializeField]
        private Text sessionNameText;
        [SerializeField]
        private GameObject[] deactivateObjectsIfError;
       

        private void Awake(){}

        public void SetIFXStringArgument(string argument){}

        public void TriggerPortalTransition(){}
    }
}
