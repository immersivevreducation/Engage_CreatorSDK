using System;
using Engage.IFX.Options;
using UnityEngine;

public class PortalTrigger : MonoBehaviour
{
    [SerializeField]
    public SessionPortalEffect portalEffectScript;

    private void Awake(){}
}