//using Engage.Core.DependencyInjection;
//using Engage;
using UnityEngine;
using UnityEngine.Events;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect/Grabable")]
    [RequireComponent(typeof(Collider))]
    public class IFXAnimationEffectsGrabableObject : MonoBehaviour
    {
        //[Inject] IPlatformConfig platformConfig;

        #region Inspector Properties
        [SerializeField]
        bool testingMode;
        [SerializeField]
        Transform testingTransform;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool maintainOffset;   
        [SerializeField]
        float maxMouseDistance = 5f;
        [SerializeField]
        bool resetOnRelease;
        [SerializeField]
        bool requireTriggerPress;
        [SerializeField]
        bool requireGrippedPress;
        
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool crankLikeRotation;
        [SerializeField]
        bool crankAround_X;
        [SerializeField]
        bool crankAround_Y;
        [SerializeField]
        bool crankAround_Z;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool radialMotionLimiter;
        [SerializeField]
        Transform centerPivot;
        [SerializeField]
        float radiusLimit;
        [SerializeField]
        bool poleAxis_X;
        [SerializeField]
        bool poleAxis_Y;
        [SerializeField]
        bool poleAxis_Z;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool AxisLimit_X;
        [SerializeField]
        Vector2 AxisLimitRange_X;
        [SerializeField]
        bool AxisLimit_Y;
        [SerializeField]
        Vector2 AxisLimitRange_Y;
        [SerializeField]
        bool AxisLimit_Z;
        [SerializeField]
        Vector2 AxisLimitRange_Z;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool rotatable;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        UnityEvent eventToFireWhenGrabbed;
        [SerializeField]
        UnityEvent eventToFireWhenReleased;




        #endregion
        #region Fields
        bool grabEventfired = false;
        bool releaseEventfired = false;
        //int primaryHand
        //{
        //    get { return ENG_TrackedMotionControllers.instance.primaryHand; }
        //}
        //int secondaryHand
        //{
        //    get { return ENG_TrackedMotionControllers.instance.secondaryHand; }
        //}
        //bool GrabbedByTwoHands
        //{
        //    get
        //    {
        //        if (rightHand != null && leftHand !=null)
        //        {
        //            if (rightHand.currentlyGrabbed && leftHand.currentlyGrabbed)
        //            {
        //                return true;
        //            }
        //        }
        //        return false;
        //    }
        //}
        GrabInfo holderObject;        
        public GrabInfo HolderObject
        {
            get
            {
                if (mouse != null)
                {
                    if (mouse.currentlyGrabbed)
                    {
                        holderObject = mouse;
                        return holderObject;
                    }
                }
                //if (GrabbedByTwoHands)
                //{
                //    holderObject = doubleHandGrab;
                //    return holderObject;
                //}
                
                if (rightHand != null)
                {
                    if (rightHand.currentlyGrabbed)
                    {
                        holderObject = rightHand;
                        return holderObject;
                    }
                } 
                if (leftHand != null)
                {
                    if (leftHand.currentlyGrabbed)
                    {
                        holderObject = leftHand;
                        return holderObject;
                    }
                }
                if (holderObject !=null)
                {
                    return holderObject;
                }
                return null;   
            }
        
        }

        Collider colliderOnTThis;
        Vector3 colliderOnTThis_Center;
        Vector3 restPosition;
        Vector3 restRotation;

        Vector3? lastCrankAngle;

        public bool initalized;
        //bool vrMode
        //{
        //    get { return Engage.ScriptHelper.using_vr; }
        //}
        //GrabInfo doubleHandGrab;
        GrabInfo rightHand;
        GrabInfo leftHand;
        GrabInfo mouse;
        #endregion

        // Start is called before the first frame update
        //void OnEnable()
        //{    
        //    if (Engage.ScriptHelper.mainCamera != null)
        //    {
        //        initalized = Initialize();
        //    }     
        //}
        //private bool Initialize()
        //{
        //    if (Engage.ScriptHelper.mainCamera == null)
        //    {
        //        return false;
        //    }
        //    colliderOnTThis = gameObject.GetComponent(typeof(Collider)) as Collider;
        //    colliderOnTThis_Center = IFXAE_Colliders.GetCollidersCentersByType(colliderOnTThis);
        //    if (centerPivot != null)
        //    {
        //        radiusLimit = Vector3.Distance(centerPivot.position, transform.position);
        //    }
        //    if (resetOnRelease)
        //    {
        //        restPosition = transform.localPosition;
        //        restRotation = transform.localEulerAngles;
        //    }

        //    if (vrMode)
        //    {
        //        if (rightHand == null)
        //        {
        //            rightHand = new GrabInfo();
        //            if (maintainOffset)
        //            {
        //                rightHand.offsetGO = new GameObject($"[{this.name}] handOffset - Right");
        //                rightHand.offsetGO.transform.SetParent(gameObject.transform);
        //            }
        //            holderObject = rightHand; // just to avoid null holderObject to start
        //        }
        //        if (leftHand == null)
        //        {
        //            leftHand = new GrabInfo();
        //            if (maintainOffset)
        //            {
        //                leftHand.offsetGO = new GameObject($"[{this.name}] handOffset - Left");
        //                leftHand.offsetGO.transform.SetParent(gameObject.transform);
        //            }
        //            holderObject = leftHand; // just to avoid null holderObject to start
        //        }
        //        //if (doubleHandGrab == null)
        //        //{
        //        //    doubleHandGrab = new GrabInfo();
        //        //    if (maintainOffset)
        //        //    {
        //        //        doubleHandGrab.offsetGO = new GameObject($"[{this.name}] handOffset - double Hand");
        //        //        doubleHandGrab.offsetGO.transform.SetParent(gameObject.transform);
        //        //    }
        //        //}

        //        if (ENG_TrackedMotionControllers.instance.controllerTransform[primaryHand] != null)
        //        {
        //            rightHand.transform = ENG_TrackedMotionControllers.instance.controllerTransform[primaryHand];
        //        }
        //        if (ENG_TrackedMotionControllers.instance.controllerTransform[secondaryHand] != null)
        //        {
        //            leftHand.transform = ENG_TrackedMotionControllers.instance.controllerTransform[secondaryHand];
        //        }

                
        //    }
        //    else if (mouse == null)
        //    {
        //        mouse = new GrabInfo();
        //        if (mouse.transform == null)
        //        {
        //            mouse.transform = new GameObject("handChild - Mouse").transform;
        //            mouse.transform.position = transform.position;
        //            mouse.transform.rotation = transform.rotation;
        //            mouse.transform.SetParent(Engage.ScriptHelper.mainCamera.transform, true);
        //        }
        //        holderObject = mouse; // just to avoid null holderObject to start
        //    }
            


            

            




        //    if (colliderOnTThis != null && Engage.ScriptHelper.mainCamera != null)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}
        
        //// Update is called once per frame
        //void LateUpdate()
        //{ 
        //    if (initalized == false) // re init if init failed, for example player not yet loaded into scene when script starts
        //    {
        //        initalized = Initialize();
        //        return;
        //    }

        //    if (vrMode)
        //    {
        //        VrGrabObject();
        //    }
        //    else
        //    {
        //        MouseGrabObject();
        //    }

        //    if (resetOnRelease && !HolderObject.currentlyGrabbed)
        //    {
        //        transform.localPosition = restPosition;
        //        transform.localEulerAngles = restRotation;
        //    }
        //    if (HolderObject !=null)
        //    {
        //        if (eventToFireWhenGrabbed != null) // fire an event once when grabbed
        //        {
        //            if (HolderObject.currentlyGrabbed)
        //            {
        //                if (grabEventfired == false)
        //                {
        //                    eventToFireWhenGrabbed.Invoke();
        //                    grabEventfired = true;
        //                }
        //            }
        //            else if (grabEventfired == true)
        //            {
        //                grabEventfired = false;
        //            }
        //        }
        //        if (eventToFireWhenReleased != null) // fire an event once when released
        //        {
        //            if (!HolderObject.currentlyGrabbed)
        //            {
        //                if (releaseEventfired == false)
        //                {
        //                    eventToFireWhenReleased.Invoke();
        //                    releaseEventfired = true;
        //                }
        //            }
        //            else if (releaseEventfired == true)
        //            {
        //                releaseEventfired = false;
        //            }
        //        }
        //    }
            

        //}

    
        
        //private void MouseGrabObject()
        //{
        //    if (Input.GetMouseButton(0))
        //    {
        //        if (mouse.transform != null && mouse.currentlyGrabbed)
        //        {  
        //            MoveObjectWithLimiters(mouse.transform);
        //            return;
        //        }

        //        Ray interaction_ray = new Ray(Engage.ScriptHelper.mainCamera.transform.position, Engage.ScriptHelper.mainCamera.transform.forward);
        //        RaycastHit hit;
        //        if (colliderOnTThis.Raycast(interaction_ray, out hit, maxMouseDistance))
        //        {  
        //            mouse.currentlyGrabbed = true;
        //            mouse.transform.position = transform.position;
        //            mouse.transform.rotation = transform.rotation;
        //        }
        //    }
        //    else
        //    {
        //        mouse.currentlyGrabbed = false;

        //        if (crankLikeRotation)
        //        {
        //            lastCrankAngle = Vector3.zero;
        //        }
        //    }
        //}

        //private void VrGrabObject()
        //{
        //    if (rightHand.transform == null)
        //    {
        //        rightHand.transform = ENG_TrackedMotionControllers.instance.controllerTransform[primaryHand];
        //    }
        //    if (leftHand.transform == null)
        //    {
        //        leftHand.transform = ENG_TrackedMotionControllers.instance.controllerTransform[secondaryHand];
        //    }


        //    rightHand.currentlyGrabbed = CheckIfGrabedVR(rightHand, primaryHand);
        //    leftHand.currentlyGrabbed = CheckIfGrabedVR(leftHand, secondaryHand);
        //    //if (GrabbedByTwoHands)
        //    //{
        //    //    MoveHeldObjectTwoHands();
        //    //}
        //    //else
        //    //{
        //        MoveHeldObject();
        //    //}
            

        //}
        ////private void MoveHeldObjectTwoHands()
        ////{
        ////    Vector3 midPoiintBetweenHands = rightHand.offsetGO.transform.position + (rightHand.offsetGO.transform.position - leftHand.offsetGO.transform.position) / 2;
        ////    doubleHandGrab.transform.position = midPoiintBetweenHands;
        ////    MoveObjectWithLimiters(doubleHandGrab.transform);
        ////}
        //private void MoveHeldObject()
        //{
        //    if (holderObject == null)
        //    {
        //        return;
        //    }
        //    if (holderObject.currentlyGrabbed)
        //    {
        //        if (maintainOffset)
        //        {
        //            if (holderObject.offsetGO != null)
        //            {
        //                if (holderObject.offsetGO.transform.parent == gameObject.transform)
        //                {
        //                    holderObject.offsetGO.transform.position = gameObject.transform.position;
        //                    holderObject.offsetGO.transform.rotation = gameObject.transform.rotation;
        //                    holderObject.offsetGO.transform.SetParent(holderObject.transform, true);
        //                    //Debug.Log($"[{rightHand.offsetGO.name}] Setting Right hand Parent: {rightHand.offsetGO.transform.parent}");
        //                    //Debug.Log($"Right hand offset: {rightHand.offset}");
        //                }
        //                MoveObjectWithLimiters(holderObject.offsetGO.transform);
        //                return;
        //            }
        //        }
        //        MoveObjectWithLimiters(holderObject.transform);
        //        return;
        //    }
        //    else if (maintainOffset)
        //    {
        //        if (holderObject.offsetGO != null)
        //        {
        //            holderObject.offsetGO.transform.SetParent(gameObject.transform);
        //        }
        //    }
    

        //    if (crankLikeRotation)
        //    {
        //        lastCrankAngle = Vector3.zero;
        //    }
        //}

        //private void MoveObjectWithLimiters(Transform handIN)
        //{
        //    if (crankLikeRotation)
        //    {
        //        if (crankAround_X)
        //        {
        //            CrankLikeRotation(handIN.transform, colliderOnTThis.transform.TransformDirection(Vector3.right));
        //            return;
        //        }
        //        if (crankAround_Y)
        //        {
        //            CrankLikeRotation(handIN.transform, colliderOnTThis.transform.TransformDirection(Vector3.up));
        //            return;
        //        }
        //        if (crankAround_Z)
        //        {
        //            CrankLikeRotation(handIN.transform, colliderOnTThis.transform.TransformDirection(Vector3.forward));
        //            return;
        //        }
        //    }

        //    if (radialMotionLimiter)
        //    {
        //        Vector3 centerpivot_Local = transform.parent.InverseTransformPoint(centerPivot.position);
        //        Vector3 handIN_Local = transform.parent.InverseTransformPoint(handIN.transform.position);
        //        float distanceToCenter = Vector3.Distance(centerpivot_Local, handIN_Local);
        //        Vector3 fromOriginToObject = centerpivot_Local - handIN_Local;
        //        fromOriginToObject *= radiusLimit / distanceToCenter;
        //        Vector3 Position3D = centerpivot_Local - fromOriginToObject;
        //        if (poleAxis_X)
        //        {
        //            Position3D.x = centerpivot_Local.x;
        //        }
        //        if (poleAxis_Y)
        //        {
        //            Position3D.y = centerpivot_Local.y;
        //        }
        //        if (poleAxis_Z)
        //        {
        //            Position3D.z = centerpivot_Local.z;
        //        }
        //        transform.localPosition = Position3D;
        //    }


        //    if (AxisLimit_X)
        //    {
        //        Vector3 LocalHandPos = transform.parent.InverseTransformPoint(handIN.position);
        //        LocalHandPos.x = Mathf.Clamp(LocalHandPos.x, Mathf.Min(AxisLimitRange_X.x, AxisLimitRange_X.y), Mathf.Max(AxisLimitRange_X.x, AxisLimitRange_X.y));
        //        transform.localPosition = new Vector3(LocalHandPos.x, transform.localPosition.y, transform.localPosition.z);
        //    }
        //    if (AxisLimit_Y)
        //    {

        //        Vector3 LocalHandPos = transform.parent.InverseTransformPoint(handIN.position);
        //        LocalHandPos.y = Mathf.Clamp(LocalHandPos.y, Mathf.Min(AxisLimitRange_Y.x, AxisLimitRange_Y.y), Mathf.Max(AxisLimitRange_Y.x, AxisLimitRange_Y.y));
        //        transform.localPosition = new Vector3(transform.localPosition.x, LocalHandPos.y, transform.localPosition.z);
        //    }
        //    if (AxisLimit_Z)
        //    {
        //        Vector3 LocalHandPos = transform.parent.InverseTransformPoint(handIN.position);
        //        LocalHandPos.z = Mathf.Clamp(LocalHandPos.z, Mathf.Min(AxisLimitRange_Z.x, AxisLimitRange_Z.y), Mathf.Max(AxisLimitRange_Z.x, AxisLimitRange_Z.y));
        //        transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, LocalHandPos.z);
        //    }

        //    if (rotatable)
        //    {
        //        transform.rotation = handIN.rotation;
        //    }

        //    if (!AxisLimit_X && !AxisLimit_Y && !AxisLimit_Z && !radialMotionLimiter)// this needs work!
        //    {
        //        transform.position = handIN.position;
        //    }        
        //}

        //private bool CheckIfGrabedVR(GrabInfo GrabInfoIN, int whichHand)
        //{
        //    if (GrabInfoIN.transform != null)
        //    {
        //        if (GrabInfoIN.currentlyGrabbed) // if the player hasn't let go yet skip checking for collision again.
        //        {
        //            if (requireTriggerPress && ENG_TrackedMotionControllers.instance.triggerPressed[whichHand])
        //            {
        //                return true;
        //            }
        //            if (requireGrippedPress && ENG_TrackedMotionControllers.instance.gripped[whichHand])
        //            {
        //                return true;
        //            }
        //        }
        //        if (IFXAE_Colliders.ColliderContainsPoint(colliderOnTThis, GrabInfoIN.transform.position))
        //        {

        //            if (requireTriggerPress && ENG_TrackedMotionControllers.instance.triggerPressed[whichHand])
        //            {
        //                return true;
        //            }
        //            if (requireGrippedPress && ENG_TrackedMotionControllers.instance.gripped[whichHand])
        //            {
        //                return true;
        //            }
        //            if (!requireTriggerPress && !requireGrippedPress)
        //            {
        //                return true;
        //            }
        //        }
        //    }
        //    return false;

        //}

        ////private bool ValueIsBetween(float testValue, float bound1, float bound2)
        ////{
        ////    return (testValue >= Math.Min(bound1, bound2) && testValue <= Math.Max(bound1, bound2));
        ////}

        //private void CrankLikeRotation(Transform handIn, Vector3 axisOfRotation)
        //{
        //    Vector3 handPos_Projected = Vector3.ProjectOnPlane(handIn.position - colliderOnTThis.transform.TransformPoint(colliderOnTThis_Center), axisOfRotation);

        //    //debugHand = colliderOnTThis.transform.position + handPos_Projected;

        //    if (lastCrankAngle.HasValue)
        //    {
        //        //float direction = Vector3.Dot(Vector3.Cross(lastCrankAngle, currentCrankAngle).normalized , colliderOnTThis.transform.TransformPoint(colliderOnTThis_Center + axisOfRotation).normalized );
        //        float amountToRotatate = Vector3.Angle(handPos_Projected, lastCrankAngle.Value);
        //        float direction = Vector3.Dot(Vector3.Cross(handPos_Projected, lastCrankAngle.Value).normalized, axisOfRotation);
        //        //Debug.Log(direction);

        //        transform.Rotate(axisOfRotation, amountToRotatate * -direction, Space.World);
        //    }

        //    lastCrankAngle = handPos_Projected;
        //}
        
        
        //private void OnDestroy()
        //{
        //    if (mouse.transform.gameObject != null)
        //    {
        //        Destroy(mouse.transform.gameObject);
        //    }
        //    if (rightHand.offsetGO != null)
        //    {
        //        Destroy(rightHand.offsetGO);
        //    }
        //    if (leftHand.offsetGO != null)
        //    {
        //        Destroy(leftHand.offsetGO);
        //    }

        //}
    }
    public class GrabInfo
    {
        public bool currentlyGrabbed;
        public Transform transform;
        public GameObject offsetGO;
    }
}

//private void OnDrawGizmos()
//{
//    //if (floorCollider != null)
//    //{
//    //    Gizmos.color = Color.green;
//    //    Gizmos.DrawCube(floorCollider.position, floorCollider.localScale);
//    //    Gizmos.color = Color.white;
//    //}

//    DrawSphere(lastCrankAngle, Color.red, 0.6f);
//    DrawSphere(debugHand, Color.green, 0.6f);

//}
//private void DrawSphere(Vector3 pos, Color colour, float size = .06f)
//{
//    Gizmos.color = colour;

//    Gizmos.DrawSphere(pos, size);

//    Gizmos.color = Color.white;
//}




