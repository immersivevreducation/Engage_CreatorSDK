//using Engage.Core.DependencyInjection;
//using Engage;
using UnityEngine;
using UnityEngine.Events;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect/Grabable")]
    [RequireComponent(typeof(Collider))]
    public class IFXAnimationEffectsGrabableObject : MonoBehaviour
    {
        

        #region Inspector Properties
        [SerializeField]
        bool testingMode;
        [SerializeField]
        Transform testingTransform;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool maintainOffset;   
        [SerializeField]
        float maxMouseDistance = 5f;
        [SerializeField]
        bool resetOnRelease;
        [SerializeField]
        bool requireTriggerPress;
        [SerializeField]
        bool requireGrippedPress;
        
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool crankLikeRotation;
        [SerializeField]
        bool crankAround_X;
        [SerializeField]
        bool crankAround_Y;
        [SerializeField]
        bool crankAround_Z;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool radialMotionLimiter;
        [SerializeField]
        Transform centerPivot;
        [SerializeField]
        float radiusLimit;
        [SerializeField]
        bool poleAxis_X;
        [SerializeField]
        bool poleAxis_Y;
        [SerializeField]
        bool poleAxis_Z;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool AxisLimit_X;
        [SerializeField]
        Vector2 AxisLimitRange_X;
        [SerializeField]
        bool AxisLimit_Y;
        [SerializeField]
        Vector2 AxisLimitRange_Y;
        [SerializeField]
        bool AxisLimit_Z;
        [SerializeField]
        Vector2 AxisLimitRange_Z;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool rotatable;
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        UnityEvent eventToFireWhenGrabbed;
        [SerializeField]
        UnityEvent eventToFireWhenReleased;




        #endregion
        #region Fields
        bool grabEventfired = false;
        bool releaseEventfired = false;
        //int primaryHand
        //{
        //    get { return ENG_TrackedMotionControllers.instance.primaryHand; }
        //}
        //int secondaryHand
        //{
        //    get { return ENG_TrackedMotionControllers.instance.secondaryHand; }
        //}
        //bool GrabbedByTwoHands
        //{
        //    get
        //    {
        //        if (rightHand != null && leftHand !=null)
        //        {
        //            if (rightHand.currentlyGrabbed && leftHand.currentlyGrabbed)
        //            {
        //                return true;
        //            }
        //        }
        //        return false;
        //    }
        //}
        GrabInfo holderObject;        
        public GrabInfo HolderObject
        {
            get
            {
                if (mouse != null)
                {
                    if (mouse.currentlyGrabbed)
                    {
                        holderObject = mouse;
                        return holderObject;
                    }
                }
                //if (GrabbedByTwoHands)
                //{
                //    holderObject = doubleHandGrab;
                //    return holderObject;
                //}
                
                if (rightHand != null)
                {
                    if (rightHand.currentlyGrabbed)
                    {
                        holderObject = rightHand;
                        return holderObject;
                    }
                } 
                if (leftHand != null)
                {
                    if (leftHand.currentlyGrabbed)
                    {
                        holderObject = leftHand;
                        return holderObject;
                    }
                }
                if (holderObject !=null)
                {
                    return holderObject;
                }
                return null;   
            }
        
        }

        Collider colliderOnTThis;
        Vector3 colliderOnTThis_Center;
        Vector3 restPosition;
        Vector3 restRotation;

        Vector3? lastCrankAngle;

        public bool initalized;
        //bool vrMode
        //{
        //    get { return Engage.ScriptHelper.using_vr; }
        //}
        //GrabInfo doubleHandGrab;
        GrabInfo rightHand;
        GrabInfo leftHand;
        GrabInfo mouse;
        #endregion

        
    }
    public class GrabInfo
    {
        public bool currentlyGrabbed;
        public Transform transform;
        public GameObject offsetGO;
    }
}






