using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine;

public class IFXAttachObjectToPlayerBody : MonoBehaviour
{

    //private LVR_FPC_PlayerSync playerSync;
    //LVR_FPC_PlayerSync PlayerSync
    //{
    //    get 
    //    {
    //        if (playerSync == null && LVR_FPC_PlayerSync.LocalPlayer != null)
    //        {             
    //            playerSync = LVR_FPC_PlayerSync.LocalPlayer; 
    //        }
    //        return playerSync;
    //    }
        
    //}



    /// ////////////////////////

    [SerializeField]
    GameObject objectToAttach;

    [SerializeField]
    bool useParenting;
    [Space]
    [SerializeField]
    bool allowOffset;
    [Header("--------------------------------------------------------------")]
    [SerializeField]
    bool attachToBodyPartWhenClose;
    [SerializeField]
    float attachDistance;
    [SerializeField]
    bool lockWhenAttached;
    [Space]
    [SerializeField]
    UnityEvent eventToFireWhenAttaching;
    [SerializeField]
    UnityEvent eventToFireWhenDetaching;

    public enum TargetBodyParts
    {
        none,
        Any,
        playerRoot,
        playerHead,
        playerChest,
        playerHips,
        playerHandL,
        playerHandR,       
        playerFootL, 
        playerFootR
    }
    [Header("--------------------------------------------------------------")]
    [SerializeField]
    TargetBodyParts bodyPart;
    Transform chosenBodyPartTransform;
    Transform oldParent;
    List<Transform> bodypartTransforms;
    Vector3 followOffsetPos;
    Vector3 followOffsetUp;
    Vector3 followOffsetFw;

    bool currentlyAttached = false;
    
}
