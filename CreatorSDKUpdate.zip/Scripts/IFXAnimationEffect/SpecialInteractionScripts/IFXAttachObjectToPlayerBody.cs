using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine;

public class IFXAttachObjectToPlayerBody : MonoBehaviour
{

    //private LVR_FPC_PlayerSync playerSync;
    //LVR_FPC_PlayerSync PlayerSync
    //{
    //    get 
    //    {
    //        if (playerSync == null && LVR_FPC_PlayerSync.LocalPlayer != null)
    //        {             
    //            playerSync = LVR_FPC_PlayerSync.LocalPlayer; 
    //        }
    //        return playerSync;
    //    }
        
    //}



    /// ////////////////////////

    [SerializeField]
    GameObject objectToAttach;

    [SerializeField]
    bool useParenting;
    [Space]
    [SerializeField]
    bool allowOffset;
    [Header("--------------------------------------------------------------")]
    [SerializeField]
    bool attachToBodyPartWhenClose;
    [SerializeField]
    float attachDistance;
    [SerializeField]
    bool lockWhenAttached;
    [Space]
    [SerializeField]
    UnityEvent eventToFireWhenAttaching;
    [SerializeField]
    UnityEvent eventToFireWhenDetaching;

    public enum TargetBodyParts
    {
        none,
        Any,
        playerRoot,
        playerHead,
        playerChest,
        playerHips,
        playerHandL,
        playerHandR,       
        playerFootL, 
        playerFootR
    }
    [Header("--------------------------------------------------------------")]
    [SerializeField]
    TargetBodyParts bodyPart;
    Transform chosenBodyPartTransform;
    Transform oldParent;
    List<Transform> bodypartTransforms;
    Vector3 followOffsetPos;
    Vector3 followOffsetUp;
    Vector3 followOffsetFw;

    bool currentlyAttached = false;
    //void Start() // may need changes to work as part of a scene where no player has loaded yet
    //{
    //    if (bodyPart == TargetBodyParts.Any)
    //    {
    //        bodypartTransforms = new List<Transform>();
    //        foreach (TargetBodyParts parts in TargetBodyParts.GetValues(typeof(TargetBodyParts)))
    //        {
    //            if (parts == TargetBodyParts.Any || parts == TargetBodyParts.playerRoot || parts == TargetBodyParts.none)
    //            {
    //                continue;
    //            }
    //            //Debug.Log("adding body part : " + parts);
    //            bodypartTransforms.Add(GetPlayerBodypartTransformRefrence(parts));
    //        }
    //        chosenBodyPartTransform = ClosestBodyPart();
    //    }
    //    else
    //    {
    //        chosenBodyPartTransform = GetPlayerBodypartTransformRefrence(bodyPart);
    //    }
    //    oldParent = objectToAttach.transform.parent;
        

    //    if (useParenting && !attachToBodyPartWhenClose)
    //    {
    //        MakeChildOfBodyPart();
    //    }
        
    //}

    //// Update is called once per frame
    //void Update()
    //{
    //    if (oldParent == null)
    //    {
    //        Destroy(objectToAttach);
    //    }
    //    if (bodyPart == TargetBodyParts.Any)
    //    {
    //        chosenBodyPartTransform = ClosestBodyPart();
    //    }

    //    if (attachToBodyPartWhenClose)
    //    {
    //        if (currentlyAttached == false)
    //        {
    //            AttachToBodyPartWhenClose();
    //        }
    //        else if(!lockWhenAttached)
    //        {
    //            if ((objectToAttach.transform.position - chosenBodyPartTransform.position).sqrMagnitude > attachDistance+0.05f)
    //            {
    //                DetechObject();
    //            }
    //        }
    //    }
    //    else
    //    {
    //        AttachObject();
    //    }
        


    //    if (!useParenting)
    //    {
    //        if (currentlyAttached == true)
    //        {
    //            FollowBodyPart();
    //        }
    //    }
    //}
    //Transform ClosestBodyPart()
    //{
    //    Transform closestPart = bodypartTransforms[0];
    //    float lastDistance = 100f;
    //    foreach (var part in bodypartTransforms)
    //    {
    //        //Debug.Log("checking for closest part: " + part.name);
    //        float distance = (objectToAttach.transform.position - part.position).sqrMagnitude;
    //        if (distance < lastDistance)
    //        {
    //            closestPart = part;
    //            lastDistance = distance;
    //        }
    //    }
    //    return closestPart;


    //}

    //void FollowBodyPart()
    //{
    //    if (allowOffset)
    //    {
    //        var newpos = chosenBodyPartTransform.TransformPoint(followOffsetPos);
    //        var newfw = chosenBodyPartTransform.TransformDirection(followOffsetFw);
    //        var newup = chosenBodyPartTransform.TransformDirection(followOffsetUp);
    //        var newrot = Quaternion.LookRotation(newfw, newup);
    //        transform.position = newpos;
    //        transform.rotation = newrot;
    //    }
    //    else
    //    {
    //        objectToAttach.transform.position = chosenBodyPartTransform.position;
    //        objectToAttach.transform.rotation = chosenBodyPartTransform.rotation;
    //    }

    //}
    //void MakeChildOfBodyPart()
    //{
    //    currentlyAttached = true;
    //    if (allowOffset)
    //    {
    //        objectToAttach.transform.SetParent(chosenBodyPartTransform, true);
    //    }
    //    else
    //    {
    //        objectToAttach.transform.SetParent(chosenBodyPartTransform);
    //    }
        
    //}
    //public void AttachToBodyPartWhenClose()
    //{
    //    if (Vector3.Distance(objectToAttach.transform.position, chosenBodyPartTransform.position) < attachDistance)
    //    {        
    //            AttachObject(); 
    //    }     
    //}
    //Transform GetPlayerBodypartTransformRefrence(TargetBodyParts bodypartIN)
    //{
    //    Transform bodyPartTransform = null;
    //    switch (bodypartIN)
    //    {
    //        default:
    //            bodyPartTransform = null;
    //            break;
    //        case TargetBodyParts.playerRoot:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.gameObject.transform;
    //            }

    //            break;
    //        case TargetBodyParts.playerHead:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.headTarget.transform;
    //            }

    //            break;
    //        case TargetBodyParts.playerChest:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.chestTarget.transform;
    //            }

    //            break;
    //        case TargetBodyParts.playerHips:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.hipTarget.transform;
    //            }

    //            break;
    //        case TargetBodyParts.playerHandL:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.leftHandPositionOffsetTarget.transform;
    //            }
    //            break;
    //        case TargetBodyParts.playerHandR:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.rightHandPositionOffsetTarget.transform;
    //            }
    //            break;
    //        case TargetBodyParts.playerFootL:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.leftFootTarget.transform;
    //            }
    //            break;
    //        case TargetBodyParts.playerFootR:
    //            if (PlayerSync != null)
    //            {
    //                bodyPartTransform = PlayerSync.rightFootTarget.transform;
    //            }
    //            break;
    //        case TargetBodyParts.Any:               
    //            break;
    //    }
    //    return bodyPartTransform;
    //}
    //private void OnDestroy()
    //{
    //    if (oldParent != null)
    //    {
    //        objectToAttach.transform.SetParent(oldParent);
    //    }
    //    else
    //    {
    //        Destroy(objectToAttach);
    //    }
        
    //}
    //private void OnDisable()
    //{
    //    if (oldParent != null)
    //    {
    //        objectToAttach.transform.SetParent(oldParent);
    //    }
    //}
    //public void DetechObject()
    //{
    //    if (currentlyAttached == true)
    //    {
    //        currentlyAttached = false;
    //        if (eventToFireWhenDetaching != null)
    //        {
    //            eventToFireWhenDetaching.Invoke();
    //        }
    //        if (useParenting)
    //        {
    //            objectToAttach.transform.SetParent(oldParent,true);
    //        }
    //    }
        
    //}
    //public void AttachObject()
    //{
    //    if (currentlyAttached == false)
    //    {
    //        currentlyAttached = true;
    //        if (eventToFireWhenAttaching != null)
    //        {
    //            eventToFireWhenAttaching.Invoke();              
    //        }
    //        if (useParenting)
    //        {
    //            MakeChildOfBodyPart();
    //            return;
    //        }
    //        if (allowOffset)
    //        {
    //            followOffsetPos = chosenBodyPartTransform.transform.InverseTransformPoint(transform.position);
    //            followOffsetFw = chosenBodyPartTransform.transform.InverseTransformDirection(transform.forward);
    //            followOffsetUp = chosenBodyPartTransform.transform.InverseTransformDirection(transform.up);
    //        }
    //    }
        
    //}
}
