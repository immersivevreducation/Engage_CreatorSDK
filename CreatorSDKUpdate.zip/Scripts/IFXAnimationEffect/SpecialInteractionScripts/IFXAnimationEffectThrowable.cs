using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect/Throwable")]
    [RequireComponent(typeof(IFXAnimationEffectsGrabableObject))]
    [RequireComponent(typeof(Rigidbody))]
    public class IFXAnimationEffectThrowable : MonoBehaviour
    {
        Queue<Vector3> vectorsOverTime = new Queue<Vector3>();
        Queue<Vector3> rotationOverTime = new Queue<Vector3>();
        Rigidbody rigidBodySelf;
        IFXAnimationEffectsGrabableObject grabableObject;
        [SerializeField]
        float throwStrength = 1;
        [SerializeField]
        bool useObjectMass = false;

        Vector3 throwVector;
        Vector3 rotVector;
        int throwCalcCount;
        Vector3 lastPos;
        Vector3 lastRot;
        // Start is called before the first frame update
        void Start()
        {
            rigidBodySelf = gameObject.GetComponent<Rigidbody>();
            grabableObject = gameObject.GetComponent<IFXAnimationEffectsGrabableObject>();
        }

        // Update is called once per frame
        void FixedUpdate()
        {
            if (grabableObject.initalized)
            {
                if (grabableObject.HolderObject == null)
                {
                    return;
                }
                if (grabableObject.HolderObject.currentlyGrabbed)
                {
                    rigidBodySelf.velocity = Vector3.zero;
                    rigidBodySelf.angularVelocity = Vector3.zero;
                    throwVector = CalculateThrowVector();
                    rotVector = CalculateThrowRotation();
                    //rigidBodySelf.isKinematic = true;
                }
                if (!grabableObject.HolderObject.currentlyGrabbed)
                {

                    //rigidBodySelf.isKinematic = false;
                    //throwVector = CalculateThrow();
                    if (rotVector != Vector3.zero)
                    {
                        if (useObjectMass)
                        {
                            rigidBodySelf.AddTorque(rotVector * throwStrength, ForceMode.Impulse);
                        }
                        else
                        {
                            rigidBodySelf.AddTorque(rotVector * throwStrength, ForceMode.VelocityChange);
                        }

                        rotVector = Vector3.zero;
                        rotationOverTime.Clear();
                        //Debug.Log("throw vector " + throwVector);
                    }
                    if (throwVector != Vector3.zero)
                    {
                        if (useObjectMass)
                        {
                            rigidBodySelf.AddForce(throwVector * throwStrength, ForceMode.Impulse);  
                        }
                        else
                        {                            
                            rigidBodySelf.AddForce(throwVector * throwStrength, ForceMode.VelocityChange);   
                        }
                        
                        throwVector = Vector3.zero;
                        vectorsOverTime.Clear();
                        //Debug.Log("throw vector " + throwVector);
                    }
                    
                }
            }
            
        }
        Vector3 CalculateThrowVector()
        {

            Vector3 velocity = (gameObject.transform.position - lastPos) / Time.deltaTime;
            //Vector3 angleVelocity = gameObject.transform.localEulerAngles - lastRot;
            //Vector3 offsetFromHand = gameObject.transform.position - handIN.position;  
            vectorsOverTime.Enqueue(velocity);
            if (vectorsOverTime.Count > 10)
            {
                vectorsOverTime.Dequeue();
            }


            Vector3 sum = new Vector3();
            foreach (var item in vectorsOverTime)
            {
                sum += item;
            }
            lastPos = gameObject.transform.position;
            //Debug.Log("velocity " + velocity);
            //Debug.Log("angleVelocity " + angleVelocity);
            //Debug.Log("average " + sum / vectorsOverTime.Count);
            return sum / vectorsOverTime.Count;        
        }
        Vector3 CalculateThrowRotation()
        {

            Vector3 velocity = (gameObject.transform.eulerAngles - lastRot) / Time.deltaTime;
            //Vector3 angleVelocity = gameObject.transform.localEulerAngles - lastRot;
            //Vector3 offsetFromHand = gameObject.transform.position - handIN.position;  
            rotationOverTime.Enqueue(velocity);
            if (rotationOverTime.Count > 10)
            {
                rotationOverTime.Dequeue();
            }


            Vector3 sum = new Vector3();
            foreach (var item in rotationOverTime)
            {
                sum += item;
            }
            lastRot = gameObject.transform.localEulerAngles;
            //Debug.Log("velocity " + velocity);
            //Debug.Log("angleVelocity " + angleVelocity);
            //Debug.Log("average " + sum / vectorsOverTime.Count);
            return sum / rotationOverTime.Count;
        }
    }
}
