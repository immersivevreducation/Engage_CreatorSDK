using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect/Throwable")]
    [RequireComponent(typeof(IFXAnimationEffectsGrabableObject))]
    [RequireComponent(typeof(Rigidbody))]
    public class IFXAnimationEffectThrowable : MonoBehaviour
    {
        
        [SerializeField]
        float throwStrength = 1;
        [SerializeField]
        bool useObjectMass = false;

    }
}
