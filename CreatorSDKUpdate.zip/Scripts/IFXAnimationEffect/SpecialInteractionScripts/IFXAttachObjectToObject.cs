using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine;

public class IFXAttachObjectToObject : MonoBehaviour
{
    /// ////////////////////////

    [SerializeField]
    GameObject objectToAttachToTarget;
    [SerializeField]
    List<GameObject> targetObjects = new List<GameObject>();

    [SerializeField]
    bool useParenting;
    [Space]
    [SerializeField]
    bool allowOffset;
    [Header("--------------------------------------------------------------")]
    [SerializeField]
    bool attachToTargetWhenClose;
    [SerializeField]
    float attachDistance;
    [SerializeField]
    bool lockWhenAttached;
    [Space]
    [SerializeField]
    UnityEvent eventToFireWhenAttaching;
    [SerializeField]
    UnityEvent eventToFireWhenDetaching;

    [Header("--------------------------------------------------------------")]    
    Transform oldParent;

    bool currentlyAttached = false;

    Vector3 followOffsetPos;
    Vector3 followOffsetUp;
    Vector3 followOffsetFw;

    void OnEnable() // may need changes to work as part of a scene where no player has loaded yet
    {
        oldParent = objectToAttachToTarget.transform.parent;
        if (useParenting && !attachToTargetWhenClose)
        {
            MakeChildOfTarget();
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        if (oldParent == null)
        {
            Destroy(objectToAttachToTarget);
        }
        if (objectToAttachToTarget == null || targetObjects == null)
        {
            return;
        }

        if (attachToTargetWhenClose)
        {
            if (currentlyAttached == false)
            {
                AttachToTargetWhenClose();
            }
            else if(!lockWhenAttached)
            {
                if ((objectToAttachToTarget.transform.position - ClosestTargetObject().position).sqrMagnitude > attachDistance + 0.05f) //detach object if to far away
                {
                    DetechObject();
                }
            }
        }
        else
        {
            AttachObject();
        }
        


        if (!useParenting)
        {
            if (currentlyAttached == true)
            {
                FollowTargetObject();
            }
        }
    }
    Transform ClosestTargetObject()
    {
        Transform closestTarget = targetObjects[0].transform;
        if (targetObjects.Count>1)
        {
            float lastDistance = 100f;
            foreach (var target in targetObjects)
            {
                // Debug.Log("checking for closest part: " + target.name);
                float distance = (objectToAttachToTarget.transform.position - target.transform.position).sqrMagnitude;
                if (distance < lastDistance)
                {
                    closestTarget = target.transform;
                    lastDistance = distance;
                }
            }
        }
        return closestTarget;


    }
 
    void FollowTargetObject()
    {
        Transform closestTarget = ClosestTargetObject();
        if (allowOffset)
        {
            
            var newpos = closestTarget.TransformPoint(followOffsetPos);
            var newfw = closestTarget.TransformDirection(followOffsetFw);
            var newup = closestTarget.TransformDirection(followOffsetUp);
            var newrot = Quaternion.LookRotation(newfw, newup);
            transform.position = newpos;
            transform.rotation = newrot;
        }
        else
        {
            objectToAttachToTarget.transform.position = closestTarget.position;
            objectToAttachToTarget.transform.rotation = closestTarget.rotation;
        }
        
    }
    private void MakeChildOfTarget()
    {
        currentlyAttached = true;
        if (allowOffset)
        {
            objectToAttachToTarget.transform.SetParent(ClosestTargetObject(), true);
        }
        else
        {
            objectToAttachToTarget.transform.SetParent(ClosestTargetObject());
        }
        
    }
    public void AttachToTargetWhenClose()
    {
        if ((objectToAttachToTarget.transform.position - ClosestTargetObject().position).sqrMagnitude < attachDistance)
        {                  
            AttachObject();   
        }     
    }
    
    private void OnDestroy()
    {
        if (oldParent != null)
        {
            objectToAttachToTarget.transform.SetParent(oldParent);
        }
        else
        {
            Destroy(objectToAttachToTarget);
        }
        
    }
    private void OnDisable()
    {
        if (oldParent != null)
        {
            objectToAttachToTarget.transform.SetParent(oldParent);
        }
    }
    public void DetechObject()
    {
        if (currentlyAttached == true)
        {
            currentlyAttached = false;
            if (eventToFireWhenDetaching != null)
            {
                eventToFireWhenDetaching.Invoke();
            }
            if (useParenting)
            {
                objectToAttachToTarget.transform.SetParent(oldParent,true);
            }
        }
        
    }
    public void AttachObject()
    {
        if (currentlyAttached == false)
        {
            currentlyAttached = true;
            if (eventToFireWhenAttaching != null)
            {
                eventToFireWhenAttaching.Invoke();
            }
            if (useParenting)
            {
                MakeChildOfTarget();
                return;
            }
            if (allowOffset)
            {
                Transform closestTarget = ClosestTargetObject();
                followOffsetPos = closestTarget.transform.InverseTransformPoint(transform.position);
                followOffsetFw = closestTarget.transform.InverseTransformDirection(transform.forward);
                followOffsetUp = closestTarget.transform.InverseTransformDirection(transform.up);
            }
        }
        
    }
}
