using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Sine - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Sine_Module : IFXAnimEffect_SEND_Module
    {
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool sinePositiveOnly = false;
        [SerializeField]
        float sineFreq = 1;
        [SerializeField]
        float sineAmp = 1;
        [SerializeField]
        IFXAnimationEffectFloatVariable sineFreqInput;
        [SerializeField]
        IFXAnimationEffectFloatVariable sineAmpInput;
        //////////////////////////////////

        private void OnEnable()
        {
            if (sineFreqInput != null || sineAmpInput != null)
            {
                UpdateValues += GetSineFromInput;
            }
            else
            {
                UpdateValues += GetSine;
            }
        }
        ///////////////////////////////////////////////

        private float GetSine()
        {
            int sinePositiveOnlyINT = 0;
            if (sinePositiveOnly)
            {
                sinePositiveOnlyINT = 1;
            }

            float output = sineAmp * Mathf.Sin(Time.time * sineFreq) + sinePositiveOnlyINT;

            return output;
        }
        private float GetSineFromInput()
        {
            int sinePositiveOnlyINT = 0;
            float amp = sineAmp;
            float freq = sineFreq;
            if (sinePositiveOnly)
            {
                sinePositiveOnlyINT = 1;
            }
            if (sineAmpInput != null)
            {
                amp = sineAmpInput.GetMathOutput();
            }
            if (sineFreqInput != null)
            {
                freq = sineFreqInput.GetMathOutput();
            }
            float output = amp * Mathf.Sin(Time.time * freq) + sinePositiveOnlyINT;

            return output;
        }
    }
}
