using UnityEngine;
using System.Collections.Generic;
//using Engage.Core.DependencyInjection;
//using Engage;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Player - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Player_Module : IFXAnimEffect_SEND_Module
    {
        
        //[Inject] IPlatformConfig platformConfig;
        Camera playerCamera = null;
        //Camera PlayerCamera
        //{
        //    get
        //    {
        //        if (playerCamera == null)
        //        {
        //            if (Engage.ScriptHelper.mainCamera != null)
        //            {
        //                playerCamera = Engage.ScriptHelper.mainCamera;
        //            } 
        //        }
        //        return playerCamera;
        //    }
        //}
        [Header("Float Based----------------------------------------------------")]
        [SerializeField]
        bool from_PlayerPositon_X;
        [SerializeField]
        bool from_PlayerPositon_Y;
        [SerializeField]
        bool from_PlayerPositon_Z;

        //////////////////////    
        [SerializeField]
        bool from_PlayerRotation_X;
        [SerializeField]
        bool from_PlayerRotation_Y;
        [SerializeField]
        bool from_PlayerRotation_Z;

        ///////////////////////
        ///
        [Space]
        [SerializeField]
        bool from_PlayerDistance;

        [SerializeField]
        Transform playerDistanceTarget;
        ///////////////////////
        [Space]
        [SerializeField]
        bool from_PlayerHandDistance;

        [SerializeField]
        Transform playerHandDistanceTarget;

        ////////////////////////
        [Header("Trigger Based----------------------------------------------------")]
        [Space]
        ///////////////////////
        
        [SerializeField]
        bool from_PlayerCollision;
        ColliderObserver colliderObserver;
        
        ///////////////////////
        [Space]
        [SerializeField]
        bool from_PlayerTouch;
        [SerializeField]
        float mouseTouchRange = 5;
        
        [SerializeField]
        bool requireTriggerPress;
        [SerializeField]
        bool requireGrippedPress;
        [Space]
        [Header("Set Colliders for functions that require them here")]
        [SerializeField]
        IFXAE_Colliders aeColliders;

        /// 
        
        //Transform primaryHandTransform;
        //Transform PrimaryHandTransform
        //{
        //    get
        //    {
        //        if (primaryHandTransform != null)
        //        {
        //            return primaryHandTransform;
        //        }
        //        else if (ENG_TrackedMotionControllers.instance.controllerTransform[ENG_TrackedMotionControllers.instance.primaryHand] != null)
        //        {
        //            primaryHandTransform = ENG_TrackedMotionControllers.instance.controllerTransform[ENG_TrackedMotionControllers.instance.primaryHand];
        //            return primaryHandTransform;
        //        }
        //        return null;
        //    }
        //}
        //Transform secondaryHandTransform;
        //Transform SecondaryHandTransform
        //{
        //    get
        //    {
        //        if (secondaryHandTransform != null)
        //        {  
        //            return secondaryHandTransform;
        //        }
        //        else if (ENG_TrackedMotionControllers.instance.controllerTransform[ENG_TrackedMotionControllers.instance.secondaryHand] != null)
        //        {
        //            secondaryHandTransform = ENG_TrackedMotionControllers.instance.controllerTransform[ENG_TrackedMotionControllers.instance.secondaryHand];
        //            return secondaryHandTransform;
        //        }
        //        return null;
        //    }
        //}
        //private void OnEnable()
        //{
        //    Setup();
        //}
        //private void OnDisable()
        //{
        //    UpdateValues = null;
        //    if (colliderObserver != null)
        //    {
        //        Destroy(colliderObserver);
        //    }
            
        //}
        
        //public override void Setup()
        //{          
        //    if (PlayerCamera != null)
        //    {
                
        //        if (from_PlayerPositon_X)
        //        {     
        //                UpdateValues += GetPlayerPosition_X;
        //        }
        //        if (from_PlayerPositon_Y)
        //        { 
        //                UpdateValues += GetPlayerPosition_Y;
        //        }
        //        if (from_PlayerPositon_Z)
        //        {
                    
        //                UpdateValues += GetPlayerPosition_Z;
                    
        //        }
        //        //////////////////////////
        //        if (from_PlayerRotation_X)
        //        {
                   
        //                UpdateValues += GetPlayerRotation_X;
                    
        //        }
        //        if (from_PlayerRotation_Y)
        //        {
                    
        //                UpdateValues += GetPlayerRotation_Y;
                    
        //        }
        //        if (from_PlayerRotation_Z)
        //        {
                    
        //                UpdateValues += GetPlayerRotation_Z;
                    
        //        }
        //        //////////////////////////
        //        if (from_PlayerDistance)
        //        {
        //            if (playerDistanceTarget != null)
        //            {
        //                UpdateValues += GetPlayerDistance;
        //            }
        //            else
        //            {
        //                Debug.Log($"AnimationEffect: [{this.name}] From player distance selected but player distance target input empty");
        //            }
        //        }
        //        if (from_PlayerHandDistance)
        //        {

        //            if (playerHandDistanceTarget != null)
        //            {                   
        //                UpdateValues += GetPlayerHandDistance;
        //            }
        //            else
        //            {
        //                Debug.Log($"AnimationEffect: [{this.name}] From player hand distance selected but player distance target input empty");                 
        //            }
        //        }

        //        //////////////////////////
        //        if (from_PlayerTouch)
        //        {
        //            if (aeColliders == null)
        //            {
        //                //Debug.Log($" [{this.name}] - Anim effect - trying to add to ae colliders : {gameObject}");
        //                aeColliders = new IFXAE_Colliders(gameObject);
        //            }
        //            else
        //            {
        //                //Debug.Log($" [{this.name}] - Anim effect - trying to add to ae colliders : {gameObject} {aeColliders !=null }");
        //                aeColliders.Init(gameObject);
        //            }

        //            if (Engage.ScriptHelper.using_vr && ENG_TrackedMotionControllers.instance != null)
        //            {
        //                UpdateValues += GetPlayerTouchedVR;
        //            }
        //            else
        //            {
        //                UpdateValues += GetPlayerTouchedMouse;
        //            }
        //        }
        //        //////////////////////////
        //        if (from_PlayerCollision)
        //        {
        //            if (aeColliders == null)
        //            {
        //                //Debug.Log($" [{this.name}] - Anim effect - trying to add to ae colliders : {gameObject}");
        //                aeColliders = new IFXAE_Colliders(gameObject);
        //            }
        //            else
        //            {
        //                //Debug.Log($" [{this.name}] - Anim effect - trying to add to ae colliders : {gameObject} {aeColliders !=null }");
        //                aeColliders.Init(gameObject);
        //            }
        //            aeColliders.mainCollider = ENG_IGM_PlayerManager.instance.myPlayerObject.playerObject.GetComponent<Collider>();
        //            UpdateValues += GetPlayerCollision; 
        //        }
                
        //        if (UpdateValues != null)
        //        {
        //            Debug.Log($"IFXAnimEffect_Send_Player [{this.name}] Initialized ");
        //            Initalized = true;
        //        }
        //        else
        //        {
        //            Debug.Log($"IFXAnimEffect_Send_Player [{this.name}] Failed to initialize ");
        //        }
                
        //    }   
        //}



        /////////////////////////////////////////////////
        //private float GetPlayerPosition_X()
        //{
        //    return PlayerCamera.transform.position.x;
        //}
        //private float GetPlayerPosition_Y()
        //{
        //    return PlayerCamera.transform.position.y;
        //}
        //private float GetPlayerPosition_Z()
        //{
        //    return PlayerCamera.transform.position.z;
        //}

        //private float GetPlayerRotation_X()
        //{
        //    return PlayerCamera.transform.rotation.x;
        //}
        //private float GetPlayerRotation_Y()
        //{
        //    return PlayerCamera.transform.rotation.y;
        //}
        //private float GetPlayerRotation_Z()
        //{
        //    return PlayerCamera.transform.rotation.z;
        //}

        //////////////////////////////////////////
        //private float GetPlayerDistance()
        //{
        //    return (playerDistanceTarget.position - PlayerCamera.transform.position).sqrMagnitude;
        //}
        //private float GetPlayerHandDistance()
        //{
        //    float distanceToPrimaryHand = 100;
        //    float distanceToSecondaryHand = 100;
        //    if (PrimaryHandTransform != null)
        //    {
        //        distanceToPrimaryHand = (PrimaryHandTransform.position - playerHandDistanceTarget.position).sqrMagnitude;
        //    }
        //    if (SecondaryHandTransform != null)
        //    {
        //        distanceToSecondaryHand = (SecondaryHandTransform.position - playerHandDistanceTarget.position).sqrMagnitude;
        //    }
        //    return Mathf.Min(distanceToPrimaryHand, distanceToSecondaryHand);
        //}
        //////////////////////////////////////////    

        //private float GetPlayerTouchedVR()
        //{
        //    foreach (var target in aeColliders.targetColliders)
        //    {
        //        if (PrimaryHandTransform != null)
        //        {
        //            if (IFXAE_Colliders.ColliderContainsPoint(target, PrimaryHandTransform.position))
        //            {
        //                if (requireTriggerPress)
        //                {
        //                    if (ENG_TrackedMotionControllers.instance.triggerPressed[ENG_TrackedMotionControllers.instance.primaryHand])
        //                    {
        //                        return 1.0f;
        //                    }
        //                }
        //                if (requireGrippedPress)
        //                {
        //                    if (ENG_TrackedMotionControllers.instance.gripped[ENG_TrackedMotionControllers.instance.primaryHand])
        //                    {
        //                        return 1.0f;
        //                    }

        //                }
        //                if (!requireGrippedPress && !requireTriggerPress)
        //                {
        //                    return 1.0f;
        //                }
        //            }
        //        }

        //        if (SecondaryHandTransform != null)
        //        {
        //            if (IFXAE_Colliders.ColliderContainsPoint(target, SecondaryHandTransform.position))
        //            {
        //                if (requireTriggerPress)
        //                {
        //                    if (ENG_TrackedMotionControllers.instance.triggerPressed[ENG_TrackedMotionControllers.instance.secondaryHand])
        //                    {
        //                        return 1.0f;
        //                    }
        //                }
        //                if (requireGrippedPress)
        //                {
        //                    if (ENG_TrackedMotionControllers.instance.gripped[ENG_TrackedMotionControllers.instance.secondaryHand])
        //                    {
        //                        return 1.0f;
        //                    }

        //                }
        //                if (!requireGrippedPress && !requireTriggerPress)
        //                {
        //                    return 1.0f;
        //                }
        //            }
        //        }
                
        //    }
            
        //    return 0.0f;
        //}
        //private float GetPlayerTouchedMouse()
        //{
        //    //Ray interaction_ray = Engage.ScriptHelper.mainCamera.ScreenPointToRay(Engage.ScriptHelper.mainCamera.WorldToScreenPoint(ENG_TrackedMotionControllers.instance.GetWorldGUIPointerTransform().position));
            
        //    if (Input.GetMouseButton(0))
        //    {
                
        //        foreach (var target in aeColliders.targetColliders)
        //        {
        //            Ray interaction_ray = new Ray(PlayerCamera.transform.position, PlayerCamera.transform.forward);
        //            RaycastHit hit;
        //            //Debug.DrawRay(interaction_ray.origin, interaction_ray.direction,  Color.green,  500.0f, true);
        //            if (target.Raycast(interaction_ray, out hit, mouseTouchRange))
        //            {
        //                return 1.0f;
        //            }
        //        }
                
        //    }
        //    return 0.0f;
        //}
        //private float GetPlayerCollision()
        //{
        //    if (aeColliders.Colliding)
        //    {
        //        return 1.0f;
        //    }
        //    else
        //    {
        //        return 0.0f;
        //    }
        //}
    }
}
