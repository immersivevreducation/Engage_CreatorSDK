using UnityEngine;
using System.Collections.Generic;
//using Engage.Core.DependencyInjection;
//using Engage;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Player - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Player_Module : IFXAnimEffect_SEND_Module
    {            
        [Header("Float Based----------------------------------------------------")]
        [SerializeField]
        bool from_PlayerPositon_X;
        [SerializeField]
        bool from_PlayerPositon_Y;
        [SerializeField]
        bool from_PlayerPositon_Z;

        //////////////////////    
        [SerializeField]
        bool from_PlayerRotation_X;
        [SerializeField]
        bool from_PlayerRotation_Y;
        [SerializeField]
        bool from_PlayerRotation_Z;

        ///////////////////////
        ///
        [Space]
        [SerializeField]
        bool from_PlayerDistance;

        [SerializeField]
        Transform playerDistanceTarget;
        ///////////////////////
        [Space]
        [SerializeField]
        bool from_PlayerHandDistance;

        [SerializeField]
        Transform playerHandDistanceTarget;

        ////////////////////////
        [Header("Trigger Based----------------------------------------------------")]
        [Space]
        ///////////////////////
        
        [SerializeField]
        bool from_PlayerCollision;
        ColliderObserver colliderObserver;
        
        ///////////////////////
        [Space]
        [SerializeField]
        bool from_PlayerTouch;
        [SerializeField]
        float mouseTouchRange = 5;
        
        [SerializeField]
        bool requireTriggerPress;
        [SerializeField]
        bool requireGrippedPress;
        [Space]
        [Header("Leave 'Main Collider' empty")]
        [Header("Set Colliders for functions that require them here - Leave 'Main Collider' empty")]
        
        [SerializeField]
        IFXAE_Colliders aeColliders;

        
    }
}
