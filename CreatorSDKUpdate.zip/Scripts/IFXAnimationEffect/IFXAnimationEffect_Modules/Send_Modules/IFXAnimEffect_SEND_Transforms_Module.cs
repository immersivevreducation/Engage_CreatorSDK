using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Transform - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Transforms_Module : IFXAnimEffect_SEND_Module
    {
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        Transform input_Transform;
        [Header("--------------------------------------------------------------")]
        [Space]
        //////////////////////////////////
        [SerializeField]
        bool from_Positon_X;
        [SerializeField]
        bool from_Positon_Y;
        [SerializeField]
        bool from_Positon_Z;
        [Header("--------------------------------------------------------------")]
        [Space]

        [SerializeField]
        bool from_Rotation_X;
        [SerializeField]
        bool from_Rotation_Y;
        [SerializeField]
        bool from_Rotation_Z;
        [Header("--------------------------------------------------------------")]
        [Space]

        [SerializeField]
        bool from_Scale_X;
        [SerializeField]
        bool from_Scale_Y;
        [SerializeField]
        bool from_Scale_Z;
        
        //////////////////////////////////

        private void OnEnable()
        {
            if (input_Transform == null)
            {
                Debug.Log($"AnimationEffect: [{ this.name}]: Input_Transform not set, an input_Transform is required.");
                return;
            }
            /////////////////////////////////////////////////////
            if (from_Positon_X)
            {
                UpdateValues += GetPosition_X;
            }
            if (from_Positon_Y)
            {
                UpdateValues += GetPosition_Y;
            }
            if (from_Positon_Z)
            {
                UpdateValues += GetPosition_Z;
            }
            /////////////////////
            if (from_Rotation_X)
            {
                UpdateValues += GetRotation_X;
            }
            if (from_Rotation_Y)
            {
                UpdateValues += GetRotation_Y;
            }
            if (from_Rotation_Z)
            {
                UpdateValues += GetRotation_Z;
            }
            //////////////////////
            if (from_Scale_X)
            {
                UpdateValues += GetScale_X;
            }
            if (from_Scale_Y)
            {
                UpdateValues += GetScale_Y;
            }
            if (from_Scale_Z)
            {
                UpdateValues += GetScale_Z;
            }
        }

        
        ///////////////////////////////////////////////

        private float GetPosition_X()
        {
            float output = input_Transform.localPosition.x;
            return output;
        }
        private float GetPosition_Y()
        {
            float output = input_Transform.localPosition.y;
            return output;
        }
        private float GetPosition_Z()
        {
            float output = input_Transform.localPosition.z;
            return output;
        }

        /////////////////////////////////
        private Vector3 lastRotation_X;
        private float GetRotation_X()
        {
            float output = base.AnimationEffectVariable.GetMathOutput();

            var axis = input_Transform.localRotation * Vector3.right;
            var facing = input_Transform.localRotation * Vector3.forward;

            float delta = Vector3.SignedAngle(Vector3.ProjectOnPlane(lastRotation_X, axis), facing, axis);
            lastRotation_X = facing;

            output += delta;

            return output;
        }
        private Vector3 lastRotation_Y;
        private float GetRotation_Y()
        {
            float output = base.AnimationEffectVariable.GetMathOutput();

            var axis = input_Transform.localRotation * Vector3.up;
            var facing = input_Transform.localRotation * Vector3.forward;

            float delta = Vector3.SignedAngle(Vector3.ProjectOnPlane(lastRotation_Y, axis), facing, axis);
            lastRotation_Y = facing;

            output += delta;

            return output;
        }

        private Vector3 lastRotation_Z;
        private float GetRotation_Z()
        {
            float output = base.AnimationEffectVariable.GetMathOutput();

            var axis = input_Transform.localRotation * Vector3.forward;
            var facing = input_Transform.localRotation * Vector3.right;

            float delta = Vector3.SignedAngle(Vector3.ProjectOnPlane(lastRotation_Z, axis), facing, axis);
            lastRotation_Z = facing;

            output += delta;

            return output;
        }
        //////////////////////////////////
        private float GetScale_X()
        {
            float output = input_Transform.localScale.x;
            return output;
        }
        private float GetScale_Y()
        {
            float output = input_Transform.localScale.y;
            return output;
        }
        private float GetScale_Z()
        {
            float output = input_Transform.localScale.z;
            return output;
        }

    }
}
