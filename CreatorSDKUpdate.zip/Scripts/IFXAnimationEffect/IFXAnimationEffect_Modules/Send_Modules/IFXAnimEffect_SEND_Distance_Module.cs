using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Distance - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Distance_Module : IFXAnimEffect_SEND_Module
    {
        //////////////////////////////////
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool invert;
        [SerializeField]
        Transform distanceTarget1;
        [SerializeField]
        Transform distanceTarget2;

        //////////////////////////////////

        private void OnEnable()
        {
            if (distanceTarget1 && distanceTarget2 != null)
            {
                if (invert)
                {
                    UpdateValues += GetDistanceInverted;
                }
                else
                {
                    UpdateValues += GetDistance;
                }

            }
            else
            {
                Debug.Log($"Animation Effect: [{this.name}] Distance target 1 or 2 is empty ");
            }
        }
        ///////////////////////////////////////////////

        private float GetDistance()
        {
            float output = Vector3.Distance(distanceTarget1.position, distanceTarget2.position);
            return output;
        }
        private float GetDistanceInverted()
        {
            float output = 1 / Vector3.Distance(distanceTarget1.position, distanceTarget2.position);
            return output;
        }

    }
}
