using UnityEngine;
using Engage.IFX.NetworkStates;
namespace IFXAnimEffect
{
    // Uncomment the line below and enter how you want this module to show in the component menu
    //[AddComponentMenu("IFXAnimEffect_SEND/Template - IFX SEND Module")]
    public class IFXAnimEffect_SEND_PlayerInfo : IFXAnimEffect_SEND_Module
    {
        //LVR_FPC_PlayerSync playerSync = LVR_FPC_PlayerSync.LocalPlayer;
        //////////////////////////////////
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool from_PlayerNumber;
        [SerializeField]
        bool from_PlayerHostStatus;
        [SerializeField]
        bool from_PlayerAwayStatus;
        [SerializeField]
        bool from_PlayerSpeaking;
        [SerializeField]
        bool from_PlayerUsingVR;
        [SerializeField]
        bool from_PlayerHeight;
        [SerializeField]
        bool from_PlayerTimeSinceJoined;
        [SerializeField]
        bool from_PlayerPing;
        [Header("--------------------------------------------------------------")]
        [Tooltip("1 = true 0 = false")]
        [SerializeField]
        bool from_PlayerNetworkstatesModuleOwner;
        [SerializeField]
        bool from_NetworkstatesModuleOwnerID;
        [SerializeField]
        NetworkStateModule networkStatesModule;

        //////////////////////////////////

    //    private void OnEnable()
    //    {
    //        Setup();
    //    }
    //    public override void Setup()
    //    {
    //        if (playerSync != null)
    //        {
    //            if (from_PlayerNumber)
    //            {
    //                UpdateValues += GetPlayerNumber;
    //            }
    //            if (from_PlayerHostStatus)
    //            {
    //                UpdateValues += GetPlayerHostStatus;
    //            }
    //            if (from_PlayerHostStatus)
    //            {
    //                UpdateValues += GetPlayerAwayStatus;
    //            }
    //            if (from_PlayerSpeaking)
    //            {
    //                UpdateValues += GetPlayerSpeakingStatus;
    //            }
    //            if (from_PlayerUsingVR)
    //            {
    //                UpdateValues += GetPlayerVRStatus;
    //            }
    //            if (from_PlayerHeight)
    //            {
    //                UpdateValues += GetPlayerHeight;
    //            }
    //            if (from_PlayerTimeSinceJoined)
    //            {
    //                UpdateValues += GetPlayerTimeSinceJoinedScene;
    //            }
    //            if (from_PlayerPing)
    //            {
    //                UpdateValues += GetPlayerPing;
    //            }
    //            if (from_PlayerNetworkstatesModuleOwner && networkStatesModule != null)
    //            {
    //                UpdateValues += GetIsPlayerNetworkstatesModuleOwner;
    //            }
    //            if (from_NetworkstatesModuleOwnerID && networkStatesModule != null)
    //            {
    //                UpdateValues += GetNetworkstatesModuleOwnerID;
    //            }
    //        }
    //        if (UpdateValues != null)
    //        {
    //            Debug.Log($"IFXAnimEffect_Send_Player [{this.name}] Initialized ");
    //            Initalized = true;
    //        }
    //        else
    //        {
    //            Debug.Log($"IFXAnimEffect_Send_Player [{this.name}] Failed to initialize ");
    //        }
    //    }


    //    private float GetPlayerNumber()
    //    {
    //        return playerSync.myPlayerNumber;
    //    }
    //    private float GetPlayerHostStatus()
    //    {
    //        if (playerSync.isSessionHost)
    //        {
    //            return 1.0f;
    //        }
    //        return 0.0f;
    //    }
    //    private float GetPlayerAwayStatus()
    //    {
    //        if (playerSync.isAway)
    //        {
    //            return 1.0f;
    //        }
    //        return 0.0f;
    //    }
    //    private float GetPlayerSpeakingStatus()
    //    {
    //        if (playerSync.isSpeaking)
    //        {
    //            return 1.0f;
    //        }
    //        return 0.0f;
    //    }
    //    private float GetPlayerVRStatus()
    //    {
    //        if (playerSync.usingVR)
    //        {
    //            return 1.0f;
    //        }
    //        return 0.0f;
    //    }
        
    //    private float GetPlayerHeight()
    //    {
    //        return playerSync.playerHeightInCentimeters;
    //    }
    //    private float GetPlayerTimeSinceJoinedScene()
    //    {
    //        return (float)playerSync.timeSinceJoinedLevel;
    //    }
    //    private float GetPlayerPing()
    //    {

    //        return playerSync.playerPing;
    //    }
    //    private float GetIsPlayerNetworkstatesModuleOwner()
    //    {
    //        if (networkStatesModule.currentOwnerID == playerSync.myPlayerNumber)
    //        {
    //            return 1.0f;
    //        }
    //        return 0.0f;
    //    }
    //    private float GetNetworkstatesModuleOwnerID()
    //    {          
    //        return networkStatesModule.currentOwnerID;
    //    }
    }
}
