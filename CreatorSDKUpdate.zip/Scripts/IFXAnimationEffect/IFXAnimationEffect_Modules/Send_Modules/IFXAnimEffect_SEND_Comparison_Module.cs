using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Comparison - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Comparison_Module : IFXAnimEffect_SEND_Module
    {
        //////////////////////////////////       
        [Header("----------------------IF(every Float Is identical)------------------")]
        [SerializeField]
        bool from_AND;
        [SerializeField]
        IFXAnimationEffectFloatVariable[] if_AND;
        [Header("----------------------IF(Any Input_1 matches Input_2)------------")]
        [SerializeField]
        bool from_OR;
        [SerializeField]
        IFXAnimationEffectFloatVariable[] if_OR_Input_1;
        [SerializeField]
        IFXAnimationEffectFloatVariable if_OR_Input_2;


        //////////////////////////////////

        private void OnEnable()
        {
            
            if (from_AND && if_AND !=null)
            {
                if (if_AND.Length>1)
                {
                    UpdateValues += GetAND;
                }   
            }
            if (from_OR)
            {
                if (if_OR_Input_1 !=null && if_OR_Input_2 != null)
                {
                    UpdateValues += GetOR;
                } 
            }
        }
   
        private float GetAND()
        { 
            foreach (var item in if_AND)
            {
                if (item.GetMathOutput() != if_AND[0].GetMathOutput())
                {
                    return 0.0f;
                }
            }
            return 1.0f;
        }
        private float GetOR()
        {
            foreach (var item in if_OR_Input_1)
            {
                if (item.GetMathOutput() == if_OR_Input_2.GetMathOutput())
                {
                    return 1.0f;
                }
            }
            return 0.0f;
        }
    }
}
