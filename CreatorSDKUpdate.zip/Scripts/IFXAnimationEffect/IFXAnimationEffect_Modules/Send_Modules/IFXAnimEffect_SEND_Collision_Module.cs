using UnityEngine;
using System.Collections;
using System.Collections.Generic;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Collision - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Collision_Module : IFXAnimEffect_SEND_Module
    {   
        [Header("--------------------------------------------------------------")]
        //////////////////////////////////
        [SerializeField]
        IFXAE_Colliders aeColliders;


        //////////////////////////////////

        private void OnEnable()
        {
            if (aeColliders == null)
            {
                //Debug.Log($" [{this.name}] - Anim effect - trying to add to ae colliders : {gameObject}");
                aeColliders = new IFXAE_Colliders(gameObject);
            }
            else
            {
                //Debug.Log($" [{this.name}] - Anim effect - trying to add to ae colliders : {gameObject} {aeColliders !=null }");
                aeColliders.Init(gameObject);
            }
            if (aeColliders.mainCollider !=null && aeColliders.targetColliders !=null)
            {
                UpdateValues += GetCollision;
            }
            else
            {
                Debug.Log($"[{this.name}] Main collider or target collider Reference left Empty. Both are required");
            }
        }


        //This method gets called by SEND_Main to retrive to value from the delegate. Only one method should be returning values.
        // public override void SendOutput()
        // {
        //    AnimationEffectVariable.Value = UpdateValues();
        // }
        ///////////////////////////////////////////////

        
        public float GetCollision()
        {
            if (aeColliders.Colliding)
            {
                return 1.0f;
            }
            else
            {
                return 0.0f;
            }
        }




    }
}

