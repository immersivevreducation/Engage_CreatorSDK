using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/NumberGen - IFX SEND Module")]
    public class IFXAnimEffect_SEND_NumberGenerator_Module : IFXAnimEffect_SEND_Module
    {
        [Header("--------------------------------------------------------------")]

        [Tooltip("Increase the value of the variable set in floatVariableOut by the number below or another float variable if one is plugged in.")]
        [SerializeField]
        bool from_IncreaseBY;
        [SerializeField]
        float increment = 1;
        [SerializeField]
        IFXAnimationEffectFloatVariable incrementInput;
        [Space]
        //////////////////////////
        [SerializeField]
        bool from_Random;
        [SerializeField]
        float randomMin = 0;
        [SerializeField]
        float randomMax = 1;
        [SerializeField]
        IFXAnimationEffectFloatVariable randomMinInput;
        [SerializeField]
        IFXAnimationEffectFloatVariable randomMaxInput;

        /// ///////////////////
        [Space]
        [SerializeField]
        bool From_LerpNumberTowardsValue;
        [SerializeField]
        float targetValue;
        [SerializeField]
        IFXAnimationEffectFloatVariable targetValueInput;
        [SerializeField]
        float lerpSpeed;
        [SerializeField]
        IFXAnimationEffectFloatVariable lerpSpeedInput;
        //////////////////////////////////

        private void OnEnable()
        {
            if (from_IncreaseBY)
            {
                if (incrementInput == null)
                {
                    UpdateValues += GetIncreaseBy;
                }
                else
                {
                    UpdateValues += GetIncreaseByInput;
                }

            }
            //////////////////////////
            if (from_Random)
            {
                if (randomMinInput != null || randomMaxInput != null)
                {
                    UpdateValues += GetRandomFromInput;
                }
                else
                {
                    UpdateValues += GetRandom;
                }

            }
            if (From_LerpNumberTowardsValue)
            {
                UpdateValues += LerpNumberTowardsValue;
            }
        }
        ///////////////////////////////////////////////

        private float GetIncreaseBy()
        {

            float output = AnimationEffectVariable.GetMathOutput() + increment;
            return output;
        }
        private float GetIncreaseByInput()
        {

            float output = AnimationEffectVariable.GetMathOutput() + incrementInput.GetMathOutput();
            return output;
        }

        private float GetRandom()
        {
            float output = Random.Range(randomMin, randomMax);

            return output;
        }
        private float GetRandomFromInput()
        {
            float randmin = randomMin;
            float randMax = randomMax;
            if (randomMinInput != null)
            {
                randmin = randomMinInput.GetMathOutput();
            }
            if (randomMaxInput != null)
            {
                randMax = randomMaxInput.GetMathOutput();
            }
            float output = Random.Range(randmin, randMax);

            return output;
        }
        private float LerpNumberTowardsValue()
        {
            float output;
            float speed;
            if (lerpSpeedInput != null)
            {
                speed = lerpSpeedInput.GetMathOutput();
            }
            else
            {
                speed = lerpSpeed;
            }
            if (targetValueInput != null)
            {
                output = Mathf.Lerp(base.AnimationEffectVariable.GetMathOutput(), targetValueInput.GetMathOutput(), speed * Time.deltaTime);
            }
            else
            {
                output = Mathf.Lerp(base.AnimationEffectVariable.GetMathOutput(), targetValue, speed * Time.deltaTime);
            }

            return output;
        }

    }
}
