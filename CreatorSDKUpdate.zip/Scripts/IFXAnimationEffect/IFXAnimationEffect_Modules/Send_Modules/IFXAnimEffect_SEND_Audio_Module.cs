using UnityEngine;
using System.Linq;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/Audio - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Audio_Module : IFXAnimEffect_SEND_Module
    {
        

        //////////////////////////////////
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        AudioSource audioIn;
        [Space]
        [SerializeField]
        bool from_AudioSpectrum;
        [Space]
        [SerializeField]
        [Space]
        bool from_AudioVolume;
        [Space]
        [SerializeField]
        bool from_AudioPitch;
        //////////////////////////////////

        private void OnEnable()
        {
            if (audioIn != null)
            {
                if (from_AudioSpectrum)
                {
                    if (audioIn != null)
                    {
                        UpdateValues += GetAudioSpectrum;
                    }
                    else
                    {
                        Debug.Log($"Animation Effect: [{this.name}] From AudioPitch selected but audioIn input empty");
                    }
                }
                if (from_AudioVolume)
                {
                    if (audioIn != null)
                    {
                        UpdateValues += GetAudioVolume;
                    }
                    else
                    {
                        Debug.Log($"Animation Effect: [{this.name}] From AudioPitch selected but audioIn input empty");
                    }
                }
                if (from_AudioPitch)
                {
                    if (audioIn != null)
                    {
                        UpdateValues += GetAudioPitch;
                    }
                    else
                    {
                        Debug.Log($"Animation Effect: [{this.name}] From AudioPitch selected but audioIn input empty");
                        
                    }
                }
            }
        }     
        ///////////////////////////////////////////////

        private float GetAudioSpectrum()
        {
            float[] spectrum = new float[8192];

            audioIn.GetSpectrumData(spectrum, 1, FFTWindow.Rectangular);
            float spectrumAverage = spectrum.Average();
            float output = spectrumAverage * 8192;
            return output;
        }
        private float GetAudioVolume()
        {

            float output = audioIn.volume;
            return output;
        }
        private float GetAudioPitch()
        {

            float output = audioIn.pitch;
            return output;
        }

    }
}
