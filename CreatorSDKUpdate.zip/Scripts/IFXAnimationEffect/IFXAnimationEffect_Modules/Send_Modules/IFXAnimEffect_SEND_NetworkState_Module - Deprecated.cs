using UnityEngine;
using Math = System.Math;
namespace IFXAnimEffect
{

    //[RequireComponent(typeof(LVR_Location_NetworkState))]
    [AddComponentMenu("IFXAnimEffect_SEND/NetworkState - IFX SEND Module")]
    public class IFXAnimEffect_SEND_NetworkState_Module : IFXAnimEffect_SEND_Module
    {
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool updateOnlyOnChange = true;
        //This is an example of an option you could have
        [SerializeField]
        LVR_Location_NetworkStateManager networkStateManager;
        [SerializeField]
        LVR_Location_NetworkState module_NetworkState;

        

    }
}
