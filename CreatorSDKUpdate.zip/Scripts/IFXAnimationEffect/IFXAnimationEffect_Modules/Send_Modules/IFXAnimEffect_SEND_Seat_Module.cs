using UnityEngine;
using Engage.Avatars.Poses;
namespace IFXAnimEffect
{
    // Uncomment the line below and enter how you want this module to show in the component menu
    [AddComponentMenu("IFXAnimEffect_SEND/Seat - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Seat_Module : IFXAnimEffect_SEND_Module
    {
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool from_Sittrigger;
        [SerializeField]
        LVR_SitTrigger SitTrigger;
        [SerializeField]
        bool from_PoseOnSeat;
        [SerializeField]
        PoseDataAsset pose;
        //LVR_FPC_SeatManager seatManager;
        //LVR_FPC_SeatManager SeatManager
        //{
        //    get
        //    {
        //        if (seatManager != null )
        //        {
        //            return seatManager;
        //        }
        //        else if (LVR_FPC_SeatManager.LocalPlayer != null)
        //        {
        //            seatManager = LVR_FPC_SeatManager.LocalPlayer;
        //            return seatManager;
        //        }
        //        return null;
        //    }
        //}

        //////////////////////////////////

        //private void OnEnable()
        //{
        //    Setup();
        //}

        //public override void Setup()    
        //{
        //    if (SeatManager != null)
        //    {
        //        UpdateValues = null;
        //        if (from_Sittrigger)
        //        {
        //            if (SitTrigger != null)
        //            {
        //                UpdateValues += GetSitTrigger;
        //            }
        //            else
        //            {
        //                Debug.Log("IFXAnimEffect_Send_Seat: sitTrigger field Null");
        //            }
        //        }
        //        if (from_PoseOnSeat)
        //        {
        //            if (pose != null)
        //            {
        //                UpdateValues += GetPoseOnSeat;
        //            }
        //            else
        //            {
        //                Debug.Log("IFXAnimEffect_Send: Pose field Null");
        //            }
        //        }
        //        if (UpdateValues != null)
        //        {
        //            Debug.Log($"IFXAnimEffect_Send [{this.name}] Initialized ");
        //            Initalized = true;
        //        }
        //        else
        //        {
        //            Debug.Log($"IFXAnimEffect_Send [{this.name}] Failed to initialize ");
        //        }
        //    }
        //    else
        //    {
        //        Debug.Log("IFXAnimEffect_Send: Seat manager not found");
        //    }
        //}

        //private float GetSitTrigger()
        //{
        //    if (SeatManager.sitTriggerScript == SitTrigger)
        //    {
        //        return 1;
        //    }
        //    else
        //    {
        //        return 0;
        //    }

        //}
        //private float GetPoseOnSeat()
        //{
        //    if (SeatManager.currentPoseSelector.ChosenPose == pose)
        //    {
        //        return 1;
        //    }
        //    else
        //    {
        //        return 0;
        //    }

        //}
    }
}
