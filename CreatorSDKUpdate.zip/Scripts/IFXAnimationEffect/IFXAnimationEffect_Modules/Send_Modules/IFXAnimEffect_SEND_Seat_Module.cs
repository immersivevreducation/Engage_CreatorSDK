using UnityEngine;
using Engage.Avatars.Poses;
namespace IFXAnimEffect
{
    // Uncomment the line below and enter how you want this module to show in the component menu
    [AddComponentMenu("IFXAnimEffect_SEND/Seat - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Seat_Module : IFXAnimEffect_SEND_Module
    {
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool from_Sittrigger;
        [SerializeField]
        LVR_SitTrigger SitTrigger;
        [SerializeField]
        bool from_PoseOnSeat;
        [SerializeField]
        PoseDataAsset pose;
        
    }
}
