using UnityEngine;
namespace IFXAnimEffect
{
    
    [AddComponentMenu("IFXAnimEffect_SEND/Keypress - IFX SEND Module")]
    public class IFXAnimEffect_SEND_Keypress_Module : IFXAnimEffect_SEND_Module
    {

        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool from_Button;
        [SerializeField]
        string input_ButtonName;

        [Space]
        [SerializeField]
        bool from_Axis;
        [SerializeField]
        string input_AxisName;

        [Space]
        [SerializeField]
        bool from_Key;
        [SerializeField]
        string input_KeyName;
       
        //////////////////////////////////

        private void OnEnable()
        {
            if (from_Button)
            {
                UpdateValues += GetButton;
            }
            if (from_Axis)
            {
                UpdateValues += GetAxis;
            }
            if (from_Key)
            {
                UpdateValues += GetKey;
            }
        }
        ///////////////////////////////////////////////
        private float GetButton()
        {
            if (Input.GetButton(input_ButtonName))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        private float GetAxis()
        {
            return Input.GetAxis(input_AxisName);
        }
        private float GetKey()
        {

            if (Input.GetKey(input_KeyName))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

    }
}
