using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_RECEIVE/Teleport - IFX RECEIVE Module")]
    public class IFXAnimEffect_RECEIVE_Teleport_Module : IFXAnimEffect_RECEIVE_Module
    {
        // a name for this type of module for use in the editor

        //////////////////////////////////
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        bool to_TeleportObject;
        [SerializeField]
        GameObject objectToTeleport;
        //[SerializeField]
        //bool to_TeleportPlayer;

        [SerializeField]
        Transform destination;

        //RECEIVE can use the same value to effect multiple things. For example the value coming in could be used to move the object on the x axis and the y axis at the same time.
        //You should not have another receive module also effect the same value though, for example two RECEIVES both trying to tranlate on the x axis


        //You can use if statments and the "InputBoolAction" & "InputFloatAction" delegates to choose the appropriate update method or methods you want the value fed to.

        //////////////////////////////////

        private void OnEnable()
        {                       
            if (to_TeleportObject)
            {
                this.InputBoolAction += TelportObjectToDestination;
            }
            //if (to_TeleportPlayer)
            //{
            //    this.InputBoolAction += TelportPlayerDestination;
            //}
        }
        
        ////////////////////////////////////////
        

        public void TelportObjectToDestination(bool input)
        {
            if (input == true)
            {
                objectToTeleport.transform.position = destination.position;
                objectToTeleport.transform.rotation = destination.rotation;
            }
        }
        //public void TelportPlayerDestination(bool input)
        //{
        //    if (input == true)
        //    {
        //        objectToTeleport.transform.position = destination.position;
        //        objectToTeleport.transform.rotation = destination.rotation;
        //    }
        //}
    }
}
