using UnityEngine;
using System.Collections.Generic;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_RECEIVE/Create Destroy")]
    public class IFXAnimEffect_RECEIVE_CreateDestroy_Module : IFXAnimEffect_RECEIVE_Module
    {
        [Header("----------------------------------------------------")]
        [Space]
        //////////////////////////////////
        [SerializeField]
        bool to_CreateObject;
        [SerializeField]
        GameObject objectToCreate;
        [SerializeField]
        List<GameObject> objectPool = new List<GameObject>();
        [SerializeField]
        Transform spawnPoint;
        [SerializeField]
        int maximumObjectCount;
        [SerializeField]
        bool timedLife;
        [SerializeField]
        float lifeTime;
        [SerializeField]

        [Space]
        bool to_DestroyObject;
        [SerializeField]
        GameObject objectToDestroy;

        int placeInPool = 0;
        
       

        //////////////////////////////////

        private void OnEnable()
        {
            if (to_CreateObject)
            {
                
                if (objectToCreate != null)
                {
                    this.InputBoolAction += SpawnObjects;
                }
                else
                {
                    Debug.Log($"AnimationEffect: [{this.name}] Error - to_CreateObject selected but objectToCreate field is empty");
                }
                if (timedLife)
                {
                    foreach (var gObject in objectPool)
                    {
                        IFXAE_DisableAfterTimer timerScript = gObject.AddComponent<IFXAE_DisableAfterTimer>();
                        timerScript.LifeTimeTotal = lifeTime;
                    }
                    
                }             
            }   
            if (to_DestroyObject)
            {
                if (objectToDestroy != null)
                {
                    this.InputBoolAction += DestroyObject;
                }
                else
                {
                    Debug.Log($"AnimationEffect: [{this.name}] Error - To_DestroyObject selected but ObjectToDestroy field is empty");
                }       
            }
        }
        ///////////////////////////////////////////////

        public void SpawnObjects(bool input)
        {
            if (input)
            {
                if (objectPool.Count < maximumObjectCount)
                {
                    GameObject createdObj = Instantiate(objectToCreate, spawnPoint.position, spawnPoint.rotation);
                    createdObj.transform.SetParent(objectToCreate.transform.parent);
                    if (timedLife)
                    {
                        IFXAE_DisableAfterTimer timerScript = createdObj.AddComponent<IFXAE_DisableAfterTimer>();
                        timerScript.LifeTimeTotal = lifeTime;
                    }
                    objectPool.Add(createdObj);
                }
                else
                {
                    //Debug.Log("placeInPool" + placeInPool);
                    objectPool[placeInPool].SetActive(true);
                    objectPool[placeInPool].transform.position = spawnPoint.position;
                    objectPool[placeInPool].transform.rotation = spawnPoint.rotation;
                    placeInPool++;
                    if (placeInPool > objectPool.Count - 1)
                    {
                        placeInPool = 0;
                    }
                }
            }            
        }

        public void DestroyObject(bool input)
        {
            if (input)
            {
                if (objectToDestroy != null)
                {
                    Destroy(objectToDestroy);
                }
            }
            
        }
    }
}
