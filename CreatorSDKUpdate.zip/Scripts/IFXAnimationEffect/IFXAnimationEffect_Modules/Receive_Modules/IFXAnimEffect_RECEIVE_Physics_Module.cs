using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_RECEIVE/Physics - IFX RECEIVE Module")]
    public class IFXAnimEffect_RECEIVE_Physics_Module : IFXAnimEffect_RECEIVE_Module
    {
        // a name for this type of module for use in the editor

        //////////////////////////////////
        //This is an example of an option you could have
        [Header("--------------------------------------------------------------")]
        [SerializeField]
        Rigidbody rigidbody;
        [Header("--------------------------------------------------------------")]


        ///////////////
        [SerializeField]
        bool to_Torque_X;
        [SerializeField]
        bool to_Torque_Y;
        [SerializeField]
        bool to_Torque_Z;
        /////////////////
        [SerializeField]
        bool to_Force_X;
        [SerializeField]
        bool to_Force_Y;
        [SerializeField]
        bool to_Force_Z;
        //////////////////
        [SerializeField]
        bool to_MovePosition;
        [SerializeField]
        Transform movePosition_Target;
        [SerializeField]
        bool to_MoveRotation;
        [SerializeField]
        Transform moveRotation_Target;
        /// //////////////////
        ///
        [Header("WheelCollider Options---------------------------------------")]
        [SerializeField]
        WheelCollider wheelCollider;
        //////////////////
        [SerializeField]
        bool to_WheelSteeringAngle;
        [SerializeField]
        bool to_WheelTorque;
        [SerializeField]
        bool to_VisualWheel;
        [SerializeField]
        GameObject input_VisualWheel;

        ///////////////////
        [Header("Triggerable Options---------------------------------------")]
        [SerializeField]
        bool setKinimatic;


        //RECEIVE can use the same value to effect multiple things. For example the value coming in could be used to move the object on the x axis and the y axis at the same time.
        //You should not have another receive module also effect the same value though, for example two RECEIVES both trying to tranlate on the x axis


        //You can use if statments and the "InputBoolAction" & "InputFloatAction" delegates to choose the appropriate update method or methods you want the value fed to.

        //////////////////////////////////

        private void OnEnable()
        {
            if (rigidbody != null)
            {
                if (to_Torque_X)
                {
                    this.InputFloatAction += AddTorque_X;
                }
                if (to_Torque_Y)
                {
                    this.InputFloatAction += AddTorque_Y;
                }
                if (to_Torque_Z)
                {
                    this.InputFloatAction += AddTorque_Z;
                }
                /////////////////////////////////////
                ///
                if (to_Force_X)
                {
                    this.InputFloatAction += AddForce_X;
                }
                if (to_Force_Y)
                {
                    this.InputFloatAction += AddForce_Y;
                }
                if (to_Force_Z)
                {
                    this.InputFloatAction += AddForce_Z;
                }
                /////////////////////////////////////
                ///
                if (to_MovePosition)
                {
                    this.InputFloatAction += MoveRBPosition;
                }
                if (to_MoveRotation)
                {
                    this.InputFloatAction += MoveRBRotation;
                }

            }
            if (wheelCollider != null)
            {
                if (to_WheelSteeringAngle)
                {
                    this.InputFloatAction += WheelSteeringAngle;
                }
                if (to_WheelTorque)
                {
                    this.InputFloatAction += WheelTorque;
                }
                if (input_VisualWheel != null)
                {
                    this.InputFloatAction += UpdateVisualWheel;
                }

            }



            //for methods that use a bool input
            if (setKinimatic)
            {
                this.InputBoolAction += SetKinimatic;
            }



        }

        //Add your custom methods here. They should take either a float or bool input as appropriate and do somthing with that value. use the delegates show above to feed these methods
        ///////////////////////////////////////////////

        private void AddTorque_X(float input)
        {
            rigidbody.AddRelativeTorque(new Vector3(input, 0, 0));
        }
        private void AddTorque_Y(float input)
        {
            rigidbody.AddRelativeTorque(new Vector3(0, input, 0));
        }
        private void AddTorque_Z(float input)
        {
            rigidbody.AddRelativeTorque(new Vector3(0, 0, input));
        }


        /////////////////////////////////
        ///
        private void AddForce_X(float input)
        {
            rigidbody.AddRelativeForce(new Vector3(input, 0, 0));
        }
        private void AddForce_Y(float input)
        {
            rigidbody.AddRelativeForce(new Vector3(0, input, 0));
        }
        private void AddForce_Z(float input)
        {
            rigidbody.AddRelativeForce(new Vector3(0, 0, input));
        }

        /////////////////////////////////
        private void MoveRBPosition(float input)
        {
            rigidbody.position = movePosition_Target.position;
            //rigidbody.MovePosition(movePosition_Target.position);
        }
        private void MoveRBRotation(float input)
        {
            rigidbody.MoveRotation(moveRotation_Target.rotation);
        }
        /// /////////////////////////////////
        ///
        private void WheelSteeringAngle(float input)
        {
            wheelCollider.steerAngle = input;
        }
        private void WheelTorque(float input)
        {
            wheelCollider.motorTorque = input;
        }
        private void UpdateVisualWheel(float input)
        {


            Vector3 position;
            Quaternion rotation;
            wheelCollider.GetWorldPose(out position, out rotation);

            input_VisualWheel.transform.position = position;
            input_VisualWheel.transform.rotation = rotation;
        }

        public void SetKinimatic(bool input)
        {
            if (input == true)
            {
                rigidbody.isKinematic = true;
            }
            else
            {
                rigidbody.isKinematic = false;
            }
        }


    }
}
