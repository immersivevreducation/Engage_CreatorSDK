using UnityEngine;
namespace IFXAnimEffect
{
    [AddComponentMenu("IFXAnimEffect_SEND/SEND MAIN")]
    public class IFXAnimEffect_SEND_Module : MonoBehaviour
    {
        public delegate float UpdateValuesDelegate();
        public UpdateValuesDelegate UpdateValues;
        bool initalized = false;
        public bool Initalized 
        {
            get
            {
                if (initalized == false)
                {
                    Setup();         
                }
                return initalized;
            }
            set 
            {
                initalized = value;
            }
        }
        [SerializeField]
        public IFXAnimationEffectFloatVariable AnimationEffectVariable;

        [Space]

        [SerializeField]
        float updateRate = 0f;
        [SerializeField]
        public bool UpdateValueOnlyOnChange;



        bool playerLoaded = true;
        
        [Header("----------------------------------------------------")]
        int badInitError;
        private void Start()
        {
            badInitError = ErrorHandler.RegisterErrorMessage($"Animation Effect [{this.name}] Failed to initialize ");
            if (AnimationEffectVariable == null)
            {
                Debug.Log($"Animation Effect Variable Not Set: [{this.name}] ");
                return;
            }
        }
        private void OnDisable()
        {
            UpdateValues = null;
        }


        float timer = 0;
        private float lastValue;
        void Update()
        {
            if (!playerLoaded)
            {
                return;
            }

            if (AnimationEffectVariable == null)
            {
                return;
            }
            if (updateRate > 0f)
            {
                timer += Time.deltaTime;
                if (timer > updateRate)
                {
                    SendOutput();
                    timer = 0;
                }
            }
            else
            {
                SendOutput();
            }
        }

        public void UpdateValueOnChangeOnly(float input)
        {
            if (input != lastValue)
            {
                AnimationEffectVariable.Value = input;
                lastValue = input;
            }
            return;
        }
        public virtual void SendOutput()
        {
            if (Initalized)
            {
                if (UpdateValues == null)
                {       
                    return;
                }
                if (UpdateValueOnlyOnChange)
                {
                    UpdateValueOnChangeOnly(UpdateValues());
                }
                else
                {
                    AnimationEffectVariable.Value = UpdateValues();
                }
            }

        }
        public virtual void Setup() // for modules that need to wait for other refrences to exist in scene before starting we can override this to keep running set up untill it's ready.
        {
            if (UpdateValues != null)
            {
                Debug.Log($"IFXAnimEffect_Send [{this.name}] Initialized ");
                Initalized = true;
            }
            else
            {
                ErrorHandler.ReportError(badInitError);
            }
        }

    }
}

