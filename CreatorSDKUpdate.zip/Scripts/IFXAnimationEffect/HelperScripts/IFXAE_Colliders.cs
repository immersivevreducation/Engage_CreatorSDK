using System;
using System.Collections.Generic;
using UnityEngine;
namespace IFXAnimEffect
{
    [Serializable]
    public class IFXAE_Colliders
    {   
        public bool Colliding        
        {
            get 
            {
                if (mainCollider == null || targetColliders == null || gameObjectToUse == null)
                {
                    return false;
                }
                switch (collisionMode)
                {
                    case CollisionDetectionType.BoundingBox:
                        return GetCollisionBounds(targetColliders, mainCollider);

                    case CollisionDetectionType.Approxomite:
                        foreach (var collider in targetColliders)
                        {
                            //Debug.Log("aprox");

                            return ColliderContainsCollider(collider, mainCollider);
                        }
                        return false;

                    case CollisionDetectionType.Full:
                        if (colliderObserver == null)
                        {
                            //Debug.Log("created observer");
                            colliderObserver = gameObjectToUse.AddComponent<ColliderObserver>();
                            colliderObserver.AddInformant(mainCollider);
                        }
                        return GetCollisionAdvanced(targetColliders, colliderObserver);
                    default:
                        return false;
                }               
                
            }
        }
        public IFXAE_Colliders(GameObject gameObjectIN)
        {
            //Debug.Log($" Anim effect - gameObjectIN : {gameObjectIN}");
            Init(gameObjectIN);
            //Debug.Log($" Anim effect - gameObjectToUse : {gameObjectToUse}");
            
        }
        public void Init(GameObject gameObjectIN)
        {
            gameObjectToUse = gameObjectIN;
           // Debug.Log($" Anim effect - gameObjectToUse : {gameObjectToUse}");
        }
        public enum CollisionDetectionType
        {
            BoundingBox,
            Approxomite,
            Full
        }
        [SerializeField]
        CollisionDetectionType collisionMode;
        [SerializeField]
        public List<Collider> targetColliders;
        [SerializeField]
        public Collider mainCollider;
        ColliderObserver colliderObserver;
        GameObject gameObjectToUse;
        public static Vector3 GetCollidersCentersByType(Collider colliderIn)
        {
            if (colliderIn is BoxCollider)
            {
                return ((BoxCollider)colliderIn).center;
            }
            else if (colliderIn is SphereCollider)
            {
                return ((SphereCollider)colliderIn).center;
            }

            else if (colliderIn is CapsuleCollider)
            {
                return ((CapsuleCollider)colliderIn).center;
            }
            else if (colliderIn is MeshCollider)
            {
                return ((MeshCollider)colliderIn).transform.localPosition;
            }
            return Vector3.zero;
        }
        public static bool ColliderContainsPoint(Collider collider, Vector3 targetsCenter)
        {
            if (collider.bounds.Contains(targetsCenter)) // check to see if a more basic form of collision is true before doing the more complex version
            {
                Vector3 collider_center_world = collider.transform.TransformPoint(GetCollidersCentersByType(collider));
                Vector3 collider_closestPoint_target;

                collider_closestPoint_target = collider.ClosestPoint(targetsCenter);

                float distanceToSelf = (collider_center_world - collider_closestPoint_target).sqrMagnitude;
                float distanceToTarget = (collider_center_world - targetsCenter).sqrMagnitude;
                //Debug.Log("Distance to target: " + (distanceToTarget - distanceToSelf));
                //Debug.Log("targetCEntert: " + targetsCenter);
                //Debug.Log("closestpointself: " + selfCollider_closestPoint_target);
                if (distanceToTarget <= distanceToSelf)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool ColliderContainsCollider(Collider collider, Collider targetCollider)
        {
            if (collider.bounds.Intersects(targetCollider.bounds)) // check to see if a more basic form of collision is true before doing the more complex version
            {
                Vector3 collider_center_world = collider.transform.TransformPoint(GetCollidersCentersByType(collider));
                //Vector3 targetCollider_center_world = targetCollider.transform.TransformPoint(GetCollidersCentersByType(targetCollider));

                Vector3 targetCollider_closestPoint_target = targetCollider.ClosestPoint(collider_center_world);
                Vector3 collider_closestPoint_target = collider.ClosestPoint(targetCollider_closestPoint_target);

                //targetsCenter = targetCollider.ClosestPoint(collider_closestPoint_target);

                float distanceToSelf = (collider_center_world - collider_closestPoint_target).sqrMagnitude;
                float distanceToTargetsClosestPoint = (collider_center_world - targetCollider_closestPoint_target).sqrMagnitude;
                //Debug.Log("Distance to target: " + (distanceToTarget - distanceToSelf));
                //Debug.Log("targetCEntert: " + targetsCenter);
                //Debug.Log("closestpointself: " + selfCollider_closestPoint_target);


                if (distanceToTargetsClosestPoint <= distanceToSelf)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool GetCollisionAdvanced(List<Collider> targetColliders, ColliderObserver colliderObserver)
        {
            foreach (var target in targetColliders)
            {
                foreach (var collider in colliderObserver.currentlyCollidingWith)
                {
                    if (collider == target)
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        private static bool GetCollisionBounds(List<Collider> targetColliders, Collider mainCollider)
        {
            foreach (var target in targetColliders)
            {
                if (mainCollider.bounds.Intersects(target.bounds))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
