using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace IFXAnimEffect
{
    public static class ErrorHandler
    {
        private static List<string> registeredMessages = new List<string>();
        private static HashSet<int> loggedMessages = new HashSet<int>();

        public static int RegisterErrorMessage(string message)
        {
            int key = registeredMessages.Count;
            registeredMessages.Add(message);

            return key;
        }

        public static void ReportError(int key)
        {
            if (loggedMessages.Add(key))
            {
                UnityEngine.Debug.Log(registeredMessages[key]);
            }
        }
    }
}
