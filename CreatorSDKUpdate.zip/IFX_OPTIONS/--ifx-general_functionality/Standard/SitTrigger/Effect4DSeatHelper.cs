﻿using UnityEngine;

public class Effect4DSeatHelper : MonoBehaviour
{
    public Transform[] seats;

}
