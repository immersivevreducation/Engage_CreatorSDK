using UnityEngine;

//PLACE THIS SCRIPT AT ROOT OF SIT TRIGGER PREFAB TO FORCE SIT USERS 
public class ForceSitClass : MonoBehaviour {
	
}
