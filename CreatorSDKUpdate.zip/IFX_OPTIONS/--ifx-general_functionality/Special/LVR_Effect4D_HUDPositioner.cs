﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class LVR_Effect4D_HUDPositioner : MonoBehaviour {

    public Transform objectToMove;

    public float lerpTime = 0.5f;

    public int enqueAmount = 20;

}
