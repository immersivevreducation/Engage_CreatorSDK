﻿using UnityEngine;
using UnityEngine.Playables;
public class LVR_Effect_SyncAnimatorOrTimeline : MonoBehaviour
{
    public float timeDelayAnimator = 0f;

}
