using UnityEngine;

public class LightIncrease : MonoBehaviour {

}
