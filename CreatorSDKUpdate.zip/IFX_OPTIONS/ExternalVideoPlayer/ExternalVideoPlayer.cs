using System.Collections.Generic;
using UnityEngine;

namespace Engage.Media.Video
{
    internal class ExternalVideoPlayer : MonoBehaviour
    {
        [SerializeField] private string url;
        [SerializeField] private float startTimeOffsetSeconds;
        [SerializeField] private bool playOnEnableNoSync;
        [SerializeField] private float volume;
        [SerializeField] private bool isLoop;
        [SerializeField] private VideoResolution youtubeResolution;
        [SerializeField] private bool is360;
        [SerializeField] private bool is3d;
        [SerializeField] private bool isLiveStream;
        [SerializeField] private SpatialAudioOption spatialAudioOption;
        [SerializeField] private List<Renderer> screenRenderers;
        [SerializeField] private GameObject[] screens360;
        [Header("Uncommon - 2d only")]
        [SerializeField] private List<CanvasRenderer> canvasRenderers;

        private void Awake() {}

        void OnEnable() {}
    }
}
