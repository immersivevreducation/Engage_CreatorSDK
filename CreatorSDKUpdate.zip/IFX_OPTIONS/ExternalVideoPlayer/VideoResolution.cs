namespace Engage.Media
{
    public enum VideoResolution
    {
        unknown = 0,
        m_360 = 360,
        m_720 = 720,
        m_1080 = 1080,
        m_1440 = 1440,
        m_2160 = 2160,
    }
}
