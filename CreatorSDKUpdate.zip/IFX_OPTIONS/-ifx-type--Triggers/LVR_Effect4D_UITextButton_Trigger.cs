﻿using UnityEngine;
using UnityEngine.UI;

public class LVR_Effect4D_UITextButton_Trigger : MonoBehaviour {

    public Button button;

    public void OnClickButton()
    {

    }

    private void Update()
    {

    }
}
