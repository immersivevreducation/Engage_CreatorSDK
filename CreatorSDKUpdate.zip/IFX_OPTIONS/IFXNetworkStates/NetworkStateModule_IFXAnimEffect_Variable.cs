
using UnityEngine;
using System.Collections.Generic;
using IFXAnimEffect;

namespace Engage.IFX.NetworkStates
{
    public class NetworkStateModule_IFXAnimEffect_Variable : NetworkStateModule
    {
        bool firstSync=false;
        [SerializeField]
        private IFXAnimationEffectFloatVariable[] animEffectVariables;     
    }
}