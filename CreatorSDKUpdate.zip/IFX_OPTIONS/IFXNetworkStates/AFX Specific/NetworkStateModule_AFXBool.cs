
using UnityEngine;
using System.Collections.Generic;
using AFX;

namespace Engage.IFX.NetworkStates
{
    public class NetworkStateModule_AFXBool : NetworkStateModule
    {
        bool firstSync=false;
        [SerializeField]
        private BoolComponent[] afxBools;        
    }
}