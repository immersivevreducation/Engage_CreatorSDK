
using UnityEngine;
using System.Collections.Generic;
using AFX;

namespace Engage.IFX.NetworkStates
{
    public class NetworkStateModule_AFXInt : NetworkStateModule
    {
        bool firstSync = false;
        [SerializeField]
        private IntComponent[] afxInts;

    }
}