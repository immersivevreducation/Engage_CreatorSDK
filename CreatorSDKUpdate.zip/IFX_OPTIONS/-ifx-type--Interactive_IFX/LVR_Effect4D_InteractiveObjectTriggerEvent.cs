﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class LVR_Effect4D_InteractiveObjectTriggerEvent : MonoBehaviour
{
    public bool triggerManually;
    public UnityEvent additionalEventAfterTrigger;

}
