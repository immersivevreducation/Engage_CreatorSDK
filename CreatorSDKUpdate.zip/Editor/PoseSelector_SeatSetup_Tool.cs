﻿using System.Collections;
using System.Collections.Generic;
using Engage.Avatars.Poses;
using UnityEngine;
using UnityEditor;
public class PoseSelector_SeatSetup_Tool : EditorWindow
{

    [MenuItem("Tools/PoseSelector Seat Setup Tool")]
    private static void ShowWindow()
    {
        var window = GetWindow<PoseSelector_SeatSetup_Tool>();
        window.titleContent = new GUIContent("PoseSelector Seat Setup");
        window.Show();
    }
    GameObject previewMesh;
    GameObject poseSelectorTemplate;
    PoseSelector internalPoseSelector;
    SerializedObject serializedPoseSelector;
    string destinationFolder;
    bool overrideExistingPoseSelectors = false;
    private List<PoseDataAsset> openLegsPoses = new List<PoseDataAsset>();
    [SerializeField]
    private List<PoseDataAsset> closedLegsPoses = new List<PoseDataAsset>();

    List<GameObject> rapidEditSeatsCreated = new List<GameObject>();
    private void OnStart()
    {

    }
    void OnDestroy()
    {
        DestroyImmediate(poseSelectorTemplate);
    }

    private void OnGUI()
    {

        overrideExistingPoseSelectors = EditorGUILayout.Toggle("Override Existing PoseSelectors", overrideExistingPoseSelectors);
        if (poseSelectorTemplate == null)
        {
            poseSelectorTemplate = new GameObject("PoseSelector Template");
            //poseSelectorTemplate.hideFlags = HideFlags.HideInHierarchy;
            internalPoseSelector = poseSelectorTemplate.AddComponent<PoseSelector>();
            serializedPoseSelector = new SerializedObject(internalPoseSelector);
            //SerializedObject serializedObject = new SerializedObject(internalPoseSelector);

        }
        if (serializedPoseSelector != null)
        {
            EditorGUILayout.PropertyField(serializedPoseSelector.FindProperty("openLegsPoses"), includeChildren: true);
            EditorGUILayout.PropertyField(serializedPoseSelector.FindProperty("closedLegsPoses"), includeChildren: true);
        }


        if (GUILayout.Button("Set Up PoseSelector On Seats"))
        {
            foreach (var seat in GetSitTriggers())
            {
                Debug.Log("Sit Trigger Found on:" + seat.gameObject.name);
                if (overrideExistingPoseSelectors)
                {
                    PoseSelector[] toDelete = seat.GetComponentsInChildren<PoseSelector>();
                    foreach (var item in toDelete)
                    {
                        DestroyImmediate(item);
                    }
                }
                if (seat.gameObject.GetComponentsInChildren<PoseSelector>().Length < 1)
                {
                    PoseSelector poseSelector = seat.gameObject.AddComponent<PoseSelector>();
                    poseSelector.SitTriggerSeatPosition = seat.m_seatPosition;
                    poseSelector.closedLegsPoses = internalPoseSelector.closedLegsPoses;
                    poseSelector.openLegsPoses = internalPoseSelector.openLegsPoses;
                    serializedPoseSelector.ApplyModifiedProperties();
                }
            }

        }
        previewMesh = EditorGUILayout.ObjectField(previewMesh, typeof(GameObject), true) as GameObject;
        if (GUILayout.Button("Rapid Pose Edit"))
        {
            rapidEditSeatsCreated.Clear();
            PoseSelector poseSelector = Selection.activeGameObject.GetComponent<PoseSelector>();
            LVR_SitTrigger sitTrigger = poseSelector.gameObject.GetComponent<LVR_SitTrigger>();
            List<PoseDataAsset> allPoses = new List<PoseDataAsset>();
            foreach (var pose in poseSelector.closedLegsPoses)
            {
                allPoses.Add(pose);
            }
            foreach (var pose in poseSelector.openLegsPoses)
            {
                allPoses.Add(pose);
            }

            float ammountToMoveUp = 1;
            foreach (var pose in allPoses)
            {
                Vector3 spawnPos = poseSelector.gameObject.transform.position + Vector3.right * ammountToMoveUp;


                GameObject rapidEditSeat = Instantiate(poseSelector.gameObject.transform.gameObject, spawnPos, Quaternion.identity) as GameObject;

                rapidEditSeat.name = pose.name + "_RapidEditSeat";

                PoseSelector LocalPoseSelector = rapidEditSeat.GetComponent<PoseSelector>();
                LocalPoseSelector.poseToEdit = pose;
                LocalPoseSelector.editMode = true;

                ammountToMoveUp += 1f;
                rapidEditSeatsCreated.Add(rapidEditSeat);

                if (previewMesh != null)
                {
                    Vector3 meshReletivePos = poseSelector.gameObject.transform.position - previewMesh.transform.position;

                    GameObject rapidEditSeatMesh = Instantiate(previewMesh, spawnPos - meshReletivePos, Quaternion.identity) as GameObject;
                    rapidEditSeatMesh.name = pose.name + "_RapidEditSeat_previewMesh";
                    rapidEditSeatsCreated.Add(rapidEditSeatMesh);
                }

            }
            foreach (var seat in rapidEditSeatsCreated)
            {
                seat.transform.position += Vector3.up * 1;
            }
        }
        if (GUILayout.Button("Remove Rapid Edit Seats - closing this window will make this not work"))
        {

            foreach (var seat in rapidEditSeatsCreated)
            {
                DestroyImmediate(seat);
            }
        }
        //destinationFolder = EditorGUILayout.TextField("Destination Folder:", destinationFolder);
        //if (GUILayout.Button("Set Destination Folder"))
        //{
        //    destinationFolder = AssetDatabase.GetAssetPath(Selection.activeObject) + "/NewPoseData.asset";
        //}
        //if (GUILayout.Button("Create New PoseData Asset In selected folder"))
        //{
        //    destinationFolder = AssetDatabase.GetAssetPath(Selection.activeObject) + "/NewPoseData.asset";
        //    PoseDataAsset asset = ScriptableObject.CreateInstance<PoseDataAsset>();
        //    AssetDatabase.CreateAsset(internalPoseSelector.CreateBackUpPose(Vector3.zero), destinationFolder);
        //    AssetDatabase.SaveAssets();

        //    EditorUtility.FocusProjectWindow();
        //}
    }

    private static List<LVR_SitTrigger> GetSitTriggers()
    {
        List<LVR_SitTrigger> sitTriggers = new List<LVR_SitTrigger>();
        foreach (var GO in Selection.gameObjects)
        {
            foreach (var sitTrigger in GO.GetComponentsInChildren<LVR_SitTrigger>())
            {
                sitTriggers.Add(sitTrigger);
            }

        }
        return sitTriggers;
    }
}

