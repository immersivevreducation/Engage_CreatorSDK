﻿using UnityEngine;

namespace Engage.CreatorSDK
{
    public static class BoundsExtensions
    {
        public static Vector3 GetPoint(this Bounds bounds, Vector3 normalizedPosition)
        {
            return bounds.center + Vector3.Scale(bounds.extents, normalizedPosition);
        }
    }
}