﻿namespace Engage
{
    public static partial class Keys
    {
        public const string currentLocalBuildPathKey = "CurrentBuildPath";
        public const string currentBuildTargets = "CurrentBuildTargets";
    }
}