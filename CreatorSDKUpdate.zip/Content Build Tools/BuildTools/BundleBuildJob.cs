﻿using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace Engage.CreatorSDK
{
    public enum AssetType
    {
        Undefined = 0,
        Location = 1,
        IFX = 2,
        Snapshot
    }

    public class BundleBuildJob : IDisposable
    {
        protected BundleBuildJob() { }

        public BundleBuildJob(string guid)
        {
            BundleGuid = guid;
            BundlePath = AssetDatabase.GUIDToAssetPath(guid);
            BundleLabel = Path.GetFileNameWithoutExtension(BundlePath);

            Initialize();
        }

        public string BundleGuid { get; }
        public string BundlePath { get; }
        public EngagePlatform BuildTargets { get; set; }

        protected AssetType assetType;
        public AssetType AssetType { get; set; }

        protected string bundleLabel;
        public string BundleLabel
        {
            get => bundleLabel;
            set
            {
                bundleLabel = value.ToLower().Replace(' ', '_');
            }
        }

        public bool IsQAPassed { get; protected set; }
        public float Progress { get; protected set; }
        public bool Done { get; protected set; }

        public bool buildQACheckOverride { get; set; }

        public void Initialize()
        {
            UpdateAssetType();

            IsQAPassed = AssetType != AssetType.Undefined;

            //TODO: run QA tests for real
        }

        public async void RunQATests()
        {
            //if (!buildQACheckOverride)
            //{
            //    var qaTool = UnityEngine.ScriptableObject.CreateInstance<IFXToolsQualityCheckTool>();

            //    // repaint

            //    IsQAPassed = await qaTool.BundleQualityCheck(this);

            //    // repaint
            //}
        }

        public void Dispose()
        {
            //throw new System.NotImplementedException();
        }

        public void UpdateAssetType()
        {
            Debug.Log($"PATH: {BundlePath} (Valid Folder: {AssetDatabase.IsValidFolder(BundlePath)})");
            var bundlePath = new string[] { BundlePath };

            if (AssetDatabase.FindAssets("t:scene", bundlePath).Length > 0)
            {
                AssetType = AssetType.Location;
            }
            else if (AssetDatabase.FindAssets("t:prefab", bundlePath).Length > 0)
            {
                AssetType = AssetType.IFX;
            }
            else
            {
                AssetType = AssetType.Undefined;
            }
        }

        public string[] GetAssetList()
        {
            var assetList = new string[] { BundlePath };

            if (AssetType == AssetType.Location)
            {
                var guids = AssetDatabase.FindAssets("t:scene", assetList);
                assetList = new string[guids.Length];

                for (int i = 0; i < guids.Length; i++)
                {
                    assetList[i] = AssetDatabase.GUIDToAssetPath(guids[i]);
                }
            }
            else if (AssetType == AssetType.IFX)
            {
                var guids = AssetDatabase.FindAssets("t:prefab", assetList);
                assetList = new string[guids.Length];

                for (int i = 0; i < guids.Length; i++)
                {
                    assetList[i] = AssetDatabase.GUIDToAssetPath(guids[i]);
                }
            }

            return assetList;
        }
    }
}