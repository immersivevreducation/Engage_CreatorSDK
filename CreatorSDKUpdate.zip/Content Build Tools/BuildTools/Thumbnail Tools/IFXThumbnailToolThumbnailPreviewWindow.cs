﻿
using UnityEngine;
using UnityEditor;

namespace Engage.CreatorSDK
{
    public class IFXThumbnailToolThumbnailPreviewWindow : EditorWindow
    {
        
        IFXThumbnailTool _thumbnailToolInstance;
        
        public IFXThumbnailToolThumbnailPreviewWindow(IFXThumbnailTool thumbnailToolInstance)
        {
            _thumbnailToolInstance = thumbnailToolInstance;
            this.minSize = new Vector2(750,500);
        }
        void OnGUI()
        {
            EditorGUILayout.LabelField("IFX Thumbnail Creation Tool");
            //the thumbnail preview
            if (_thumbnailToolInstance.ifxObject!=null)
            {
                GUILayout.Label(_thumbnailToolInstance.previewImage, GUILayout.Width(this.position.width), GUILayout.Height(this.position.height));
                var thumbnailPreviewRect = GUILayoutUtility.GetLastRect();
                //_thumbnailToolInstance.UpdatePreviewImage();
                this.Repaint();
            }                        
        }
        void OnDestroy()
        {
            DestroyImmediate(_thumbnailToolInstance.ifxObject, true);
        }
    }
}
        
    