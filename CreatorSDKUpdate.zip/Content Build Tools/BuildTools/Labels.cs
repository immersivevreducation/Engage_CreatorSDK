﻿namespace Engage.CreatorSDK
{
    public class Labels
    {
        public const string Close = "Close";

        public const string LocalBuildPath = "Local Build Path";
        public const string SelectLocalBuildPathTitle = "Select Local Bundle Location";
        public const string Ellipsis = "⋯";
        public const string BuildTargets = "Default Build Targets";

        public const string ResetToDefault = "Reset to Default";
        public const string ResetConfirmTitle = "Confirm Reset";
        public const string ResetConfirmMessage = "Reset build settings to default values?";
        public const string Reset = "Reset";
        public const string Cancel = "Cancel";
        public const string Refresh = "Refresh";
    }
}
