﻿using System.Collections.Generic;
using UnityEngine;
using Engage.UI.Editor;
using System;
using UnityEditor;
using System.IO;
using System.Linq;

namespace Engage.CreatorSDK
{
    public class ImageBuilder : ViewModel
    {
        // Geometry: Quad or Two-Sided Quad
        public bool MaintainRatio { get => ImageSettings.MaintainRatio; set => ImageSettings.MaintainRatio = value; }
        public bool MaintainTransparency { get => ImageSettings.MaintainTransparency; set => ImageSettings.MaintainTransparency = value; }
        public bool GenerateMipmaps { get => ImageSettings.GenerateMipmaps; set => ImageSettings.GenerateMipmaps = value; }
        public float MipmapBias { get => ImageSettings.MipmapBias; set => ImageSettings.MipmapBias = value; }
        // SetMax Texture Resolution
        //public string PrefabFolderPath { get => ImageSettings.PrefabFolderPath; set => ImageSettings.PrefabFolderPath = value; }

        public string[] TextureSizeOptions => ImageSettings.TextureSize.Select(tex => tex.ToString()).ToArray();

        private int? maxSizeIndex;
        public int MaxSizeIndex
        {
            get
            {
                if (!maxSizeIndex.HasValue)
                {
                    for(int i = 0; i < ImageSettings.TextureSize.Length; i++)
                    {
                        maxSizeIndex = i;
 
                        if (ImageSettings.TextureSize[i] >= ImageSettings.MaxTextureSize)
                        {
                            break;
                        }
                    }
                }

                return maxSizeIndex.Value;
            }
            set
            {
                if (maxSizeIndex != value)
                {
                    ImageSettings.MaxTextureSize = ImageSettings.TextureSize[value];
                }

                maxSizeIndex = value;
            }
        }

        public List<Texture> ImageList { get; internal set; } = new List<Texture>();

        protected override void Initialize()
        {
            base.Initialize();
            Refresh();
        }

        public override void Refresh()
        {
            ImageList.Clear();

            foreach (var guid in Selection.assetGUIDs)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);

                if (AssetDatabase.IsValidFolder(path))
                {
                    foreach (var assetPath in Directory.EnumerateFiles(path))
                    {
                        var image = AssetDatabase.LoadAssetAtPath<Texture>(assetPath);

                        if (image)
                        {
                            ImageList.Add(image);
                        }
                    }
                }
                else
                {
                    var image = AssetDatabase.LoadAssetAtPath<Texture>(path);

                    if (image)
                    {
                        ImageList.Add(image);
                    }
                }
            }
        }

        public void ApplyTextureSettings()
        {
            foreach (var image in ImageList)
            {
                ImageTools.ApplyImportSettings(image);
            }
        }

        public void BuildImages()
        {
            foreach(var image in ImageList)
            {
                ImageTools.ApplyImportSettings(image);
                ImageTools.CreateImagePrefab(image);
            }
        }

        public void ResetImageSettings()
        {
            maxSizeIndex = null;
            ImageSettings.ResetToDefaults();
            NotifyPropertyChange(nameof(ImageSettings));
        }
    }
}
