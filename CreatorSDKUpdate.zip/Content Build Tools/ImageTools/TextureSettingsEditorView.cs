using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;

namespace Engage.CreatorSDK
{
    public class TextureSettingsEditorView : View<ImageBuilder>
    {
        private Vector2 scrollPos;
        private const float verticalSpace = 20f;

        private class Labels : CreatorSDK.Labels
        {
            public const string MenuTitle = "Edit Texture Properties";
            public const string ViewTitle = "Edit Texture Properties";
        }

        [MenuItem(MenuLabels.AssetsToolsPath + Labels.MenuTitle, priority = MenuLabels.AssetToolsPriority + 1)]
        [MenuItem(MenuLabels.CreatorSDKToolsPath + Labels.MenuTitle, priority = MenuLabels.AssetToolsPriority + 1)]
        public static void OpenView() => GetWindow<TextureSettingsEditorView>(title: Labels.ViewTitle).Open();

        public override void Draw()
        {
            GUILayout.Space(verticalSpace);

            GuiTools.DrawHeader("Texture Settings");

            using (var settingsPanel = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                ViewModel.MaintainRatio = EditorGUILayout.Toggle("Maintain Ratio", ViewModel.MaintainRatio);
                ViewModel.MaintainTransparency = EditorGUILayout.Toggle("Maintain Transparency", ViewModel.MaintainTransparency);
                ViewModel.GenerateMipmaps = EditorGUILayout.Toggle("Generate Mipmaps", ViewModel.GenerateMipmaps);
                ViewModel.MipmapBias = EditorGUILayout.FloatField("Mipmap Bias", ViewModel.MipmapBias);
                ViewModel.MaxSizeIndex = EditorGUILayout.Popup("Max Size", ViewModel.MaxSizeIndex, ViewModel.TextureSizeOptions);

                GUILayout.Space(verticalSpace);

                GuiTools.DrawButton("Reset to Defaults", ViewModel.ResetImageSettings);
            }

            GUILayout.Space(verticalSpace);

            GuiTools.DrawHeader("Selected Textures");

            DrawQueue();

            using (var buttons = new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(Labels.Refresh))
                {
                    ViewModel.Refresh();
                }

                if (GUILayout.Button("Apply"))
                {
                    ViewModel.BuildImages();
                }
            }

            EditorGUILayout.Space();
        }

        private void DrawQueue()
        {
            using (var scrollArea = new GuiTools.ScrollArea(ref scrollPos, EditorStyles.helpBox))
            {
                foreach (var image in ViewModel.ImageList)
                {
                    DrawImage(image);
                }
            }
        }

        private void DrawImage(Texture image)
        {
            using (var imageRow = new EditorGUILayout.HorizontalScope())
            {
                image.name = EditorGUILayout.TextField(image.name);
                EditorGUILayout.LabelField($"({image.width} x {image.height})");
            }
        }
    }
}