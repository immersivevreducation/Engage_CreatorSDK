﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;
using UnityEditor;
using Engage.UI.Editor;

namespace Engage.CreatorSDK
{
    public static class ImageTools
    {
        public const string twoSidedQuad = "Two-Sided Quad";

        public static void CreateImagePrefab()
        {
            var images = new List<Texture>();

            foreach (var guid in Selection.assetGUIDs)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);

                if (AssetDatabase.IsValidFolder(path))
                {
                    foreach (var assetPath in Directory.EnumerateFiles(path))
                    {
                        images.Add(AssetDatabase.LoadAssetAtPath<Texture>(assetPath));
                    }
                }
                else
                {
                    images.Add(AssetDatabase.LoadAssetAtPath<Texture>(path));
                }
            }

            CreateImagePrefab(images);
        }

        public static void CreateImagePrefab(IEnumerable<Texture> images)
        {
            foreach (var image in images)
            {
                if (!image)
                    return;

                CreateImagePrefab(image);
            }
        }

        public static GameObject CreateImagePrefab(Texture image)
        {
            if (image == null)
                return null;

            var imagePath = AssetDatabase.GetAssetPath(image);
            var imageFolder = Path.GetDirectoryName(imagePath);

            var imageObjectRoot = new GameObject(image.name);
            var imageObject = new GameObject(twoSidedQuad);
            imageObject.transform.SetParent(imageObjectRoot.transform);

            var material = CreateUnlitTextureMaterial(image as Texture2D);
            var mesh = CreateTwoSidedQuadMesh();
            var geometry = imageObject.AddGeometry();

            geometry.renderer.material = material;
            geometry.filter.mesh = mesh;

            imageObject.SetRatio(image.width, image.height);

            string materialPath = AssetDatabase.GenerateUniqueAssetPath($"{imageFolder}/{image.name}.mat");
            string meshPath = AssetDatabase.GenerateUniqueAssetPath($"{imageFolder}/{image.name}.mesh");
            string prefabPath = AssetDatabase.GenerateUniqueAssetPath($"{imageFolder}/{image.name}.prefab");

            AssetDatabase.CreateAsset(material, materialPath);
            AssetDatabase.CreateAsset(mesh, meshPath);

            return PrefabUtility.SaveAsPrefabAssetAndConnect(imageObjectRoot, prefabPath, InteractionMode.UserAction);
        }

        [MenuItem(MenuLabels.GameObjectPrimitivesContext + twoSidedQuad)]
        public static GameObject CreateTwoSidedQuad()
        {
            var imageObject = new GameObject("Two Sided Quad");

            var material = AssetDatabase.GetBuiltinExtraResource<Material>("Default-Diffuse.mat");
            var mesh = FindTwoSidedQuad();
            var geometry = imageObject.AddGeometry();

            geometry.renderer.material = material;
            geometry.filter.mesh = mesh;

            return imageObject;
        }

        public static (MeshFilter filter, MeshRenderer renderer) AddGeometry(this GameObject gameObject)
        {
            var renderer = gameObject.AddComponent<MeshRenderer>();
            var filter = gameObject.AddComponent<MeshFilter>();

            return (filter, renderer);
        }

        public static Mesh FindTwoSidedQuad()
        {
            var finds = AssetDatabase.FindAssets("t:mesh " + twoSidedQuad);

            if (finds.Length > 0)
            {
                return AssetDatabase.LoadAssetAtPath<Mesh>(AssetDatabase.GUIDToAssetPath(finds[0]));
            }
            else
            {
                var mesh = CreateTwoSidedQuadMesh();
                string meshPath = AssetDatabase.GenerateUniqueAssetPath($"Assets/{twoSidedQuad}.mesh");
                AssetDatabase.CreateAsset(mesh, meshPath);

                return mesh;
            }
        }

        public static Mesh CreateTwoSidedQuadMesh()
        {
            var mesh = new Mesh();

            var leftEdge = new Vector3[] { new Vector3(-0.5f, -0.5f, 0), new Vector3(-0.5f, 0.5f, 0) };
            var rightEdge = new Vector3[] { new Vector3(0.5f, -0.5f, 0), new Vector3(0.5f, 0.5f, 0) };

            var verts = new List<Vector3>();
            var tris = new List<int>();
            var UVs = new List<Vector2>();

            verts.AddRange(leftEdge);
            verts.AddRange(rightEdge);
            verts.AddRange(rightEdge);
            verts.AddRange(leftEdge);

            var triangle1 = new int[] { 0, 3, 1 };
            var triangle2 = new int[] { 0, 2, 3 };
            tris.AddRange(triangle1);
            tris.AddRange(triangle2);
            tris.AddRange(triangle1.Select(v => v + 4));
            tris.AddRange(triangle2.Select(v => v + 4));

            var offset = Vector2.one * 0.5f;

            UVs.AddRange(rightEdge.Select(vert => (Vector2)vert + offset));
            UVs.AddRange(leftEdge.Select(vert => (Vector2)vert + offset));
            UVs.AddRange(rightEdge.Select(vert => (Vector2)vert + offset));
            UVs.AddRange(leftEdge.Select(vert => (Vector2)vert + offset));

            mesh.vertices = verts.ToArray();
            mesh.triangles = tris.ToArray();
            mesh.uv = UVs.ToArray();
            mesh.RecalculateNormals();

            return mesh;
        }

        public static Material CreateUnlitTextureMaterial(Texture2D image)
        {
            if (image == null)
                return new Material(Shader.Find(ImageSettings.ImageShaders[ShaderType.UnlitTexture]));

            var shader = image.alphaIsTransparency ?
                ImageSettings.ImageShaders[ShaderType.UnlitTransparentCutout] :
                ImageSettings.ImageShaders[ShaderType.UnlitTexture];

            var material = new Material(Shader.Find(shader));
            material.mainTexture = image;
            material.name = image.name;

            return material;
        }

        public static void SetRatio(this GameObject gameObject, float width, float height)
        {
            float ratio = Mathf.Min(width, height) / Mathf.Max(width, height);

            gameObject.transform.localScale = width > height ?
                 new Vector3(1f, ratio, 1f) :
                 new Vector3(ratio, 1f, 1f);
        }

        public static void ApplyImportSettings(this Texture image)
        {
            string path = AssetDatabase.GetAssetPath(image);
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;

            if (importer == null)
                return;

            importer.npotScale = TextureImporterNPOTScale.None;
            importer.alphaIsTransparency = ImageSettings.MaintainTransparency && importer.DoesSourceTextureHaveAlpha();
            importer.mipmapEnabled = ImageSettings.GenerateMipmaps;
            importer.mipMapBias = ImageSettings.MipmapBias;
            importer.maxTextureSize = ImageSettings.MaxTextureSize;

            AssetDatabase.ImportAsset(path);
        }

        public static Vector2 GetNativeSize(this Texture image)
        {
            var size = Vector2.one;
            var texture = new Texture2D(1, 1);

            string path = AssetDatabase.GetAssetPath(image);

            try
            {
                var imageBytes = File.ReadAllBytes(path);
                texture.LoadImage(imageBytes);
                size = new Vector2(texture.width, texture.height);
            }
            catch { }

            return size;
        }
    }
}
