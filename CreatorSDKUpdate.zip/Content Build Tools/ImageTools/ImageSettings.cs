﻿using System.Collections.Generic;
using Engage.UI.Editor;
using UnityEditor;

namespace Engage.CreatorSDK
{
    public enum ShaderType
    {
        UnlitTexture,
        UnlitTransparent,
        UnlitTransparentCutout
    }

    public class ImageSettings : Settings<ImageSettings>
    {
        private readonly Dictionary<ShaderType, string> imageShaders = new Dictionary<ShaderType, string>()
        {
            { ShaderType.UnlitTexture, "Unlit/Texture" },
            { ShaderType.UnlitTransparent, "Unlit/Transparent" },
            { ShaderType.UnlitTransparentCutout, "Unlit/Transparent Cutout" }
        };

        private readonly int[] textureSize = new int[]
        {
            32,
            64,
            128,
            256,
            512,
            1024,
            2048,
            4096,
            8192
        };

        private readonly Setting<bool> maintainRatio;
        private readonly Setting<bool> maintainTransparency;
        private readonly Setting<bool> generateMipmaps;
        private readonly Setting<float> mipmapBias;
        private readonly Setting<int> maxTextureSize;

        public ImageSettings()
        {
            RegisterBool(GetKey(nameof(MaintainRatio)), ref maintainRatio, true);
            RegisterBool(GetKey(nameof(MaintainTransparency)), ref maintainTransparency, true);
            RegisterBool(GetKey(nameof(GenerateMipmaps)), ref generateMipmaps, true);
            RegisterFloat(GetKey(nameof(MipmapBias)), ref mipmapBias, -100);
            RegisterInt(GetKey(nameof(MaxTextureSize)), ref maxTextureSize, 2048);
        }

        public static int[] TextureSize => Instance.textureSize;
        public static Dictionary<ShaderType, string> ImageShaders => Instance.imageShaders;

        public static bool MaintainRatio { get => Instance.maintainRatio; set => Instance.maintainRatio.Value = value; }
        public static bool MaintainTransparency { get => Instance.maintainTransparency; set => Instance.maintainTransparency.Value = value; }
        public static bool GenerateMipmaps { get => Instance.generateMipmaps; set => Instance.generateMipmaps.Value = value; }
        public static float MipmapBias { get => Instance.mipmapBias; set => Instance.mipmapBias.Value = value; }
        public static int MaxTextureSize { get => Instance.maxTextureSize; set => Instance.maxTextureSize.Value = value; }

        public static void ResetToDefaults()
        {
            Instance.Reset(GetKey(nameof(MaintainRatio)), Instance.maintainRatio);
            Instance.Reset(GetKey(nameof(MaintainTransparency)), Instance.maintainTransparency);
            Instance.Reset(GetKey(nameof(GenerateMipmaps)), Instance.generateMipmaps);
            Instance.Reset(GetKey(nameof(MipmapBias)), Instance.mipmapBias);
            Instance.Reset(GetKey(nameof(MaxTextureSize)), Instance.maxTextureSize);
        }
    }
}
