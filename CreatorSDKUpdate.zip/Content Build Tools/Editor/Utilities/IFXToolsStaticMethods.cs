﻿using UnityEditor;
using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using Debug = UnityEngine.Debug;

namespace Engage.CreatorSDK
{
    public class IFXToolsStaticMethods
    {
        public static string[] GetAllScriptsInProject()
        {
            string[] filesOfType = Directory.GetFiles(Application.dataPath, "*.cs", SearchOption.AllDirectories);
            return filesOfType;
        }

        public static string RunCMD(List<string> arguments)
        {
            Process cmd = new Process();
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = "cmd.exe";

            info.WindowStyle = ProcessWindowStyle.Hidden;
            info.CreateNoWindow = true;

            info.RedirectStandardInput = true;
            info.RedirectStandardOutput = true;
            info.UseShellExecute = false;
            cmd.StartInfo = info;
            cmd.Start();
            using (StreamWriter sw = cmd.StandardInput)
            {
                if (sw.BaseStream.CanWrite)
                {
                    foreach (string arg in arguments)
                    {

                        //string argIN = arg.Replace("/","\\");
                        sw.WriteLine(arg);
                        Debug.Log("CMD LINE input command: " + arg);
                    }
                }

            }
            // Synchronously read the standard output of the process.
            string output = cmd.StandardOutput.ReadToEnd();

            cmd.StandardInput.Close();
            cmd.WaitForExit();
            return output;
        }

        public static List<string> GetFolderDependencies(List<UnityEngine.Object> listOfObjectsIn) // get dependencies for every object in folder
        {
            List<string> result = new List<string>();

            foreach (var obj in listOfObjectsIn)
            {
                string assetPath = AssetDatabase.GetAssetPath(obj);
                AssetImporter assetImporter = AssetImporter.GetAtPath(assetPath);

                if (assetImporter.assetBundleName != obj.name)
                {
                    assetImporter.assetBundleName = obj.name;
                }

                string[] assetsInCurBundle = AssetDatabase.GetAssetPathsFromAssetBundle(assetImporter.assetBundleName);

                foreach (string item in assetsInCurBundle)
                {
                    string[] dependencies = AssetDatabase.GetDependencies(item, true);

                    foreach (var item2 in dependencies)
                    {
                        result.Add(item2);
                    }
                }
            }

            return result;
        }

        //quicktools related methods////////////////////////////////////////////////////////////////
        public static bool ObjectPivotCenteredCheck(GameObject sourceGO, bool useAleternateCenter = false)
        {
            bool objectIsCentered = true;
            float diffrenceTollerence = 2f;
            Vector3 sceneCenter = new Vector3(0, 0, 0);
            Vector3 center = GetAverageCenter(sourceGO, useAleternateCenter);

            float diff = center.sqrMagnitude;
            if (diff >= diffrenceTollerence)
            {
                objectIsCentered = false;
            }
            return objectIsCentered;
        }

        public static Vector3 MeshCenter(GameObject inputGO)
        {
            MeshFilter meshFilter = inputGO.GetComponent<MeshFilter>();
            if (meshFilter != null)
            {
                Mesh mesh = meshFilter.sharedMesh;
                Vector3[] vertices = mesh.vertices;
                Bounds tempBounds = new Bounds(inputGO.transform.TransformPoint(mesh.bounds.center), new Vector3(0, 0, 0));
                for (var i = 0; i < vertices.Length; i++)
                {
                    tempBounds.Encapsulate(inputGO.transform.TransformPoint(vertices[i]));
                }
                Vector3 result = tempBounds.center;
                return tempBounds.center;
            }
            else
            {
                return Vector3.zero;
            }

        }

        private static Vector3 GetAverageCenter(GameObject inputGO, bool useAleternateCenter = false)
        {
            //index error here
            Bounds tempBounds;
            Vector3 centerAverage;
            if (useAleternateCenter)
            {

                MeshFilter[] mFInChildren = inputGO.GetComponentsInChildren<MeshFilter>();

                if (mFInChildren.Length > 0)
                {
                    tempBounds = new Bounds(MeshCenter(mFInChildren[0].gameObject), Vector3.zero);
                    for (var i = 0; i < mFInChildren.Length; i++)
                    {
                        GameObject child = mFInChildren[i].gameObject;
                        Debug.Log("children: " + child.name);

                        Vector3 meshCenter = MeshCenter(child.gameObject);

                        tempBounds.Encapsulate(meshCenter);
                    }
                    centerAverage = tempBounds.center;
                    centerAverage = Vector3.zero;
                }
                else
                {
                    Debug.Log("no Meshfilter Components found use other centering method");
                    centerAverage = Vector3.zero;
                }
            }
            else
            {
                List<Vector3> boundsCenterList = new List<Vector3>();
                Renderer[] renderComponentsInChildren = inputGO.GetComponentsInChildren<Renderer>();

                if (renderComponentsInChildren.Length > 0)
                {

                    foreach (Renderer renderComponent in renderComponentsInChildren)
                    {
                        //Debug.Log("Render Components test");
                        boundsCenterList.Add(renderComponent.bounds.center);
                    }
                    //Debug.Log("Render Components it aint null bruh");
                    tempBounds = new Bounds(boundsCenterList[0], Vector3.zero);
                    foreach (Vector3 bound in boundsCenterList)
                    {
                        tempBounds.Encapsulate(bound);
                    }
                    centerAverage = tempBounds.center;
                }
                else
                {
                    Debug.Log("no Render Components found use other centering method");
                    centerAverage = Vector3.zero;
                }
            }
            return centerAverage;
        }

        public static void CenterIFX(GameObject inputGO, bool useAleternateCenter = false)
        {
            //if it has an asset path AKA it's a prefab then load that prefab for editing otherwise just use the scene GO
            GameObject prefabRoot = inputGO;
            string assetPath = "";
            assetPath = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(inputGO);
            //Debug.Log("Asset path is: "+assetPath);
            if (assetPath != "")
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(assetPath);
            }
            Vector3 averageCenter = GetAverageCenter(prefabRoot, useAleternateCenter);
            //Need to load all the direct children transforms into a list before reparenting or the foreach count gets confused 
            List<Transform> childrenTransformsList = new List<Transform>();
            //create a GO that is moved to the averaged center of geo. Paaretn everything to it then move it to 0,0,0
            GameObject offsetMoverGO = new GameObject();
            offsetMoverGO.name = "ReCentering Mover";
            offsetMoverGO.transform.parent = prefabRoot.transform;
            offsetMoverGO.transform.position = averageCenter;
            //Debug.Log("average center is: "+averageCenter);
            //Debug.Log("mover pos is: "+offsetMoverGO.transform.position);
            //Debug.Log(prefabRoot.transform.childCount);
            foreach (Transform child in prefabRoot.transform)
            {
                Debug.Log(child.name);
                childrenTransformsList.Add(child.transform);
            }
            foreach (Transform child in childrenTransformsList)
            {
                child.transform.SetParent(offsetMoverGO.transform);
            }
            //move the offset back to zero
            offsetMoverGO.transform.position = new Vector3(0, 0, 0);
            //parent all the objects back to their original parent then delete the offset mover
            foreach (Transform child in childrenTransformsList)
            {
                child.transform.SetParent(prefabRoot.transform);
            }

            Object.DestroyImmediate(offsetMoverGO);
            //if it was used on a prefab save it over the old prefab
            if (assetPath != "")
            {
                PrefabUtility.SaveAsPrefabAsset(prefabRoot, assetPath);
            }
        }

        public static void BatchCenterIFX(GameObject[] inputGO, bool useAleternateCenter = false)
        {
            foreach (GameObject GO in inputGO)
            {
                Debug.Log("got to batch center:");
                CenterIFX(GO, useAleternateCenter);
            }
        }

        public static void ImagePlaneFromImage()
        {
            UnityEngine.Object[] activeGOs = Selection.GetFiltered(typeof(Texture2D), SelectionMode.Editable | SelectionMode.TopLevel);
            float ratio1 = 1f;
            float ratio2 = 1f;

            if (activeGOs.Length > 0)
            {
                foreach (Texture2D image in activeGOs)
                {
                    var itemPath = AssetDatabase.GetAssetPath(image);
                    var itemDirectory = Path.GetDirectoryName(itemPath);

                    TextureImporter textureImporter = (TextureImporter)AssetImporter.GetAtPath(itemPath);
                    textureImporter.npotScale = TextureImporterNPOTScale.None;
                    textureImporter.SaveAndReimport();

                    GameObject plane = GameObject.CreatePrimitive(PrimitiveType.Plane);

                    ratio1 = image.height;
                    ratio2 = image.width;

                    //scale to the ratios
                    plane.transform.localScale = new Vector3(ratio2 / ratio1, 1, ratio1 / ratio1);

                    //Set the name
                    plane.name = image.name;

                    //Remove Colliders
                    Object.DestroyImmediate(plane.GetComponent<Collider>());

                    //Material Stuff
                    Renderer rend = plane.GetComponent<Renderer>();
                    Material material = new Material(Shader.Find("Unlit/Transparent Cutout"));
                    material.SetFloat("_Mode", 1.0f);
                    material = MaterialCutoutmode(material);
                    material.name = image.name + "_MAT";
                    material.SetTexture("_MainTex", image);
                    rend.material = material;

                    AssetDatabase.CreateAsset(material, itemDirectory + "/" + image.name + "_MAT.mat");

                    //Rotate
                    plane.transform.eulerAngles = new Vector3(90, 0, 0);

                    //Duplicate the plane
                    GameObject planeOtherSide = GameObject.Instantiate(plane, new Vector3(0, 0, 0), Quaternion.identity);
                    planeOtherSide.name = plane.name + "_OtherSide";
                    planeOtherSide.transform.eulerAngles = new Vector3(90, 0, 180);

                    //Paretnt to empty
                    GameObject topEmpty = new GameObject();
                    topEmpty.name = plane.name + "_ScaleThis";
                    plane.transform.parent = topEmpty.transform;
                    planeOtherSide.transform.parent = topEmpty.transform;
                }
            }
            else
            {
                Debug.Log("No image selected");
                EditorUtility.DisplayDialog("WARNING!", "Select an image in the project view first", "OK", "Cancel");
            }
        }

        private static Material MaterialCutoutmode(Material material)
        {
            material.SetOverrideTag("RenderType", "TransparentCutout");
            material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
            material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.Zero);
            material.SetInt("_ZWrite", 1);
            material.EnableKeyword("_ALPHATEST_ON");
            material.DisableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.AlphaTest;
            return material;
        }

        public static void CreateAnimClipsFromSelectedFBX()
        {
            string assetPath = AssetDatabase.GetAssetPath((GameObject)Selection.activeObject);

            ModelImporter MI = (ModelImporter)AssetImporter.GetAtPath(assetPath);
            ModelImporterClipAnimation[] clips = MI.clipAnimations;

            var itemPath = AssetDatabase.GetAssetPath(Selection.activeObject);
            var itemDirectory = Path.GetDirectoryName(itemPath);
            var findClipsAtPath = AssetDatabase.LoadAllAssetRepresentationsAtPath(itemPath);

            foreach (var aClips in findClipsAtPath)
            {
                var animationClip = aClips as AnimationClip;

                if (animationClip != null)
                {
                    var createController = UnityEditor.Animations.AnimatorController.CreateAnimatorControllerAtPathWithClip(itemDirectory + "/" + animationClip.name + "_ANIM_CONTROLLER.controller", animationClip);
                    Debug.Log("Found animation clip");
                }
            }
        }

        public static void InsertSelectedObjectIntoEmpty(GameObject[] selectedObjects, string prefix, string affix)
        {
            foreach (GameObject item in selectedObjects)
            {
                var topEmpty = new GameObject();
                topEmpty.name = prefix + item.name + affix;
                item.transform.parent = topEmpty.transform;
                topEmpty.transform.position = new Vector3(0, 0, 0);
                topEmpty.transform.eulerAngles = new Vector3(0, 0, 0);
            }
        }

        //Quality Check related methods////////////////////////////////////////////////////////////////
        public static void FixPrefabs(GameObject inputGO)
        {
            GameObject prefabRoot = inputGO;
            string assetPath = "";

            assetPath = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(prefabRoot);
            Debug.Log("Asset path is: " + assetPath);
            if (assetPath != "")
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(assetPath);
            }

            Camera[] cameras = prefabRoot.GetComponentsInChildren<Camera>();
            Collider[] colliders = prefabRoot.GetComponentsInChildren<Collider>();
            Light[] lights = prefabRoot.GetComponentsInChildren<Light>();
            LODGroup[] lodGroups = prefabRoot.GetComponentsInChildren<LODGroup>();

            foreach (Camera item in cameras)
            {
                Object.DestroyImmediate(item);
            }
            foreach (Collider item in colliders)
            {
                Object.DestroyImmediate(item);
            }
            foreach (Light item in lights)
            {
                Object.DestroyImmediate(item);
            }
            foreach (LODGroup item in lodGroups)
            {
                Object.DestroyImmediate(item);
            }

            PrefabZeroTransforms(prefabRoot);



            if (assetPath != "")
            {
                PrefabUtility.SaveAsPrefabAsset(prefabRoot, assetPath);
            }
            // center ifx opens prefab so it's better to keep it after the rest to avoid conflict then prefab is opened for above changes
            if (ObjectPivotCenteredCheck(inputGO))
            {
                CenterIFX(inputGO);
            }
        }

        public static List<string> PrefabQualityCheck(GameObject gameObjectToCheck)
        {

            List<string> errorsFound = new List<string>();


            if (gameObjectToCheck.transform.position != Vector3.zero | gameObjectToCheck.transform.rotation != Quaternion.identity | gameObjectToCheck.transform.localScale != new Vector3(1, 1, 1))
            {
                Debug.Log("Prefab Root not zeroed: ");

                errorsFound.Add("Prefab Root not zeroed");
            }

            if (ObjectPivotCenteredCheck(gameObjectToCheck) == false)
            {
                Debug.Log("Object appears off center: ");

                errorsFound.Add("Object Appears OffCenter");

            }
            if (gameObjectToCheck.GetComponentInChildren(typeof(Camera), true) != null)
            {
                Debug.Log("Camera component found within ");

                errorsFound.Add("Camera component found within: ");


            }

            if (gameObjectToCheck.GetComponentInChildren(typeof(Collider), true) != null)
            {
                Debug.Log("Collider component found within ");

                errorsFound.Add("Collider component found within: ");


            }

            if (gameObjectToCheck.GetComponentInChildren(typeof(Light), true) != null)
            {
                Debug.Log("Light component found within ");

                errorsFound.Add("Light component found within: ");

            }

            if (gameObjectToCheck.GetComponentInChildren(typeof(LODGroup), true) != null)
            {
                Debug.Log("LODGroup component found within ");

                errorsFound.Add("LODGroup component found within: ");
            }

            //if(gameObjectToCheck.GetComponentInChildren(typeof(AudioSource),true) != null && gameObjectToCheck.GetComponentInChildren(typeof(AudioDefaultScale),true) == null)
            //{
            //    Debug.Log("AudioSource component found within ");

            //    errorsFound.Add("AudioSource component requires \"AudioDefaultScale\" script: ");                
            //}

            return errorsFound;
        }


        public static void PrefabZeroTransforms(GameObject inputGO)
        {
            inputGO.transform.position = Vector3.zero;
            inputGO.transform.rotation = Quaternion.identity;
            inputGO.transform.localScale = new Vector3(1, 1, 1);
        }

    }
}
