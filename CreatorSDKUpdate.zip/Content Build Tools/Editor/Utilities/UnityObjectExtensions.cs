﻿using System.IO;
using UnityEditor;
using Object = UnityEngine.Object;

namespace Engage.CreatorSDK
{
    public static class UnityObjectExtensions
    {
        public static bool IsDirectory(this Object item) =>
            Directory.Exists(AssetDatabase.GetAssetPath(item.GetInstanceID()));

        public static void SetAssetLabelToFolderName(this Object item)
        {
            //This part changes the asset labelsS
            var itemPath = AssetDatabase.GetAssetPath(item);
            var itemFolderName = Path.GetFileName(itemPath);
            AssetImporter assetImporterForSelection = AssetImporter.GetAtPath(itemPath);
            assetImporterForSelection.assetBundleName = itemFolderName;
        }
    }
}
