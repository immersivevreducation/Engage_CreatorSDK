﻿
using UnityEngine;
using UnityEditor;
using System.IO;
using UnityEditor.SceneManagement;

namespace Engage.CreatorSDK
{
    public class IFXThumbnailToolWindow : EditorWindow
    {
        public static void Open()
        {
            var window = GetWindow<IFXThumbnailToolWindow>(title: "Thumbnail Tool");
            window.Show();
        }

        // IFXThumbnailToolWindow(string saveLocationPath = "")
        // {
        //     saveLocation = saveLocationPath;
        // }
        IFXThumbnailTool thumbnailToolInstance;
        
        IFXThumbnailToolThumbnailPreviewWindow thumbnailPreview;
        public string saveLocation;
        void OnEnable()
        {
            thumbnailToolInstance = new IFXThumbnailTool();
            thumbnailToolInstance.ThumbnailSetup(thumbnailToolInstance.ifxObject);
            this.minSize = new Vector2(300,450);
            
        }
        void OnDestroy()
        {
            thumbnailPreview.Close();
            //DestroyImmediate(thumbnailPreview, true);
        }
        void OnGUI()
        {
            ThumbnailToolWindowUI();
            if (thumbnailToolInstance!=null)
            {
                thumbnailToolInstance.ThumbnailToolControlsUI(); 
            }
                       
        }
        

        private void ThumbnailToolWindowUI()
        {
            // EditorGUILayout.LabelField("IFX Thumbnail Creation Tool");
            // //the thumbnail preview
            // GUILayout.Label(thumbnailToolInstance.previewImage, GUILayout.Width(500), GUILayout.Height(281));
            // var thumbnailPreviewRect = GUILayoutUtility.GetLastRect();

            if (GUILayout.Button("Load Thumbnail Scene"))
                {
                    if (EditorUtility.DisplayDialog("WARNING!", "Unsaved work in  the current scene will be lost", "Load IFX Thumbnail Scene", "Cancel"))
                    {
                        EditorSceneManager.OpenScene("Assets/ENGAGE_CreatorSDK/Editor/IFX Tools/ThumbnailToolAssets/IFX_Thumbnail_Scene.unity");
                    }
                
                }
            
            if (GUILayout.Button("Load Object for camera"))
            {
                if (thumbnailPreview == null)
                {
                    thumbnailPreview = new IFXThumbnailToolThumbnailPreviewWindow(thumbnailToolInstance);
                    //thumbnailPreview = GetWindow<IFXThumbnailToolThumbnailPreviewWindow>();
                    thumbnailPreview.position.Set(0,0,thumbnailToolInstance.imageResolutionWidth,thumbnailToolInstance.imageResolutionHeight);
                
                    //editorWindow.End();
                    thumbnailPreview.Show();

                }           
                


                if (thumbnailToolInstance.ifxObject != Selection.activeGameObject)
                {
                    DestroyImmediate(thumbnailToolInstance.ifxObject, true);
                }
                if (Selection.activeObject is GameObject)
                {                    
                    GameObject obj = Selection.activeObject as GameObject;
                    thumbnailToolInstance.ifxObject = (GameObject)Instantiate(obj, new Vector3(0, 0, 0), Quaternion.identity);
                    thumbnailToolInstance.ThumbnailSetup(thumbnailToolInstance.ifxObject);                    
                }
                else
                {
                    Debug.Log("Select a GameObject object first");
                }
            }         
            if (GUILayout.Button("Reset Camera"))
            {
                thumbnailToolInstance.ResetCameraSettings();
            }
            // if (GUILayout.Button("Auto Camera - This is a WIP"))
            // {
            //     thumbnailToolInstance.AutoCamera(thumbnailToolInstance.ifxObject, thumbnailToolInstance.cameraObject);
            // }
            EditorGUILayout.LabelField(" ");
            if (GUILayout.Button("Save Thumbnail"))
            {
                saveLocation = ValidatePathAndSaveThumbnail(saveLocation);
                
                
            }
            //if the camera still exists, Update the preview
            if (thumbnailToolInstance.cameraObject)
            {
                //thumbnailToolInstance.ThumbnailToolControlsUI();
                thumbnailToolInstance.UpdatePreviewImage();
            }            
        }
        string ValidatePathAndSaveThumbnail(string saveLocationPath )
        {
            if (!string.IsNullOrEmpty(saveLocationPath) && Directory.Exists(saveLocationPath))
            {
                thumbnailToolInstance.SaveThumbnail(saveLocationPath);
                return saveLocationPath;
            }
            else
            {
                if (EditorUtility.DisplayDialog("WARNING!", "Thumbnail Save location Not Set, please pick a save directory", "Browse", "Cancel"))
                {
                    saveLocationPath = EditorUtility.OpenFolderPanel("Select thumbnail save location", "", "");
                    if (!string.IsNullOrEmpty(saveLocationPath) && Directory.Exists(saveLocationPath))
                    {
                        thumbnailToolInstance.SaveThumbnail(saveLocationPath);
                        return saveLocationPath;
                    }
                    else
                    {
                        if (EditorUtility.DisplayDialog("WARNING!", "This is not a valid save directory", "Ok", ""))
                        {
                            return saveLocationPath;
                        }
                    }
                }
                return saveLocationPath;
            }
        }
    }
}
        
    