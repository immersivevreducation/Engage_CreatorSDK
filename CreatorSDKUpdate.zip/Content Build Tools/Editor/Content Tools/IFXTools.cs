﻿using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
using Engage.UI.Editor;

namespace Engage.CreatorSDK
{
    public static class IFXTools
    {
        #region Parenting
        [MenuItem(MenuLabels.GameObjectContext + "Create Parent")]
        public static IEnumerable<GameObject> CreateEmptyParents()
        {
            var parents = new List<GameObject>();

            foreach (GameObject item in Selection.gameObjects)
            {
                item.CreateEmptyParent();
            }

            return parents;
        }

        [MenuItem("GameObject/Create Normal-Scale Parent", priority = 0)]
        public static void CreateEmptyParent(MenuCommand command)
        {
            var target = command.context as GameObject;

            if (target)
            {
                target.CreateEmptyParent();
            }
        }

        public static IEnumerable<GameObject> CreateEmptyParents(this GameObject[] gameObjects, string prefix = null, string affix = null)
        {
            var parents = new List<GameObject>();

            foreach (GameObject item in gameObjects)
            {
                parents.Add(item.CreateEmptyParent(prefix, affix));
            }

            return parents;
        }

        public static GameObject CreateEmptyParent(this GameObject item, string prefix = null, string affix = null)
        {
            var parent = new GameObject(prefix + item.name + affix);
            parent.transform.SetPositionAndRotation(item.transform.position, item.transform.rotation);
            item.transform.SetParent(parent.transform, true);
            Selection.activeObject = parent;

            return parent;
        }
        #endregion

        #region IFX Prefabs

        public static string GetPrefabPath(this GameObject item)
        {
            if (!Directory.Exists(IFXSettings.PrefabFolderPath))
            {
                Directory.CreateDirectory(IFXSettings.PrefabFolderPath);
            }

            return AssetDatabase.GenerateUniqueAssetPath($"{IFXSettings.PrefabFolderPath}/{item.name}.prefab");
        }

        [MenuItem("GameObject/Create IFX Prefab", priority = 0)]
        public static void CreateIFXPrefab(MenuCommand command)
        {
            var target = command.context as GameObject;
            target.CreateIFXPrefab();
        }

        public static GameObject CreateIFXPrefab(this GameObject item)
        {
            if (item.transform.localScale != Vector3.one)
            {
                item = item.CreateEmptyParent();
            }

            var prefab = PrefabUtility.SaveAsPrefabAssetAndConnect(item, item.GetPrefabPath(), InteractionMode.UserAction);
            prefab.transform.SetPositionAndRotation(Vector3.zero, Quaternion.identity);

            return prefab;
        }

        public static IEnumerable<GameObject> CreateIFXPrefabs(GameObject[] gameObjects)
        {
            var prefabs = new List<GameObject>();

            foreach (var gameObject in gameObjects)
            {
                prefabs.Add(gameObject.CreateIFXPrefab());
            }

            return prefabs;
        }
        #endregion

        #region Root Transform Alignment
        public const int offset = 10;

        public static void AlignWithUndo(GameObject[] gameObjects, Vector3 alignment)
        {
            foreach(var gameObject in gameObjects)
            {
                if (gameObject)
                {
                    AlignWithUndo(gameObject, alignment);
                }
            }
        }

        public static void AlignWithUndo(GameObject gameObject, Vector3 alignment)
        {
            if (!gameObject)
            {
                AlignWithUndo(Selection.gameObjects, alignment);
                return;
            }

            var root = gameObject.transform;
            Undo.RecordObjects(root.GetChildren(), "Align Root Transform");

            var position = root.GetRenderBounds().GetPoint(alignment);
            root.Align(position);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Center", priority = 0 + offset)]
        public static void AlignCenter(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.zero);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Top", priority = 1 + offset)]
        public static void AlignTop(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.up);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Bottom", priority = 2 + offset)]
        public static void AlignBottom(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.down);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Front", priority = 3 + offset)]
        public static void AlignFront(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.forward);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Back", priority = 4 + offset)]
        public static void AlignBack(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.back);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Left", priority = 5 + offset)]
        public static void AlignLeft(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.left);
        }

        [MenuItem(MenuLabels.GameObjectAlignRoot + "Right", priority = 6 + offset)]
        public static void AlignRight(MenuCommand command)
        {
            var gameObject = command.context as GameObject;
            AlignWithUndo(gameObject, Vector3.right);
        }

        // This is just here as an example
        //[MenuItem(MenuLabels.GameObjectAlignRoot + "Top Left", priority = 6 + offset)]
        //public static void AlignTopLeft(MenuCommand command)
        //{
        //    var gameObject = command.context as GameObject;
        //    AlignWithUndo(gameObject, Vector3.up + Vector3.left);
        //}
        #endregion
    }
}