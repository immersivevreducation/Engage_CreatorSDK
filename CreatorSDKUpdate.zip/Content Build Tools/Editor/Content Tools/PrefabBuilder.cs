﻿using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEditor;
using Engage.UI.Editor;

namespace Engage.CreatorSDK
{
    public class PrefabBuilder : ViewModel
    {
        public string PrefabFolderPath { get => IFXSettings.PrefabFolderPath; set => IFXSettings.PrefabFolderPath = value; }

        public List<GameObject> ObjectList { get; internal set; } = new List<GameObject>();

        public override void Refresh()
        {
            ObjectList.Clear();
            ObjectList.AddRange(Selection.gameObjects);
        }

        public void BuildPrefabs()
        {
            if (!AssetDatabase.IsValidFolder(IFXSettings.PrefabFolderPath))
            {
                Directory.CreateDirectory(IFXSettings.PrefabFolderPath);
            }

            IFXTools.CreateIFXPrefabs(ObjectList.ToArray());
        }
    }
}
