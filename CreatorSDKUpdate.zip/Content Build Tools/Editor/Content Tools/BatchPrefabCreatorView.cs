using Engage.UI.Editor;
using UnityEditor;
using UnityEngine;

namespace Engage.CreatorSDK
{
    public class BatchPrefabCreatorView : View<PrefabBuilder>
    {
        private Vector2 scrollPos;
        private const float verticalSpace = 20f;

        private class Labels : CreatorSDK.Labels
        {
            public const string MenuTitle = "Batch Prefab Creator";
            public const string ViewTitle = "Batch Prefab Creator";
        }

        [MenuItem(MenuLabels.AssetsToolsPath + Labels.MenuTitle, priority = MenuLabels.AssetToolsPriority + 1)]
        [MenuItem(MenuLabels.CreatorSDKToolsPath + Labels.MenuTitle, priority = MenuLabels.AssetToolsPriority + 1)]
        public static void OpenView() => GetWindow<BatchPrefabCreatorView>(title: Labels.ViewTitle).Open();

        public override void Draw()
        {
            ViewModel.PrefabFolderPath = GuiTools.FolderSelectionField(Labels.PrefabFolderPath, ViewModel.PrefabFolderPath, false);

            GUILayout.Space(verticalSpace);

            GuiTools.DrawHeader("Selected GameObjects");

            DrawQueue();

            using (var buttons = new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(Labels.Refresh))
                {
                    ViewModel.Refresh();
                }

                if (GUILayout.Button("Create"))
                {
                    ViewModel.BuildPrefabs();
                }
            }

            EditorGUILayout.Space();
        }

        private void DrawQueue()
        {
            using (var scrollArea = new GuiTools.ScrollArea(ref scrollPos, EditorStyles.helpBox))
            {
                foreach (var gameObject in ViewModel.ObjectList)
                {
                    DrawImage(gameObject);
                }
            }
        }

        private void DrawImage(GameObject gameObject)
        {
            using (var gameObjectRow = new EditorGUILayout.HorizontalScope())
            {
                gameObject.name = EditorGUILayout.TextField(gameObject.name);
            }
        }
    }
}