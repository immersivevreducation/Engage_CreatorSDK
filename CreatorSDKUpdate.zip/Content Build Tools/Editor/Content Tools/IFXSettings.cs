﻿using Engage.UI.Editor;

namespace Engage.CreatorSDK
{
    public class IFXSettings : Settings<IFXSettings>
    {
        private const string defaultPrefabFolderPath = "Assets/Prefabs";

        private Setting<string> prefabFolderPath;
        private Setting<bool> generateParentObject;

        public IFXSettings()
        {
            RegisterString(GetKey(nameof(PrefabFolderPath)), ref prefabFolderPath, defaultPrefabFolderPath);
            RegisterBool(GetKey(nameof(GenerateParentObject)), ref generateParentObject, true);
        }

        public static string PrefabFolderPath { get => Instance.prefabFolderPath; set => Instance.prefabFolderPath.Value = value; }
        public static bool GenerateParentObject { get => Instance.generateParentObject; set => Instance.generateParentObject.Value = value; }

        public static void Reset()
        {
            Instance.Reset(GetKey(nameof(PrefabFolderPath)), Instance.prefabFolderPath);
            Instance.Reset(GetKey(nameof(GenerateParentObject)), Instance.generateParentObject);
        }
    }
}