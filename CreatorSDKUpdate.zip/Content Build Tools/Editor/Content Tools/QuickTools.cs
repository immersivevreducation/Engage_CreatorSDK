using System;
using UnityEditor;
using UnityEngine;

namespace Engage.CreatorSDK
{
    public class QuickTools : EditorWindow
    {
        int selectedTabIndex;

        string[] tabLabels = new string[]
        {
            "Prefab Tools",
            "Organising Tools",
            "Creation Tools"
        };

        Action[] tabDrawers;
        Action DrawTab => tabDrawers[selectedTabIndex];

        bool altCenterMethod { get; set; }
        string folderName;
        float mipMapBias = -0.7f;
        string destinationFolder;

        [MenuItem("Assets/Asset Tools/IFX Tools")]
        [MenuItem("Creator SDK/Asset Tools/IFX Tools", priority = UI.Editor.MenuLabels.AssetToolsPriority)]
        static void Init()
        {
            EditorWindow window = GetWindow<QuickTools>("IFX Tools");
            window.position = new Rect(100, 100, 700, 700);
            window.minSize = new Vector2(500,700);
            window.Show();
        }

        private void Awake()
        {
            tabDrawers = new Action[]
            {
                DrawPrefabTab,
                DrawOrganizationTab,
                DrawCreationTab
            };
        }

        const float buttonSize = 175;

        void OnGUI()
        {
            GUILayout.Space(25);

            using (var mainPanel = new EditorGUILayout.HorizontalScope())
            {
                GUILayout.Space(5);

                using (var buttonPanel = new EditorGUILayout.VerticalScope(GUILayout.Width(buttonSize), GUILayout.ExpandHeight(true)))
                {
                    for (int i = 0; i < tabLabels.Length; i++)
                    {
                        if (GUILayout.Button(tabLabels[i], GUILayout.Width(buttonSize), GUILayout.Height(buttonSize)))
                        {
                            selectedTabIndex = i;
                        }
                    }
                }

                GUILayout.Space(10);

                using (var tabPanel = new EditorGUILayout.VerticalScope())
                {
                    DrawTab?.Invoke();
                }

                GUILayout.Space(5);
            }

            GUILayout.Space(25);
        }

        //Prefab Tools
        void DrawPrefabTab()
        {
            using (var section1 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                EmptyPrefabWindowUI();
            }

            GUILayout.Space(10);

            using (var section2 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                BatchPrefabWindowUI();
            }

            GUILayout.Space(10);

            using (var section3 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                AutoPivotUI();
            }
        }

        //Organization Tools
        void DrawOrganizationTab()
        {
            using (var section1 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                if (GUILayout.Button("Youtube Downloader"))
                {
                    EditorWindow window = GetWindow(typeof(IFXToolsYouTubeDownloader));
                    window.Show();
                }
            }

            GUILayout.Space(10);

            using (var section2 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                NewDependenciesWindowUI();
            }

        }

        //Creation Tools
        void DrawCreationTab()
        {
            using (var section1 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                CreateImagePlaneUI();
            }

            GUILayout.Space(10);


            using (var section2 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                AnimCNTRLFromClipsWindowUI();
            }

            GUILayout.Space(10);


            using (var section3 = new EditorGUILayout.VerticalScope(EditorStyles.helpBox))
            {
                BatchChangeMipMapBiasUI();
            }

            GUILayout.Space(10);

            if (GUILayout.Button("Thumbnail Tool"))
            {
                IFXThumbnailToolWindow.Open();
            }
        }

        #region Prefab Tools
        void EmptyPrefabWindowUI()
        {
            EditorGUILayout.LabelField("Add a top level zeroed out empty", EditorStyles.boldLabel);

            BuildSettings.PrefabPrefix = EditorGUILayout.TextField("Prefix", BuildSettings.PrefabPrefix);
            BuildSettings.PrefabSuffix = EditorGUILayout.TextField("Suffex", BuildSettings.PrefabSuffix);

            if (GUILayout.Button("Create Zeroed Prefab"))
            {
                Selection.gameObjects.CreateEmptyParents(BuildSettings.PrefabPrefix, BuildSettings.PrefabSuffix);
            }
        }

        void BatchPrefabWindowUI()
        {
            QuickToolsHelp.BatchMakePrefabsInstructions(); // displays the instructions for this tool

            destinationFolder = EditorGUILayout.TextField("Destination Folder:", destinationFolder);

            if (GUILayout.Button("Set Destination Folder"))
            {
                destinationFolder = AssetDatabase.GetAssetPath(Selection.activeObject);
            }

            if (GUILayout.Button("Make Prefabs"))
            {
                // Loop through every GameObject in the array above
                foreach (GameObject gameObject in Selection.objects)
                {
                    // Set the path as within the Assets folder,
                    // and name it as the GameObject's name with the .Prefab format
                    string localPath = destinationFolder + "/" + gameObject.name + ".prefab";

                    // Make sure the file name is unique, in case an existing Prefab has the same name.
                    localPath = AssetDatabase.GenerateUniqueAssetPath(localPath);

                    // Create the new Prefab.
                    PrefabUtility.SaveAsPrefabAssetAndConnect(gameObject, localPath, InteractionMode.UserAction);
                }
            }
        }

        void AutoPivotUI()
        {
            QuickToolsHelp.AutoPivotInstructions(); // displays the instructions for this tool
            altCenterMethod = GUILayout.Toggle(altCenterMethod, "ALT Centering");

            if (GUILayout.Button("Auto Pivot"))
            {
                if (Selection.gameObjects != null)
                {
                    //string assetPath = PrefabUtility.GetPrefabAssetPathOfNearestInstanceRoot(Selection.gameObjects[0]);
                    //string assetPath = AssetDatabase.GetAssetPath(Selection.gameObjects[0]);
                    //Debug.Log("Asset path is: "+assetPath);
                    IFXToolsStaticMethods.BatchCenterIFX(Selection.gameObjects, false);
                }
                else
                {
                    Debug.Log("Nothing selected - please select the top most object of the hierarchy and try again");
                }
            }
        }
        #endregion

        #region Organising Tools
        void NewDependenciesWindowUI()
        {
            // Create all the folders and stuff for a new dependencie
            QuickToolsHelp.NewDependenciesWindowInstructions(); // displays the instructions for this tool
            folderName = EditorGUILayout.TextField("Folder Name: ", folderName);
            if (GUILayout.Button("Create Folders"))
            {
                //IFXToolsStaticMethods.CreateDependenciesFolder(BuildSettings.currentIFXNum,folderName);
            }
        }
        #endregion

        #region Creation Tools
        void CreateImagePlaneUI()
        {
            EditorGUILayout.LabelField("Create Image Plane From image", EditorStyles.boldLabel);
            //EditorGUILayout.LabelField("This feature still needs error handeling to be written");

            if (GUILayout.Button("Image plane from Image"))
            {
                ImageTools.CreateImagePrefab();
                //IFXToolsStaticMethods.ImagePlaneFromImage();
            }
        }

        void AnimCNTRLFromClipsWindowUI()
        {
            QuickToolsHelp.AnimClipsFromFBXInstructions();

            if (GUILayout.Button("Quick Create Anim Controlers"))
            {
                IFXToolsStaticMethods.CreateAnimClipsFromSelectedFBX();
            }
        }

        void BatchChangeMipMapBiasUI()
        {
            EditorGUILayout.LabelField("Change MipMap Bias of every selected Texture", EditorStyles.boldLabel);
            mipMapBias = EditorGUILayout.FloatField(mipMapBias);
            if (GUILayout.Button("Batch change mip map bias"))
            {
                foreach (UnityEngine.Object obj in Selection.objects)
                {
                    string path = AssetDatabase.GetAssetPath(obj);
                    TextureImporter texImporter = AssetImporter.GetAtPath(path) as TextureImporter;
                    if (texImporter != null)
                    {
                        texImporter.mipmapEnabled = true;
                        //  texImporter.filterMode =filter;
                        //  texImporter.anisoLevel = aniso;
                        texImporter.mipMapBias = mipMapBias;
                        AssetDatabase.ImportAsset(path);
                    }
                }
            }
        }
        #endregion





    }
}

public static class QuickToolsHelp
{
    public static void AutoPivotInstructions()
    {
        EditorGUILayout.LabelField("Center IFX", EditorStyles.boldLabel);
        EditorGUILayout.LabelField("This tool assumes a top level empty at 0,0,0");
        EditorGUILayout.LabelField("You can easily add one using the \"quick prefab\" tool.");
        EditorGUILayout.LabelField(" ");
        EditorGUILayout.LabelField("\"ALT Centering\" Slower but more accurate.");
        EditorGUILayout.LabelField("It figures out the center based on mesh verticies.");
        EditorGUILayout.LabelField(" ");
        EditorGUILayout.LabelField("NOTE: this tool has no undo.");
        EditorGUILayout.LabelField("Makes immediate changes to prefabs. No need to override.");
        EditorGUILayout.LabelField("Works on selections in project view or scene view.");
    }

    public static void NewDependenciesWindowInstructions()
    {

        EditorGUILayout.LabelField("Set up Client folders", EditorStyles.boldLabel);
        EditorGUILayout.LabelField("Type client name and click the button to create dependencies folder, ifx and asset label.");
        EditorGUILayout.LabelField("For example type mcdonalds and you would get Dependencies_mcdonalds, ");
        EditorGUILayout.LabelField("ifx3-mcdonalds folders and ifx3-mcdonalds assetbunddle created and applied.");
    }

    public static void AnimClipsFromFBXInstructions()
    {
        EditorGUILayout.LabelField("Create Animation Controlers from Selection", EditorStyles.boldLabel);
        EditorGUILayout.LabelField("TO USE: Select the fbx in the project window and hit the button.");
        EditorGUILayout.LabelField("You will get a named anim controller for every anim clip in the fbx.");
        EditorGUILayout.LabelField("each anim controler will already be connected to it's animation clip.");
    }

    public static void BatchMakePrefabsInstructions()
    {

        EditorGUILayout.LabelField("Batch Make Prefabs ", EditorStyles.boldLabel);
        EditorGUILayout.LabelField("This tool adds all the selected objects in a scene as prefabs so you don't have to do it one by one.");
        EditorGUILayout.LabelField("TO USE: Set the destination folder by selecting the folder and hitting the button or by typing in the box.");
        EditorGUILayout.LabelField("Then select all the objects you want added as prefabs and click the Make Prefabs button.");
    }
}