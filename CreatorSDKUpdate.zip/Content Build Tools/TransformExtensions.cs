﻿using UnityEngine;

namespace Engage.CreatorSDK
{
    public static class TransformExtensions
    {
        public static void Align(this Transform root, Vector3 position)
        {
            var delta = root.position - position;

            foreach (Transform child in root)
            {
                child.localPosition += delta;
            }
        }

        public static Bounds GetRenderBounds(this Transform transform)
        {
            var renderers = transform.GetComponentsInChildren<Renderer>();

            if (renderers.Length == 0)
            {
                return new Bounds(transform.position, Vector3.zero);
            }

            var bounds = renderers[0].bounds;

            for (int i = 1; i < renderers.Length; i++)
            {
                bounds.Encapsulate(renderers[i].bounds);
            }

            return bounds;
        }

        public static Bounds GetColliderBounds(this Transform transform)
        {
            var colliders = transform.GetComponentsInChildren<Collider>();

            if (colliders.Length == 0)
            {
                return new Bounds(transform.position, Vector3.zero);
            }

            var bounds = colliders[0].bounds;

            for(int i = 1; i < colliders.Length; i++)
            {
                bounds.Encapsulate(colliders[i].bounds);
            }

            return bounds;
        }

        public static Transform[] GetChildren(this Transform parent)
        {
            var children = new Transform[parent.childCount];

            for (int i = 0; i < parent.childCount; i++)
            {
                children[i] = parent.GetChild(i);
            }

            return children;
        }
    }
}